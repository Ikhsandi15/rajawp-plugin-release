<?php
/**
 * Plugin Name: Komerce Shipping & Payment
 * Plugin URI: https://komerce.id
 * Description: Integrasi WooCommerce dengan Komerce Collaborator OpenAPI — Shipping, Tracking, Pickup, Payment.
 * Version: 2.3.9
 * Author: Komerce
 * Author URI: https://komerce.id
 * Text Domain: komerce-shipping
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 * WC tested up to: 10.7.0
 *
 * @package Komerce
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'KOMERCE_PLUGIN_FILE' ) ) {
    define( 'KOMERCE_PLUGIN_FILE', __FILE__ );
}
if ( ! defined( 'KOMERCE_PLUGIN_DIR' ) ) {
    define( 'KOMERCE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'KOMERCE_PLUGIN_URL' ) ) {
    define( 'KOMERCE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}
if ( ! defined( 'KOMERCE_VERSION' ) ) {
    define( 'KOMERCE_VERSION', '2.3.9' );
}

// ── Automatic updates via GitHub Release ──
if ( file_exists( KOMERCE_PLUGIN_DIR . 'includes/plugin-update-checker/plugin-update-checker.php' ) ) {
    require_once KOMERCE_PLUGIN_DIR . 'includes/plugin-update-checker/plugin-update-checker.php';
    $komerce_update_checker = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
        'https://github.com/Ikhsandi15/rajawp-plugin-release/',
        KOMERCE_PLUGIN_FILE,
        'komerce-shipping'
    );
    $komerce_update_checker->setBranch( 'main' );
    if ( is_object( $komerce_update_checker->getVcsApi() ) && method_exists( $komerce_update_checker->getVcsApi(), 'enableReleaseAssets' ) ) {
        $komerce_update_checker->getVcsApi()->enableReleaseAssets( '/\.zip($|[?&#])/i' );
    }
}

// Remove "Edit" link in Plugins admin list to prevent clients from tampering with code
add_filter( 'plugin_action_links_' . plugin_basename( KOMERCE_PLUGIN_FILE ), function ( $actions ) {
    unset( $actions['edit'] );
    return $actions;
} );

/**
 * Initialize plugin after all plugins loaded.
 */
if ( ! function_exists( 'komerce_init' ) ) :
function komerce_init() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function () {
            echo '<div class="notice notice-error"><p><strong>Komerce Shipping & Payment</strong> membutuhkan <a href="https://woocommerce.com" target="_blank">WooCommerce</a> yang aktif.</p></div>';
        } );
        return;
    }

    $dir = KOMERCE_PLUGIN_DIR . 'includes/';

    require_once $dir . 'class-komerce-logger.php';
    require_once $dir . 'class-komerce-api-client.php';
    require_once $dir . 'rajaongkir-functions.php';
    require_once $dir . 'class-komerce-destination.php';
    require_once $dir . 'class-komerce-order.php';
    require_once $dir . 'class-komerce-pickup.php';
    require_once $dir . 'class-komerce-tracking.php';
    require_once $dir . 'class-komerce-label.php';
    require_once $dir . 'class-komerce-ajax.php';
    require_once $dir . 'class-komerce-diagnostics.php';

    /**
     * Load shipping & payment classes only when WooCommerce is ready.
     * This avoids "Class Not Found" errors for WC_Shipping_Method and WC_Payment_Gateway.
     */
    add_action( 'woocommerce_shipping_init', function() use ( $dir ) {
        require_once $dir . 'class-komerce-shipping.php';
    } );

    add_action( 'init', function() use ( $dir ) {
        if ( class_exists( 'WC_Payment_Gateway' ) ) {
            require_once $dir . 'class-komerce-payment.php';
        }
    }, 5 );

    // Register shipping method.
    add_filter( 'woocommerce_shipping_methods', function ( $methods ) {
        if ( class_exists( 'WC_Komerce_Shipping' ) ) {
            $methods['komerce_shipping'] = 'WC_Komerce_Shipping';
        }
        return $methods;
    } );

    // Register payment gateway.
    add_filter( 'woocommerce_payment_gateways', function ( $gateways ) {
        if ( class_exists( 'WC_Komerce_Payment' ) ) {
            $gateways[] = 'WC_Komerce_Payment';
        }
        return $gateways;
    } );

    // Initialize modules.
    new Komerce_Destination();
    Komerce_Order::instance();
    new Komerce_Pickup();
    new Komerce_Tracking();
    new Komerce_Label();
    new Komerce_Ajax();

    if ( is_admin() ) {
        new Komerce_Diagnostics();
    }

    // Save destination to session.
    add_action( 'wp_ajax_komerce_save_destination', 'komerce_save_destination_session' );
    add_action( 'wp_ajax_nopriv_komerce_save_destination', 'komerce_save_destination_session' );

    // Persist destination & shipping selection to order meta.
    add_action( 'woocommerce_checkout_update_order_meta', 'komerce_save_destination_meta' );
    add_action( 'woocommerce_checkout_update_order_meta', 'rajaongkir_save_shipping_selection_to_order' );

    // Admin settings page.
    add_action( 'admin_menu', 'komerce_add_settings_page' );
    add_action( 'admin_init', 'komerce_register_settings' );

    // Local order status checker (0 external API calls - reads pure local DB).
    add_action( 'wp_ajax_komerce_check_local_order_status', 'komerce_check_local_order_status_handler' );
    add_action( 'wp_ajax_nopriv_komerce_check_local_order_status', 'komerce_check_local_order_status_handler' );

    // Use Komerce order_no (generated by store order API) as the public order number.
    add_filter( 'woocommerce_order_number', function ( $order_number, $order ) {
        if ( ! $order instanceof WC_Order ) {
            return $order_number;
        }
        $komerce_no = (string) $order->get_meta( '_komerce_order_no' );
        if ( '' !== $komerce_no ) {
            return $komerce_no;
        }
        $ro_no = (string) $order->get_meta( '_rajaongkir_order_no' );
        if ( '' !== $ro_no ) {
            return $ro_no;
        }
        return $order_number;
    }, 10, 2 );

    // Early interceptor for Komerce webhook requests.
    add_action( 'init', function () use ( $dir ) {
        $uri = strtolower( $_SERVER['REQUEST_URI'] ?? '' );
        $api = strtolower( sanitize_key( $_GET['wc-api'] ?? '' ) );
        $is_wh = in_array( $api, array( 'komerce-webhook', 'komercewebhook', 'komerce-callback', 'komerce_webhook' ), true )
            || false !== strpos( $uri, 'wc-api/komerce-webhook' )
            || false !== strpos( $uri, 'wc-api/komercewebhook' )
            || false !== strpos( $uri, 'wc-api/komerce-callback' )
            || false !== strpos( $uri, 'wc-api/komerce_webhook' )
            || false !== strpos( $uri, 'wc-api=komerce-webhook' )
            || false !== strpos( $uri, 'wc-api=komerce_webhook' );

        if ( $is_wh ) {
            if ( ! class_exists( 'WC_Komerce_Payment' ) ) {
                require_once $dir . 'class-komerce-payment.php';
            }
            if ( class_exists( 'WC_Komerce_Payment' ) ) {
                $gateway = new WC_Komerce_Payment();
                $gateway->handle_webhook();
                exit;
            }
        }
    }, 20 );
}
add_action( 'plugins_loaded', 'komerce_init' );
endif;

// ── Activation / deactivation ──

/**
 * Activation: seed default settings, flush caches, verify WooCommerce presence.
 *
 * @return void
 */
if ( ! function_exists( 'komerce_activate' ) ) :
function komerce_activate() {
    $defaults = array(
        'api_key_order'     => '',
        'api_key_payment'   => '',
        'sandbox_mode'      => 'yes',
        'auto_create_order' => 'yes',
        'webhook_secret'    => '',
        'custom_webhook_url'=> '',
        'shipper_name'      => get_bloginfo( 'name' ),
        'shipper_phone'     => '',
        'shipper_address'   => '',
        'origin_id'         => '',
    );

    $existing = get_option( 'komerce_settings', array() );
    if ( ! is_array( $existing ) ) {
        $existing = array();
    }

    if ( empty( $existing['webhook_secret'] ) ) {
        $defaults['webhook_secret'] = wp_generate_password( 40, false );
    }

    update_option( 'komerce_settings', array_merge( $defaults, $existing ) );

    if ( class_exists( 'Komerce_API_Client' ) ) {
        Komerce_API_Client::clear_cache();
    }

    update_option( 'komerce_version', KOMERCE_VERSION, false );
}
endif;
register_activation_hook( __FILE__, 'komerce_activate' );

/**
 * Deactivation: clear cached API responses.
 *
 * @return void
 */
if ( ! function_exists( 'komerce_deactivate' ) ) :
function komerce_deactivate() {
    if ( class_exists( 'Komerce_API_Client' ) ) {
        Komerce_API_Client::clear_cache();
    }
}
endif;
register_deactivation_hook( __FILE__, 'komerce_deactivate' );

add_action( 'admin_notices', function () {
    if ( get_transient( 'komerce_missing_wc_notice' ) ) {
        delete_transient( 'komerce_missing_wc_notice' );
        echo '<div class="notice notice-warning is-dismissible"><p><strong>Komerce Shipping &amp; Payment</strong> aktif, tetapi WooCommerce belum terdeteksi. Aktifkan WooCommerce agar integrasi berjalan.</p></div>';
    }
} );

// ── Suppress shipping fee on Cart page (Fee only calculated when selecting courier on Checkout Step 2) ──

add_filter( 'woocommerce_cart_ready_to_calc_shipping', function ( $show_shipping ) {
    if ( function_exists( 'is_cart' ) && is_cart() ) {
        return false;
    }
    return $show_shipping;
}, 99 );

add_filter( 'woocommerce_cart_needs_shipping_address', function ( $needs_address ) {
    if ( function_exists( 'is_cart' ) && is_cart() ) {
        return false;
    }
    return $needs_address;
}, 99 );

add_action( 'template_redirect', function () {
    if ( function_exists( 'is_cart' ) && is_cart() && WC()->session ) {
        WC()->session->set( 'chosen_shipping_methods', array() );
        WC()->session->set( 'komerce_user_has_selected_shipping', false );
    }
    // On fresh checkout GET request, start with no pre-selected courier fee until step 2 selection
    if ( function_exists( 'is_checkout' ) && is_checkout() && ! is_wc_endpoint_url() && 'GET' === ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) && WC()->session ) {
        if ( empty( $_POST['shipping_method'] ) ) {
            WC()->session->set( 'chosen_shipping_methods', array() );
            WC()->session->set( 'komerce_user_has_selected_shipping', false );
        }
    }
} );

// Ensure session flag is immediately updated during WooCommerce AJAX update_order_review
add_action( 'woocommerce_checkout_update_order_review', function ( $post_data ) {
    $posted_methods = isset( $_POST['shipping_method'] ) ? (array) $_POST['shipping_method'] : array();

    if ( empty( $posted_methods ) && ! empty( $post_data ) ) {
        parse_str( (string) $post_data, $post_data_parsed );
        if ( ! empty( $post_data_parsed['shipping_method'] ) ) {
            $posted_methods = (array) $post_data_parsed['shipping_method'];
        }
    }

    if ( ! empty( $posted_methods ) ) {
        $first = reset( $posted_methods );
        if ( ! empty( $first ) && WC()->session && is_callable( array( WC()->session, 'set' ) ) ) {
            WC()->session->set( 'komerce_user_has_selected_shipping', true );
        }
    }
}, 5 );

add_action( 'woocommerce_after_calculate_totals', function( $cart ) {
    if ( WC()->session && is_callable( array( WC()->session, 'get' ) ) ) {
        $chosen = WC()->session->get( 'chosen_shipping_methods' );
        if ( ! empty( $chosen ) && ! empty( $chosen[0] ) ) {
            WC()->session->set( 'komerce_user_has_selected_shipping', true );
        }
    }
}, 5 );

// Do not auto-select a shipping method until user explicitly chooses one (Step 2 of checkout)
add_filter( 'woocommerce_shipping_chosen_method', function ( $default, $rates, $chosen_method ) {
    // Check if user has explicitly posted a shipping method right now
    $posted_methods = isset( $_POST['shipping_method'] ) ? (array) $_POST['shipping_method'] : array();

    if ( empty( $posted_methods ) && ! empty( $_POST['post_data'] ) ) {
        parse_str( (string) $_POST['post_data'], $post_data_parsed );
        if ( ! empty( $post_data_parsed['shipping_method'] ) ) {
            $posted_methods = (array) $post_data_parsed['shipping_method'];
        }
    }

    $session_chosen = ( WC()->session && is_callable( array( WC()->session, 'get' ) ) )
        ? WC()->session->get( 'komerce_user_has_selected_shipping' )
        : false;

    if ( ! empty( $posted_methods ) ) {
        $first = reset( $posted_methods );
        if ( ! empty( $first ) ) {
            if ( WC()->session && is_callable( array( WC()->session, 'set' ) ) ) {
                WC()->session->set( 'komerce_user_has_selected_shipping', true );
            }
            return $first;
        }
    }

    if ( $session_chosen && ! empty( $chosen_method ) && isset( $rates[ $chosen_method ] ) ) {
        return $chosen_method;
    }

    // Default to empty string: no shipping method selected, no shipping cost added to cart total
    return '';
}, 99, 3 );

// Safety filter: ensure #summaryShippingFee fragment displays cart shipping total whenever shipping total > 0
add_filter( 'woocommerce_update_order_review_fragments', function ( $fragments ) {
    if ( WC()->cart && WC()->cart->get_shipping_total() > 0 ) {
        $shipping_html = wc_price( WC()->cart->get_shipping_total() );
        foreach ( $fragments as $key => $html ) {
            if ( false !== strpos( $html, 'summaryShippingFee' ) ) {
                $fragments[ $key ] = preg_replace(
                    '/(<span[^>]*id=["\']summaryShippingFee["\'][^>]*>)\s*(?:Rp0|0|Rp\s*0)\s*(<\/span>)/i',
                    '$1' . addcslashes( $shipping_html, '$' ) . '$2',
                    $html
                );
            }
        }
    }
    return $fragments;
}, 999 );

// Inject destination_id into shipping package destination so WooCommerce invalidates package rate cache whenever destination changes
add_filter( 'woocommerce_cart_shipping_packages', function ( $packages ) {
    $dest_id = function_exists( 'komerce_get_posted_or_session_destination_id' )
        ? komerce_get_posted_or_session_destination_id()
        : 0;

    if ( ! empty( $packages ) && is_array( $packages ) ) {
        foreach ( $packages as $i => $package ) {
            $packages[ $i ]['destination']['komerce_destination_id'] = (string) $dest_id;
            $packages[ $i ]['destination']['destination_id']         = (string) $dest_id;
        }
    }
    return $packages;
}, 99 );

// ── Session helper ──

if ( ! function_exists( 'komerce_save_destination_session' ) ) :
function komerce_save_destination_session() {
    check_ajax_referer( 'komerce_dest_nonce', 'nonce' );
    $id = sanitize_text_field( $_POST['destination_id'] ?? '' );
    if ( $id && WC()->session ) {
        WC()->session->set( 'komerce_destination_id', $id );
        WC()->session->set( 'chosen_shipping_methods', array() );
        WC()->session->set( 'komerce_user_has_selected_shipping', false );
    }
    wp_send_json_success();
}
endif;

/**
 * Helper to resolve destination_id from $_POST fields or active session.
 *
 * @return int
 */
if ( ! function_exists( 'komerce_get_posted_or_session_destination_id' ) ) :
function komerce_get_posted_or_session_destination_id() {
    $candidates = array(
        $_POST['billing_komerce_destination_id'] ?? '',
        $_POST['shipping_komerce_destination_id'] ?? '',
        $_POST['billing_komerce_destination'] ?? '',
        $_POST['shipping_komerce_destination'] ?? '',
        $_POST['billing_destination'] ?? '',
        $_POST['destination_id'] ?? '',
        $_POST['komerce_destination_id'] ?? '',
    );

    foreach ( $candidates as $cand ) {
        if ( ! empty( $cand ) ) {
            $cand = sanitize_text_field( wp_unslash( $cand ) );
            if ( is_numeric( $cand ) && (int) $cand > 0 ) {
                if ( WC()->session && is_callable( array( WC()->session, 'set' ) ) ) {
                    WC()->session->set( 'komerce_destination_id', (string) $cand );
                }
                return (int) $cand;
            }
        }
    }

    if ( ! empty( $_POST['post_data'] ) ) {
        parse_str( (string) $_POST['post_data'], $parsed );
        if ( is_array( $parsed ) ) {
            foreach ( $candidates as $cand_key ) {
                if ( ! empty( $parsed[ $cand_key ] ) ) {
                    $val = sanitize_text_field( wp_unslash( $parsed[ $cand_key ] ) );
                    if ( is_numeric( $val ) && (int) $val > 0 ) {
                        if ( WC()->session && is_callable( array( WC()->session, 'set' ) ) ) {
                            WC()->session->set( 'komerce_destination_id', (string) $val );
                        }
                        return (int) $val;
                    }
                }
            }
        }
    }

    if ( WC()->session && is_callable( array( WC()->session, 'get' ) ) ) {
        $sess = WC()->session->get( 'komerce_destination_id' );
        if ( ! empty( $sess ) && is_numeric( $sess ) && (int) $sess > 0 ) {
            return (int) $sess;
        }
    }

    return 0;
}
endif;

// ── Save destination to order meta ──

if ( ! function_exists( 'komerce_save_destination_meta' ) ) :
function komerce_save_destination_meta( $order_id ) {
    $order = wc_get_order( $order_id );
    if ( ! $order ) return;

    $dest_id = komerce_get_posted_or_session_destination_id();
    if ( $dest_id > 0 ) {
        $order->update_meta_data( 'billing_komerce_destination_id', (string) $dest_id );
        $order->update_meta_data( 'shipping_komerce_destination_id', (string) $dest_id );
        $order->update_meta_data( '_rajaongkir_destination_id', (string) $dest_id );
        $order->update_meta_data( 'destination_id', (string) $dest_id );

        // Persist to logged-in user profile as well
        if ( $order->get_customer_id() > 0 ) {
            update_user_meta( $order->get_customer_id(), 'billing_komerce_destination_id', (string) $dest_id );
            update_user_meta( $order->get_customer_id(), 'shipping_komerce_destination_id', (string) $dest_id );
        }
    }

    $fields = array(
        'billing_komerce_destination',
        'shipping_komerce_destination',
        'billing_destination',
    );
    foreach ( $fields as $f ) {
        if ( ! empty( $_POST[ $f ] ) ) {
            $val = sanitize_text_field( wp_unslash( $_POST[ $f ] ) );
            $order->update_meta_data( $f, $val );
            if ( $order->get_customer_id() > 0 ) {
                update_user_meta( $order->get_customer_id(), $f, $val );
            }
        }
    }

    // Copy shipping details from shipping methods to order meta for easy access
    foreach ( $order->get_shipping_methods() as $item ) {
        foreach ( $item->get_meta_data() as $m ) {
            $d = $m->get_data();
            if ( ! empty( $d['key'] ) && isset( $d['value'] ) && $d['value'] !== '' ) {
                $order->update_meta_data( '_komerce_' . $d['key'], $d['value'] );
                if ( $d['key'] === 'courier_code' ) {
                    $order->update_meta_data( '_rajaongkir_courier_id', $d['value'] );
                }
                if ( $d['key'] === 'shipping_code' ) {
                    $order->update_meta_data( '_komerce_shipping', $d['value'] );
                }
                if ( $d['key'] === 'service_code' ) {
                    $order->update_meta_data( '_rajaongkir_courier_service', $d['value'] );
                    $order->update_meta_data( '_komerce_shipping_type', $d['value'] );
                }
            }
        }
    }

    $order->save();
}
endif;

// ── Settings page ──

if ( ! function_exists( 'komerce_add_settings_page' ) ) :
function komerce_add_settings_page() {
    add_submenu_page(
        'woocommerce',
        'Komerce Settings',
        'Komerce',
        'manage_woocommerce',
        'komerce-settings',
        'komerce_render_settings'
    );
}
endif;

if ( ! function_exists( 'komerce_register_settings' ) ) :
function komerce_register_settings() {
    register_setting( 'komerce_settings_group', 'komerce_settings', array(
        'sanitize_callback' => 'komerce_sanitize_settings',
    ) );
}
endif;

if ( ! function_exists( 'komerce_sanitize_settings' ) ) :
function komerce_sanitize_settings( $input ) {
    $clean = array();
    $keys  = array(
        'api_key_order', 'api_key_payment',
        'sandbox_mode', 'auto_create_order', 'webhook_secret', 'custom_webhook_url',
        'shipper_name', 'shipper_phone', 'shipper_address', 'origin_id',
    );
    foreach ( $keys as $k ) {
        $clean[ $k ] = isset( $input[ $k ] ) ? sanitize_text_field( $input[ $k ] ) : '';
    }

    // API keys changed → drop cached API responses and rebuild the client.
    Komerce_API_Client::clear_cache();
    Komerce_API_Client::refresh();

    return $clean;
}
endif;

if ( ! function_exists( 'komerce_render_settings' ) ) :
function komerce_render_settings() {
    $opts = get_option( 'komerce_settings', array() );
    $api  = Komerce_API_Client::instance();

    $order_ok   = $api->is_order_configured();
    $payment_ok = $api->is_payment_configured();
    $all_ok     = $order_ok && $payment_ok;
    $any_ok     = $order_ok || $payment_ok;
    ?>
    <div class="wrap">
        <h1>Komerce Settings</h1>
        <p>Konfigurasi integrasi Komerce Collaborator OpenAPI.</p>

        <?php if ( $all_ok ) : ?>
            <div class="notice notice-success"><p>Semua API Key terkonfigurasi — Environment: <strong><?php echo esc_html( $api->get_environment() ); ?></strong></p></div>
        <?php elseif ( $any_ok ) : ?>
            <div class="notice notice-warning"><p>
                <?php
                $missing = array();
                if ( ! $order_ok )   $missing[] = 'API Key Shipping Delivery';
                if ( ! $payment_ok ) $missing[] = 'API Key Payment';
                echo 'Belum diisi: ' . esc_html( implode( ', ', $missing ) ) . '.';
                ?>
            </p></div>
        <?php else : ?>
            <div class="notice notice-error"><p>Belum ada API Key yang diisi.</p></div>
        <?php endif; ?>

        <!-- ── Panduan Integrasi & Webhook ── -->
        <div class="card" style="max-width:100%; margin-top:15px; margin-bottom:20px; padding:15px 20px; background:#fff; border-left:4px solid #2271b1; box-shadow:0 1px 3px rgba(0,0,0,0.05);">
            <h2 style="margin-top:0; font-size:16px; display:flex; align-items:center; gap:8px;">
                <span>📋</span> <strong>Panduan Integrasi: Dashboard Collaborator vs Pengaturan WooCommerce</strong>
            </h2>
            <p style="margin-bottom:12px; color:#50575e;">
                Gunakan tabel berikut untuk memahami konfigurasi mana yang harus dimasukkan ke <strong>Dashboard Komerce Collaborator</strong> dan mana yang diatur di <strong>WooCommerce</strong>:
            </p>
            <table class="widefat striped" style="margin-bottom:12px;">
                <thead>
                    <tr>
                        <th style="width:25%;">Komponen / Item</th>
                        <th style="width:25%;">Di Mana Diisinya?</th>
                        <th style="width:20%;">Perlu ke Collaborator?</th>
                        <th>Penjelasan &amp; Alur</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>🚚 Shipping Webhook URL</strong><br><small style="color:#646970;">(Callback Pengiriman &amp; AWB)</small></td>
                        <td>Didaftarkan di <strong>Dashboard Collaborator</strong></td>
                        <td><span style="color:#d63638; font-weight:600;">✓ WAJIB</span></td>
                        <td>
                            Daftarkan URL di bawah ke menu <em>Webhook / Integrasi</em> di Dashboard Collaborator. Digunakan Komerce untuk mengirim <strong>Nomor Resi (AWB / cnote)</strong> dan status pengiriman (<em>Diajukan, Dijemput, Dikirim, Selesai</em>).
                        </td>
                    </tr>
                    <tr>
                        <td><strong>💳 Payment Webhook URL</strong><br><small style="color:#646970;">(Callback Pembayaran VA/QRIS)</small></td>
                        <td>Otomatis oleh Plugin</td>
                        <td><span style="color:#135e96; font-weight:600;">✕ TIDAK PERLU</span></td>
                        <td>
                            Plugin <strong>otomatis menyisipkan URL ini</strong> pada setiap pembuatan tagihan pembayaran (<em>create payment</em>). Komerce akan langsung merespons ke URL tersebut ketika status pembayaran terbayar (<em>PAID</em>).
                        </td>
                    </tr>
                    <tr>
                        <td><strong>🔒 Callback API Key</strong><br><small style="color:#646970;">(Webhook Secret)</small></td>
                        <td>Di-generate di <strong>WooCommerce ini</strong></td>
                        <td><span style="color:#135e96; font-weight:600;">✕ TIDAK PERLU</span></td>
                        <td>
                            Kunci rahasia HMAC-SHA256 untuk memvalidasi bahwa callback pembayaran benar-benar dari Komerce. <strong>Cukup klik "Generate Baru" di form bawah</strong>. Token ini otomatis dikirim saat request pembayaran.
                        </td>
                    </tr>
                    <tr>
                        <td><strong>🔑 API Keys</strong><br><small style="color:#646970;">(Tariff, Order, Payment)</small></td>
                        <td>Disalin ke <strong>WooCommerce ini</strong></td>
                        <td><span style="color:#1a7f37; font-weight:600;">Dibuat di Collaborator</span></td>
                        <td>
                            Generate API Key di Dashboard Collaborator (Menu API Key), lalu salin ke kolom input <strong>API Keys</strong> di form bawah ini.
                        </td>
                    </tr>
                    <tr>
                        <td><strong>📦 Shipper &amp; Origin ID</strong><br><small style="color:#646970;">(Lokasi &amp; Kontak Toko)</small></td>
                        <td>Diisi di <strong>WooCommerce ini</strong></td>
                        <td><span style="color:#646970;">-</span></td>
                        <td>
                            Alamat dan nomor telepon toko untuk penjemputan paket kurir (pickup) serta Origin ID (ID Kecamatan asal) untuk kalkulasi ongkir.
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <form method="post" action="options.php">
            <?php settings_fields( 'komerce_settings_group' ); ?>
            <table class="form-table">
                <tr><th colspan="2"><hr><strong>🔑 API Keys (Disalin dari Dashboard Collaborator)</strong></th></tr>
                <tr>
                    <th>API Key Shipping Delivery<br><small style="font-weight:normal;color:#646970;">(Order &amp; Cek Ongkir)</small></th>
                    <td>
                        <input type="password" name="komerce_settings[api_key_order]" value="<?php echo esc_attr( $opts['api_key_order'] ?? '' ); ?>" class="regular-text" autocomplete="off" />
                        <p class="description">
                            Digunakan untuk <strong>seluruh fitur pengiriman</strong>: Cek Ongkir (<code>/tariff/</code>), Pencarian Kecamatan, Buat Order (<code>/order/</code>), Lacak Resi, Pickup, &amp; Cetak Label.
                        </p>
                        <p class="description"><em>Salin dari <strong>Shipping Delivery</strong> di menu API Key Dashboard Collaborator.</em></p>
                    </td>
                </tr>
                <tr>
                    <th>API Key Payment<br><small style="font-weight:normal;color:#646970;">(Virtual Account &amp; QRIS)</small></th>
                    <td>
                        <input type="password" name="komerce_settings[api_key_payment]" value="<?php echo esc_attr( $opts['api_key_payment'] ?? '' ); ?>" class="regular-text" autocomplete="off" />
                        <p class="description">
                            Digunakan untuk pembayaran otomatis: Buat Tagihan VA/QRIS (<code>/user/</code>), Cek Status Pembayaran, &amp; Metode Pembayaran.
                        </p>
                        <p class="description"><em>Salin dari <strong>Payment API</strong> di Dashboard Collaborator (jika sama dengan Shipping Delivery, isi dengan key yang sama).</em></p>
                    </td>
                </tr>

                <tr><th colspan="2"><hr><strong>⚙️ Pengaturan Umum &amp; Keamanan Webhook</strong></th></tr>
                <tr>
                    <th>Sandbox Mode</th>
                    <td><label><input type="checkbox" name="komerce_settings[sandbox_mode]" value="yes" <?php checked( $opts['sandbox_mode'] ?? '', 'yes' ); ?> /> Gunakan sandbox API (Development / Testing)</label></td>
                </tr>
                <tr>
                    <th>Auto-Create Order</th>
                    <td><label><input type="checkbox" name="komerce_settings[auto_create_order]" value="yes" <?php checked( $opts['auto_create_order'] ?? '', 'yes' ); ?> /> Buat order pengiriman otomatis saat pembayaran terkonfirmasi</label>
                        <p class="description">Jika nonaktif, order pengiriman dibuat manual dari meta box pesanan atau via AJAX.</p>
                    </td>
                </tr>
                <tr>
                    <th>Callback API Key<br><small style="font-weight:normal;color:#646970;">(Payment Webhook Secret)</small></th>
                    <td>
                        <?php $secret = $opts['webhook_secret'] ?? ''; ?>
                        <div style="display:flex; align-items:center; gap:6px; margin-bottom:6px;">
                            <input type="text" id="komerce-webhook-secret" name="komerce_settings[webhook_secret]" value="<?php echo esc_attr( $secret ); ?>" class="regular-text code" autocomplete="off" spellcheck="false" />
                            <button type="button" class="button" id="komerce-generate-secret">Generate Baru</button>
                            <button type="button" class="button" id="komerce-copy-secret">Salin</button>
                        </div>
                        <p class="description">
                            Kunci rahasia untuk menandatangani dan memvalidasi callback pembayaran (HMAC-SHA256).
                        </p>
                        <p class="description" style="color:#135e96;">
                            ℹ️ <strong>Tidak perlu dimasukkan ke Dashboard Collaborator</strong>. Plugin akan otomatis menyertakan kunci ini dalam payload API saat customer checkout.
                        </p>
                        <?php if ( '' === trim( (string) $secret ) ) : ?>
                            <p class="description" style="color:#b32d2e;">
                                <strong>⚠ Belum diisi.</strong> Klik <strong>"Generate Baru"</strong> lalu klik <strong>"Simpan Pengaturan"</strong> agar callback pembayaran dapat diverifikasi dengan aman.
                            </p>
                        <?php endif; ?>
                        <script>
                        (function(){
                            var input = document.getElementById('komerce-webhook-secret');
                            document.getElementById('komerce-generate-secret').addEventListener('click', function(){
                                if (input.value && !confirm('Ganti Callback API Key? Pembayaran VA/QRIS yang masih menunggu pembayaran berpotensi gagal verifikasi callback-nya.')) {
                                    return;
                                }
                                var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
                                var bytes = new Uint32Array(40);
                                window.crypto.getRandomValues(bytes);
                                var out = '';
                                for (var i = 0; i < bytes.length; i++) {
                                    out += chars[bytes[i] % chars.length];
                                }
                                input.value = out;
                                input.focus();
                                input.select();
                            });
                            document.getElementById('komerce-copy-secret').addEventListener('click', function(){
                                input.select();
                                navigator.clipboard.writeText(input.value).then(function(){
                                    alert('Callback API Key disalin ke clipboard.');
                                });
                            });
                        })();
                        </script>
                    </td>
                </tr>

                <tr>
                    <th>Custom Webhook URL<br><small style="font-weight:normal;color:#646970;">(Tunnel / Localhost / Ngrok)</small></th>
                    <td>
                        <?php $custom_wh = $opts['custom_webhook_url'] ?? ''; ?>
                        <input type="url" name="komerce_settings[custom_webhook_url]" value="<?php echo esc_attr( $custom_wh ); ?>" class="regular-text code" placeholder="https://xxxx.trycloudflare.com/wc-api/komerce-webhook" />
                        <p class="description">
                            <strong>Gunakan jika website berjalan di localhost</strong> (Local by Flywheel / Laragon / XAMPP) dan menggunakan tunnel publik (seperti <em>Cloudflare Tunnel</em>, <em>Ngrok</em>, atau domain staging HTTPS).
                        </p>
                        <p class="description">
                            <em>Jika diisi, URL ini yang akan dikirimkan ke Komerce Payment API dan yang harus didaftarkan di Dashboard Collaborator. Jika dikosongkan, otomatis menggunakan URL default WordPress.</em>
                        </p>
                    </td>
                </tr>

                <tr><th colspan="2"><hr><strong>📦 Shipper (Data Pengirim / Asal)</strong></th></tr>
                <tr>
                    <th>Nama Pengirim</th>
                    <td><input type="text" name="komerce_settings[shipper_name]" value="<?php echo esc_attr( $opts['shipper_name'] ?? '' ); ?>" class="regular-text" /></td>
                </tr>
                <tr>
                    <th>Nomor Telepon</th>
                    <td>
                        <input type="text" name="komerce_settings[shipper_phone]" value="<?php echo esc_attr( $opts['shipper_phone'] ?? '' ); ?>" class="regular-text" />
                        <p class="description">Format standar: <code>08123456789</code> atau <code>628123456789</code> (tanpa tanda <code>+</code>).</p>
                    </td>
                </tr>
                <tr>
                    <th>Alamat Lengkap</th>
                    <td><textarea name="komerce_settings[shipper_address]" rows="3" class="large-text"><?php echo esc_textarea( $opts['shipper_address'] ?? '' ); ?></textarea></td>
                </tr>
                <tr>
                    <th>Origin ID (Kecamatan Asal)</th>
                    <td><input type="text" name="komerce_settings[origin_id]" value="<?php echo esc_attr( $opts['origin_id'] ?? '' ); ?>" class="regular-text" />
                        <p class="description">ID kecamatan asal pengirim (destination ID) dari pencarian kecamatan Komerce.</p>
                    </td>
                </tr>
                <tr>
                    <th colspan="2" style="padding-top:20px; font-size:15px; border-bottom:1px solid #c3c4c7;">
                        <strong>Pengaturan Pickup Kurir (Default)</strong>
                    </th>
                </tr>
                <tr>
                    <th>Waktu Pickup Default</th>
                    <td>
                        <input type="time" name="komerce_settings[pickup_default_time]" value="<?php echo esc_attr( $opts['pickup_default_time'] ?? '16:00' ); ?>" class="regular-text" style="max-width:140px;" />
                        <p class="description">Jam default penjemputan paket oleh kurir (misal: 14:00, 16:00).</p>
                    </td>
                </tr>
                <tr>
                    <th>Kendaraan Penjemputan Default</th>
                    <td>
                        <select name="komerce_settings[pickup_default_vehicle]">
                            <option value="Motor" <?php selected( $opts['pickup_default_vehicle'] ?? 'Motor', 'Motor' ); ?>>Motor</option>
                            <option value="Mobil" <?php selected( $opts['pickup_default_vehicle'] ?? 'Motor', 'Mobil' ); ?>>Mobil</option>
                        </select>
                        <p class="description">Tipe armada penjemputan default kurir.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button( 'Simpan Pengaturan' ); ?>
        </form>

        <hr>
        <h3>Informasi Sistem &amp; Webhook Endpoint</h3>
        <table class="form-table">
            <tr>
                <th>Webhook Endpoint URL</th>
                <td>
                    <?php
                    $webhook_url   = rajaongkir_get_webhook_url();
                    $webhook_check = rajaongkir_check_webhook_reachable();
                    ?>
                    <div style="display:flex; align-items:center; gap:8px; margin-bottom:8px;">
                        <code id="komerce-webhook-url-val" style="font-size:13px; padding:6px 10px; background:#f0f0f1; border-radius:4px;"><?php echo esc_html( $webhook_url ); ?></code>
                        <button type="button" class="button" id="komerce-copy-webhook-url">Salin Webhook URL</button>
                        <?php if ( ! empty( $opts['custom_webhook_url'] ) ) : ?>
                            <span style="font-size:11px; background:#dbeafe; color:#1e40af; padding:3px 8px; border-radius:4px; font-weight:600;">Custom URL Active</span>
                        <?php endif; ?>
                    </div>
                    <script>
                    document.getElementById('komerce-copy-webhook-url').addEventListener('click', function(){
                        var url = document.getElementById('komerce-webhook-url-val').innerText;
                        navigator.clipboard.writeText(url).then(function(){
                            alert('Webhook URL disalin: ' + url + '\n\nSilakan daftarkan URL ini di Dashboard Collaborator (Menu Webhook/Integrasi).');
                        });
                    });
                    </script>
                    <p class="description">
                        Endpoint ini menangani 2 jenis webhook secara terintegrasi:
                    </p>
                    <ul class="description" style="margin:4px 0 8px 18px;list-style:disc;">
                        <li><strong>1. Pengiriman &amp; Resi (Shipping Webhook):</strong> <strong style="color:#d63638;">[Wajib diinput ke Collaborator]</strong> Daftarkan URL di atas ke <strong>Dashboard Collaborator</strong> agar nomor resi (AWB) dan status kurir otomatis tersinkron ke pesanan WooCommerce.</li>
                        <li><strong>2. Pembayaran VA/QRIS (Payment Webhook):</strong> <strong style="color:#135e96;">[Otomatis]</strong> URL ini dikirim otomatis setiap customer checkout. Tidak perlu didaftarkan manual di Collaborator.</li>
                    </ul>
                    <?php if ( ! $webhook_check['ok'] ) : ?>
                        <p class="description" style="color:#b32d2e; background:#fcf0f0; padding:8px 12px; border-left:3px solid #d63638; border-radius:3px;">
                            <strong>⚠ Perhatian (Lokal / Non-HTTPS):</strong>
                            <?php echo esc_html( $webhook_check['reason'] ); ?><br>
                            Untuk pengujian di localhost, gunakan tunnel HTTPS publik (seperti <code>cloudflared tunnel</code> atau <code>ngrok</code>).
                        </p>
                    <?php else : ?>
                        <p class="description" style="color:#1a7f37; font-weight:600;">✓ URL dapat dijangkau publik melalui HTTPS.</p>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Status Callback API Key</th>
                <td>
                    <?php $has_secret = '' !== trim( (string) rajaongkir_get_webhook_secret() ); ?>
                    <?php echo $has_secret
                        ? '<span style="color:#16a34a; font-weight:600;">✓ Terisi — Callback pembayaran diverifikasi HMAC-SHA256</span>'
                        : '<span style="color:#dc2626; font-weight:600;">✗ Belum diisi — Callback pembayaran akan ditolak demi keamanan</span>'; ?>
                </td>
            </tr>
            <tr><th>Environment</th><td><strong><?php echo esc_html( $api->get_environment() ); ?></strong></td></tr>
            <tr><th>Plugin Version</th><td><code><?php echo esc_html( KOMERCE_VERSION ); ?></code></td></tr>
            <tr>
                <th>API Key Shipping Delivery</th>
                <td><?php echo $order_ok ? '<span style="color:#16a34a">✓ Terkonfigurasi</span>' : '<span style="color:#dc2626">✗ Belum diisi</span>'; ?></td>
            </tr>
            <tr>
                <th>API Key Payment</th>
                <td><?php echo $payment_ok ? '<span style="color:#16a34a">✓ Terkonfigurasi</span>' : '<span style="color:#dc2626">✗ Belum diisi</span>'; ?></td>
            </tr>
        </table>

        <p><button type="button" class="button" onclick="if(confirm('Clear semua cache Komerce?')){jQuery.post(ajaxurl,{action:'komerce_clear_cache',nonce:'<?php echo esc_js( wp_create_nonce( 'komerce_clear_cache' ) ); ?>'},function(r){alert(r.data||'Done')})}">Clear Cache</button></p>

        <hr>
        <h3>Webhook Events Terakhir</h3>
        <?php $events = Komerce_Logger::get_webhook_log( 20 ); ?>
        <?php if ( empty( $events ) ) : ?>
            <p><em>Belum ada event webhook yang tercatat.</em></p>
        <?php else : ?>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th style="width:160px;">Waktu</th>
                        <th style="width:100px;">Event</th>
                        <th style="width:80px;">Level</th>
                        <th>Pesan</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ( $events as $e ) : ?>
                    <tr>
                        <td><?php echo esc_html( $e['time'] ?? '' ); ?></td>
                        <td><code><?php echo esc_html( $e['event'] ?? '' ); ?></code></td>
                        <td><?php echo esc_html( $e['level'] ?? '' ); ?></td>
                        <td>
                            <?php echo esc_html( $e['message'] ?? '' ); ?>
                            <?php if ( ! empty( $e['context'] ) ) : ?>
                                <br><small><code><?php echo esc_html( wp_json_encode( $e['context'] ) ); ?></code></small>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        <p class="description">Log lengkap tersedia di <strong>WooCommerce &gt; Status &gt; Logs</strong> (source: <code>komerce</code>).</p>
    </div>
    <?php
}
endif;

// ── Clear cache AJAX ──

add_action( 'wp_ajax_komerce_clear_cache', function () {
    check_ajax_referer( 'komerce_clear_cache', 'nonce' );
    if ( ! current_user_can( 'manage_woocommerce' ) ) {
        wp_send_json_error( 'Unauthorized' );
    }
    Komerce_API_Client::clear_cache();
    wp_send_json_success( 'Cache dibersihkan' );
} );

// ── HPOS compatibility ──

add_action( 'before_woocommerce_init', function () {
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
    }
} );

// ── Plugin action links ──

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
    $settings = '<a href="' . admin_url( 'admin.php?page=komerce-settings' ) . '">Settings</a>';
    array_unshift( $links, $settings );
    return $links;
} );

/**
 * Formats a WooCommerce order into a comprehensive data structure for theme consumption.
 *
 * @param WC_Order|int $order
 * @return array
 */
if ( ! function_exists( 'komerce_format_order_payload' ) ) :
function komerce_format_order_payload( $order ) {
    if ( is_numeric( $order ) ) {
        $order = wc_get_order( (int) $order );
    }
    if ( ! $order instanceof WC_Order ) {
        return array();
    }

    $komerce_no = (string) $order->get_meta( '_komerce_order_no' );
    if ( '' === $komerce_no ) {
        $komerce_no = (string) $order->get_meta( '_rajaongkir_order_no' );
    }
    if ( '' === $komerce_no ) {
        $komerce_no = (string) $order->get_order_number();
    }

    $courier = (string) $order->get_meta( '_komerce_courier' );
    $service = (string) $order->get_meta( '_komerce_service' );
    $awb     = (string) $order->get_meta( '_komerce_awb' ) ?: (string) $order->get_meta( '_rajaongkir_airway_bill' );

    $est_delivery = '2-3 business days';
    if ( $courier || $service ) {
        $est_delivery = strtoupper( $courier ) . ( $service ? ' - ' . $service : '' );
    }

    // Items list (order details)
    $items = array();
    foreach ( $order->get_items() as $item ) {
        $product  = $item->get_product();
        $qty      = max( 1, (int) $item->get_quantity() );
        $subtotal = (int) round( (float) $item->get_subtotal() );
        $price    = (int) round( $subtotal / $qty );

        $image_url = '';
        if ( $product ) {
            $img_id = $product->get_image_id();
            if ( $img_id ) {
                $image_url = wp_get_attachment_image_url( $img_id, 'thumbnail' ) ?: '';
            }
            if ( ! $image_url ) {
                $image_url = wc_placeholder_img_src();
            }
        }

        $items[] = array(
            'id'                 => $item->get_id(),
            'product_id'         => $item->get_product_id(),
            'name'               => $item->get_name(),
            'quantity'           => $qty,
            'price'              => $price,
            'price_formatted'    => 'Rp' . number_format_i18n( $price ),
            'subtotal'           => $subtotal,
            'subtotal_formatted' => 'Rp' . number_format_i18n( $subtotal ),
            'image_url'          => $image_url,
            'sku'                => $product ? $product->get_sku() : '',
        );
    }

    $status  = $order->get_status();
    $is_paid = in_array( $status, array( 'processing', 'completed' ), true );

    $total_amount    = (int) round( (float) $order->get_total() );
    $subtotal_amount = (int) round( (float) $order->get_subtotal() );
    $shipping_amount = (int) round( (float) $order->get_shipping_total() );
    $discount_amount = (int) round( (float) $order->get_discount_total() );

    $receiver_name = trim( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() );
    if ( '' === $receiver_name ) {
        $receiver_name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
    }

    return array(
        'paid'               => $is_paid,
        'status'             => $status,
        'order_id'           => $order->get_id(),
        'order_key'          => $order->get_order_key(),
        'order_number'       => '#' . $komerce_no,
        'order_no'           => $komerce_no,
        'order_date'         => date_i18n( 'j F Y', strtotime( (string) $order->get_date_created() ) ),
        'order_date_raw'     => (string) $order->get_date_created(),
        'total_amount'       => $total_amount,
        'total_formatted'    => 'Rp' . number_format_i18n( $total_amount ),
        'subtotal_amount'    => $subtotal_amount,
        'subtotal_formatted' => 'Rp' . number_format_i18n( $subtotal_amount ),
        'shipping_amount'    => $shipping_amount,
        'shipping_formatted' => 'Rp' . number_format_i18n( $shipping_amount ),
        'discount_amount'    => $discount_amount,
        'discount_formatted' => 'Rp' . number_format_i18n( $discount_amount ),
        'payment_method'     => $order->get_payment_method_title() ?: 'Bank Transfer',
        'courier'            => $courier,
        'service'            => $service,
        'est_delivery'       => $est_delivery,
        'awb'                => $awb,
        'airway_bill'        => $awb,
        'billing_email'      => $order->get_billing_email(),
        'billing_phone'      => $order->get_billing_phone(),
        'receiver_name'      => $receiver_name,
        'shipping_address'   => $order->get_formatted_shipping_address() ?: $order->get_formatted_billing_address(),
        'order_url'          => $order->get_view_order_url() ?: home_url( '/my-account/orders/' ),
        'track_order_url'    => $order->get_view_order_url() ?: home_url( '/my-account/orders/' ),
        'track_url'          => $order->get_view_order_url() ?: home_url( '/my-account/orders/' ),
        'view_order_url'     => $order->get_view_order_url() ?: home_url( '/my-account/orders/' ),
        'items'              => $items,
        'order_details'      => $items,
    );
}
endif;

/**
 * Local order status checker (pure local DB query - 0 external API calls).
 * Returns complete order data for the theme to consume and render Step 5.
 */
if ( ! function_exists( 'komerce_check_local_order_status_handler' ) ) :
function komerce_check_local_order_status_handler() {
    $order_id  = absint( $_POST['order_id'] ?? 0 );
    $order_key = sanitize_text_field( $_POST['order_key'] ?? '' );

    if ( ! $order_id ) {
        wp_send_json_error( 'Missing order_id' );
    }

    $order = wc_get_order( $order_id );
    if ( ! $order ) {
        wp_send_json_error( 'Order not found' );
    }

    if ( $order_key && $order->get_order_key() !== $order_key ) {
        wp_send_json_error( 'Unauthorized' );
    }

    $payload = komerce_format_order_payload( $order );
    wp_send_json_success( $payload );
}
endif;
