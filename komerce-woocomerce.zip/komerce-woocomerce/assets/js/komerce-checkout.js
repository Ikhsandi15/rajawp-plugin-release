/**
 * Komerce Checkout JS
 *
 * Select2 AJAX destination search + dynamic shipping rate update.
 */
(function ($) {
  'use strict';

  if (typeof komerce_checkout === 'undefined') return;

  var cfg = komerce_checkout;

  function initDestinationSearch(selector) {
    var $select = $(selector);
    if (!$select.length) return;

    $select.select2({
      placeholder: 'Ketik kecamatan / kota...',
      minimumInputLength: cfg.min_chars || 3,
      allowClear: true,
      ajax: {
        url: cfg.ajax_url,
        type: 'POST',
        dataType: 'json',
        delay: 400,
        data: function (params) {
          return {
            action: 'komerce_search_destination',
            nonce: cfg.nonce,
            keyword: params.term,
          };
        },
        processResults: function (response) {
          if (!response.success) return { results: [] };
          return {
            results: response.data.map(function (item) {
              return { id: item.id, text: item.text, meta: item };
            }),
          };
        },
        cache: true,
      },
    });

    $select.on('select2:select', function (e) {
      var data = e.params.data;
      var prefix = selector.indexOf('shipping') !== -1 ? 'shipping' : 'billing';

      // Set hidden field, creating it if not present in the DOM
      var $hidden = $('#' + prefix + '_komerce_destination_id');
      if ($hidden.length) {
        $hidden.val(data.id);
      } else {
        $('<input type="hidden">')
          .attr({
            name: prefix + '_komerce_destination_id',
            id: prefix + '_komerce_destination_id',
          })
          .val(data.id)
          .appendTo('form.checkout');
      }

      // Sync both billing and shipping hidden fields
      $('#billing_komerce_destination_id').val(data.id);
      $('#shipping_komerce_destination_id').val(data.id);

      // Auto-fill postcode, city, state if available (without premature change trigger)
      if (data.meta) {
        if (data.meta.postal_code) {
          $('#' + prefix + '_postcode').val(data.meta.postal_code);
        }
        if (data.meta.city_name) {
          $('#' + prefix + '_city').val(data.meta.city_name);
        }
        if (data.meta.province_name) {
          $('#' + prefix + '_state').val(data.meta.province_name);
        }
      }

      // Save destination to session first, then trigger WooCommerce checkout update
      $.post(cfg.ajax_url, {
        action: 'komerce_save_destination',
        nonce: cfg.nonce,
        destination_id: data.id,
      }).always(function () {
        if (data.meta && data.meta.postal_code) {
          $('#' + prefix + '_postcode').trigger('change');
        }
        $('body').trigger('update_checkout');
      });
    });

    $select.on('select2:clear', function () {
      var prefix = selector.indexOf('shipping') !== -1 ? 'shipping' : 'billing';
      $('#' + prefix + '_komerce_destination_id').val('');
      $('body').trigger('update_checkout');
    });
  }

  // Init on document ready.
  $(function () {
    initDestinationSearch('#billing_komerce_destination');
    initDestinationSearch('#shipping_komerce_destination');
  });

  // Re-init after checkout update (WooCommerce re-renders fields).
  $(document.body).on('updated_checkout', function () {
    if ($('#billing_komerce_destination').data('select2')) return;
    initDestinationSearch('#billing_komerce_destination');
    initDestinationSearch('#shipping_komerce_destination');
  });

  // ── Place Order: Open invoice in New Tab & notify Theme when Paid ──
  var newTabWindow = null;

  // Pre-open new tab on place order button click to bypass browser popup blockers
  $(document).on('click', 'form.checkout #place_order, form.checkout button[type="submit"]', function () {
    var selectedMethod = $('input[name="payment_method"]:checked').val();
    if (!selectedMethod || selectedMethod === 'komerce_payment') {
      try {
        newTabWindow = window.open('about:blank', '_blank');
      } catch (e) {
        newTabWindow = null;
      }
    }
  });

  // Intercept checkout AJAX response
  $(document).ajaxSuccess(function (event, xhr, settings) {
    if (settings.url && settings.url.indexOf('wc-ajax=checkout') !== -1) {
      try {
        var data = typeof xhr.responseJSON !== 'undefined' ? xhr.responseJSON : JSON.parse(xhr.responseText);
        if (data && (data.result === 'komerce_success' || data.result === 'success' || data.status === 'success')) {
          var payUrl = data.payment_url || '';

          // Redirect the new tab to invoice URL
          if (payUrl) {
            if (newTabWindow && !newTabWindow.closed) {
              newTabWindow.location.href = payUrl;
            } else {
              window.open(payUrl, '_blank');
            }
          }

          // Expose created order data globally and dispatch event for theme consumption
          window.komerce_order_created_data = data;
          window.komerce_order_data = data;
          $(document.body).trigger('komerce_order_created', [data]);

          var orderId = data.order_id || 0;
          var orderKey = data.order_key || '';

          if (orderId) {
            var isResolved = false;

            function checkLocalStatus() {
              if (isResolved) return;
              $.post(cfg.ajax_url, {
                action: 'komerce_check_local_order_status',
                order_id: orderId,
                order_key: orderKey,
                nonce: cfg.nonce
              }, function (res) {
                if (res.success && res.data && res.data.paid) {
                  isResolved = true;
                  clearInterval(pollInterval);
                  // Populate global data and emit events for theme consumption (NO plugin UI injected)
                  window.komerce_order_data = res.data;
                  $(document.body).trigger('komerce_order_paid', [res.data]);
                  $(document.body).trigger('komerce_checkout_step_5', [res.data]);
                }
              });
            }

            // Check immediately when user switches back to this tab
            $(window).on('focus', checkLocalStatus);
            document.addEventListener('visibilitychange', function () {
              if (document.visibilityState === 'visible') {
                checkLocalStatus();
              }
            });

            // Gentle local check (queries local MySQL DB only, 0 external API calls)
            var pollInterval = setInterval(checkLocalStatus, 3000);
          }
        }
      } catch (e) { }
    }
  });
})(jQuery);
