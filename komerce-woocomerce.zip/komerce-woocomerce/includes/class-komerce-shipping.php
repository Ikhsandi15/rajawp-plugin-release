<?php
/**
 * Komerce Shipping Method
 *
 * WooCommerce shipping method — real-time tariff via Komerce OpenAPI.
 * Multi-courier, subdistrict, COD, free-shipping threshold.
 *
 * @package WooCommerce\Komerce
 * @since   2.2.0
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'WC_Shipping_Method' ) && ! class_exists( 'WC_Komerce_Shipping' ) ) :
class WC_Komerce_Shipping extends WC_Shipping_Method {

    private $api;

    const COURIERS = array(
        'jne'        => 'JNE',
        'jnt'        => 'J&T Express',
        'sicepat'    => 'SiCepat',
        'anteraja'   => 'AnterAja',
        'ninja'      => 'Ninja Express',
        'lion'       => 'Lion Parcel',
        'idexpress'  => 'ID Express',
        'spx'        => 'Shopee Express',
        'pos'        => 'POS Indonesia',
        'tiki'       => 'TIKI',
        'rpx'        => 'RPX',
        'sap'        => 'SAP Express',
    );

    public function __construct( $instance_id = 0 ) {
        $this->id                 = 'komerce_shipping';
        $this->instance_id        = absint( $instance_id );
        $this->method_title       = __( 'Komerce Shipping', 'woocommerce' );
        $this->method_description = __( 'Ongkir real-time via Komerce Collaborator OpenAPI.', 'woocommerce' );
        $this->supports           = array( 'shipping-zones', 'instance-settings' );
        $this->enabled            = 'yes';

        $this->init();
        $this->api = Komerce_API_Client::instance();
    }

    public function init() {
        $this->init_form_fields();
        $this->init_settings();
        $this->title = $this->get_option( 'title', 'Komerce Shipping' );

        add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
        add_filter( 'woocommerce_available_payment_gateways', array( $this, 'filter_gateways_for_non_cod' ) );
    }

    public function init_form_fields() {
        $this->instance_form_fields = array(
            'title'           => array(
                'title'   => 'Judul',
                'type'    => 'text',
                'default' => 'Komerce Shipping',
            ),
            'enabled_couriers' => array(
                'title'   => 'Kurir Aktif',
                'type'    => 'multiselect',
                'class'   => 'wc-enhanced-select',
                'css'     => 'min-width:350px;',
                'default' => array( 'jne', 'jnt', 'sicepat' ),
                'options' => self::COURIERS,
            ),
            'origin_id' => array(
                'title'       => 'ID Asal Pengiriman',
                'type'        => 'text',
                'description' => 'ID kecamatan asal (shipper_destination_id) dari destination search API.',
                'desc_tip'    => true,
            ),
            'origin_label' => array(
                'title'    => 'Label Asal',
                'type'     => 'text',
                'desc_tip' => true,
            ),
            'enable_cod' => array(
                'title'       => 'Metode Pengiriman',
                'type'        => 'title',
                'description' => '<strong>Khusus Non-COD:</strong> Pengiriman saat ini hanya mendukung Non-COD (COD belum didukung).',
            ),
            'extra_fee' => array(
                'title'   => 'Biaya Tambahan (Rp)',
                'type'    => 'number',
                'default' => 0,
            ),
            'free_shipping_min' => array(
                'title'       => 'Gratis Ongkir Minimum (Rp)',
                'type'        => 'number',
                'default'     => 0,
                'description' => '0 = nonaktif.',
                'desc_tip'    => true,
            ),
        );
    }

    /**
     * Calculate shipping rates via OpenAPI /tariff/api/v1/calculate.
     */
    public function calculate_shipping( $package = array() ) {
        // Do not calculate shipping rates on the cart page (only calculated on checkout when choosing courier).
        if ( function_exists( 'is_cart' ) && is_cart() ) {
            return;
        }

        $origin   = $this->get_option( 'origin_id' );
        $couriers = $this->get_option( 'enabled_couriers', array( 'jne' ) );
        $cod      = false; // Khusus Non-COD (COD belum didukung)
        $extra    = (int) $this->get_option( 'extra_fee', 0 );
        $free_min = (int) $this->get_option( 'free_shipping_min', 0 );

        $debug = defined( 'WP_DEBUG' ) && WP_DEBUG;

        if ( $debug ) {
            error_log( '[Komerce Shipping] calculate_shipping called, instance_id=' . $this->instance_id );
            error_log( '[Komerce Shipping] instance origin_id=' . var_export( $origin, true ) );
            error_log( '[Komerce Shipping] enabled_couriers=' . wp_json_encode( $couriers ) );
        }

        // Fallback origin from global settings.
        if ( empty( $origin ) ) {
            $opts   = get_option( 'komerce_settings', array() );
            $origin = $opts['origin_id'] ?? '';
            if ( $debug ) {
                error_log( '[Komerce Shipping] instance origin empty, global fallback=' . var_export( $origin, true ) );
            }
        }

        if ( empty( $origin ) ) {
            if ( $debug ) {
                error_log( '[Komerce Shipping] ❌ ABORT: origin_id is empty (both instance and global)' );
            }
            return;
        }

        $dest_id = $this->get_destination_id();
        if ( $debug ) {
            error_log( '[Komerce Shipping] destination_id=' . var_export( $dest_id, true ) );
        }

        if ( empty( $dest_id ) ) {
            if ( $debug ) {
                error_log( '[Komerce Shipping] ❌ ABORT: destination_id is empty (no POST data, no session)' );
            }
            return;
        }

        $weight     = $this->calc_weight( $package );
        $cart_total = WC()->cart ? (int) WC()->cart->get_subtotal() : 0;
        $free       = ( $free_min > 0 && $cart_total >= $free_min );

        // OpenAPI calculate uses query params:
        // shipper_destination_id, receiver_destination_id, weight (kg), item_value, cod
        // Weight is sent as decimal kilograms (dot separator) per the API docs.
        $params = array(
            'shipper_destination_id'  => $origin,
            'receiver_destination_id' => $dest_id,
            'weight'                  => rajaongkir_grams_to_kg( $weight ), // gram → kg (decimal)
            'item_value'              => $cart_total,
            'cod'                     => 'no', // Strictly Non-COD
        );

        if ( $debug ) {
            error_log( '[Komerce Shipping] API params=' . wp_json_encode( $params ) );
        }

        $resp = $this->api->calculate_cost( $params );

        if ( is_wp_error( $resp ) ) {
            if ( $debug ) {
                error_log( '[Komerce Shipping] ❌ API error: ' . $resp->get_error_message() );
            }
            return;
        }

        if ( $debug ) {
            error_log( '[Komerce Shipping] ✅ API response keys=' . wp_json_encode( array_keys( $resp ) ) );
            error_log( '[Komerce Shipping] API response (truncated)=' . substr( wp_json_encode( $resp ), 0, 1000 ) );
        }

        $this->parse_rates( $resp, $couriers, $extra, $free, $cod );
    }

    private function get_destination_id() {
        // phpcs:disable WordPress.Security.NonceVerification
        $keys = array(
            'billing_komerce_destination',
            'billing_komerce_destination_id',
            'shipping_komerce_destination',
            'shipping_komerce_destination_id',
            'billing_destination',
            'destination_id',
            'komerce_destination_id',
            'billing_city',
        );

        // 1. Check direct $_POST
        foreach ( $keys as $k ) {
            if ( ! empty( $_POST[ $k ] ) ) {
                $val = sanitize_text_field( wp_unslash( $_POST[ $k ] ) );
                if ( is_numeric( $val ) && (int) $val > 0 ) {
                    if ( WC()->session && is_callable( array( WC()->session, 'set' ) ) ) {
                        WC()->session->set( 'komerce_destination_id', (string) $val );
                    }
                    if ( WC()->customer && is_callable( array( WC()->customer, 'update_meta_data' ) ) ) {
                        WC()->customer->update_meta_data( 'billing_komerce_destination_id', (string) $val );
                        WC()->customer->update_meta_data( 'shipping_komerce_destination_id', (string) $val );
                    }
                    return (string) $val;
                }
            }
        }

        // 2. Check serialized post_data from WooCommerce AJAX update_order_review
        if ( ! empty( $_POST['post_data'] ) ) {
            parse_str( (string) $_POST['post_data'], $parsed );
            if ( is_array( $parsed ) ) {
                foreach ( $keys as $k ) {
                    if ( ! empty( $parsed[ $k ] ) ) {
                        $val = sanitize_text_field( wp_unslash( $parsed[ $k ] ) );
                        if ( is_numeric( $val ) && (int) $val > 0 ) {
                            if ( WC()->session && is_callable( array( WC()->session, 'set' ) ) ) {
                                WC()->session->set( 'komerce_destination_id', (string) $val );
                            }
                            if ( WC()->customer && is_callable( array( WC()->customer, 'update_meta_data' ) ) ) {
                                WC()->customer->update_meta_data( 'billing_komerce_destination_id', (string) $val );
                                WC()->customer->update_meta_data( 'shipping_komerce_destination_id', (string) $val );
                            }
                            return (string) $val;
                        }
                    }
                }
            }
        }
        // phpcs:enable

        // 3. Fallback to active WC session
        if ( WC()->session && is_callable( array( WC()->session, 'get' ) ) ) {
            $v = WC()->session->get( 'komerce_destination_id' );
            if ( ! empty( $v ) && is_numeric( $v ) && (int) $v > 0 ) {
                return (string) $v;
            }
        }
        return '';
    }

    /**
     * Total package weight in grams.
     *
     * Handles store units (kg, g) and guards against double-scaled weights.
     */
    private function calc_weight( $package ) {
        $total = 0;
        $unit  = get_option( 'woocommerce_weight_unit', 'kg' );
        $m     = rajaongkir_weight_multiplier();

        if ( ! empty( $package['contents'] ) ) {
            foreach ( $package['contents'] as $item ) {
                if ( empty( $item['data'] ) ) {
                    continue;
                }
                $raw_w = (float) $item['data']->get_weight();
                if ( $raw_w <= 0 ) {
                    $raw_w = 1.0;
                }
                // If unit is kg but value entered was >= 50 (e.g. 250, 500, 1000), it is in grams
                if ( 'kg' === $unit && $raw_w >= 50 ) {
                    $total += $raw_w * (int) $item['quantity'];
                } else {
                    $total += $raw_w * $m * (int) $item['quantity'];
                }
            }
        }

        return max( (int) ceil( $total ), 1000 ); // minimum 1000g = 1kg
    }

    /**
     * Parse OpenAPI calculate response into WooCommerce shipping rates.
     *
     * Tariff-service response format:
     *   { "meta": {...}, "data": {
     *       "calculate_reguler": [ { shipping_name, service_name, shipping_cost, ... }, ... ],
     *       "calculate_cargo":   [ ... ],
     *       "calculate_instant": [ ... ]
     *   }}
     *
     * Each item has: shipping_name, service_name, weight, is_cod, shipping_cost,
     * shipping_cashback, shipping_cost_net, grandtotal, service_fee, net_income, etd.
     */
    private function parse_rates( $response, $enabled_couriers, $extra, $free, $cod ) {
        $debug = defined( 'WP_DEBUG' ) && WP_DEBUG;

        // Extract data wrapper from API response.
        $data = array();
        if ( isset( $response['data'] ) && is_array( $response['data'] ) ) {
            $data = $response['data'];
        }

        // Collect all shipping options from the three categories.
        $categories = array(
            'reguler' => $data['calculate_reguler'] ?? array(),
            'cargo'   => $data['calculate_cargo']   ?? array(),
            'instant' => $data['calculate_instant']  ?? array(),
        );

        $rate_count = 0;

        foreach ( $categories as $category => $items ) {
            if ( ! is_array( $items ) ) {
                continue;
            }

            foreach ( $items as $item ) {
                // shipping_name = "JNE", "SICEPAT", "J&T", "SAP", "NINJA", "ID EXPRESS", "LION" etc.
                $shipping_name = $item['shipping_name'] ?? '';
                // service_name = "REG", "OKE", "YES", "BEST", "CARGO", "SDS", "HDS", etc.
                $service_name  = $item['service_name']  ?? '';
                $shipping_cost = (int) ( $item['shipping_cost'] ?? 0 );
                $cashback      = (int) ( $item['shipping_cashback'] ?? 0 );
                $cost_net      = (int) ( $item['shipping_cost_net'] ?? 0 );
                $etd           = $item['etd'] ?? '';
                $is_cod        = false; // Non-COD only
                $service_fee   = (int) ( $item['service_fee'] ?? 0 );
                $grandtotal    = (int) ( $item['grandtotal'] ?? 0 );
                $net_income    = (int) ( $item['net_income'] ?? 0 );

                if ( $shipping_cost <= 0 || empty( $shipping_name ) ) {
                    continue;
                }

                // Map shipping_name to internal courier code for filtering.
                $courier_code = $this->normalize_courier_code( $shipping_name );

                // Filter by enabled couriers.
                if ( ! empty( $enabled_couriers ) && ! in_array( $courier_code, (array) $enabled_couriers, true ) ) {
                    continue;
                }

                $courier_label = self::COURIERS[ $courier_code ] ?? $shipping_name;

                $final = $free ? 0 : ( $shipping_cost + $extra );
                $label = "{$courier_label} - {$service_name}";
                if ( $etd ) {
                    $etd_clean = trim( str_ireplace( array( 'hari', 'HARI', 'days' ), '', $etd ) );
                    $label .= " ({$etd_clean} hari)";
                }
                if ( $free ) {
                    $label .= ' ✨ GRATIS';
                }

                $rid = $this->id . ':' . $this->instance_id . ':' . $courier_code . '_' . sanitize_title( $service_name );

                // Map courier_code to order-service shipping code.
                // Order-service expects: JNE, JNT, SICEPAT, SAP, NINJA, IDEXPRESS, LION, GOSEND
                $order_shipping_code = $this->to_order_shipping_code( $courier_code );

                $this->add_rate( array(
                    'id'        => $rid,
                    'label'     => $label,
                    'cost'      => $final,
                    'meta_data' => array(
                        'courier_code'      => $courier_code,
                        'shipping_code'     => $order_shipping_code, // For order-service "shipping" field
                        'service_code'      => $service_name,        // For order-service "shipping_type" field
                        'etd'               => $etd,
                        'original_cost'     => $shipping_cost,
                        'shipping_cashback' => $cashback,
                        'shipping_cost_net' => $cost_net,
                        'service_fee'       => $service_fee,
                        'grandtotal'        => $grandtotal,
                        'net_income'        => $net_income,
                        'category'          => $category,
                    ),
                ) );

                $rate_count++;

                // COD variant.
                if ( $cod && $is_cod ) {
                    $this->add_rate( array(
                        'id'        => $rid . '_cod',
                        'label'     => $label . ' [COD]',
                        'cost'      => $final,
                        'meta_data' => array(
                            'courier_code'      => $courier_code,
                            'shipping_code'     => $order_shipping_code,
                            'service_code'      => $service_name,
                            'etd'               => $etd,
                            'original_cost'     => $shipping_cost,
                            'shipping_cashback' => $cashback,
                            'shipping_cost_net' => $cost_net,
                            'service_fee'       => $service_fee,
                            'grandtotal'        => $grandtotal,
                            'net_income'        => $net_income,
                            'category'          => $category,
                            'is_cod'            => true,
                        ),
                    ) );
                }
            }
        }

        if ( $debug ) {
            error_log( '[Komerce Shipping] parse_rates total rates added: ' . $rate_count );
        }
    }

    /**
     * Normalize shipping_name from tariff-service to internal courier code.
     *
     * @param string $shipping_name e.g. "JNE", "J&T", "SICEPAT", "ID EXPRESS"
     * @return string Internal code e.g. "jne", "jnt", "sicepat", "idexpress"
     */
    private function normalize_courier_code( $shipping_name ) {
        $name = strtolower( trim( $shipping_name ) );
        $map  = array(
            'jne'             => 'jne',
            'j&t'             => 'jnt',
            'j&t express'     => 'jnt',
            'jnt'             => 'jnt',
            'sicepat'         => 'sicepat',
            'anteraja'        => 'anteraja',
            'ninja'           => 'ninja',
            'ninja express'   => 'ninja',
            'lion parcel'     => 'lion',
            'lion'            => 'lion',
            'id express'      => 'idexpress',
            'ide'             => 'idexpress',
            'idexpress'       => 'idexpress',
            'shopee express'  => 'spx',
            'spx'             => 'spx',
            'pos'             => 'pos',
            'pos indonesia'   => 'pos',
            'tiki'            => 'tiki',
            'rpx'             => 'rpx',
            'sap'             => 'sap',
            'sap express'     => 'sap',
            'gosend'          => 'gosend',
        );

        // Exact match first.
        if ( isset( $map[ $name ] ) ) {
            return $map[ $name ];
        }

        // Partial match.
        foreach ( $map as $key => $code ) {
            if ( strpos( $name, $key ) !== false ) {
                return $code;
            }
        }

        return sanitize_title( $name );
    }

    /**
     * Map internal courier code to order-service shipping code.
     *
     * Order-service accepts: JNE, JNT, SICEPAT, SAP, NINJA, IDEXPRESS, LION, GOSEND
     *
     * @param string $courier_code Internal code e.g. "jne", "jnt"
     * @return string Order-service code e.g. "JNE", "JNT"
     */
    private function to_order_shipping_code( $courier_code ) {
        $map = array(
            'jne'       => 'JNE',
            'jnt'       => 'JNT',
            'sicepat'   => 'SICEPAT',
            'sap'       => 'SAP',
            'ninja'     => 'NINJA',
            'idexpress' => 'IDEXPRESS',
            'lion'      => 'LION',
            'gosend'    => 'GOSEND',
        );
        return $map[ $courier_code ] ?? strtoupper( $courier_code );
    }

    /**
     * Disable COD payment gateway if Komerce Shipping is used or selected.
     *
     * @param array $available_gateways
     * @return array
     */
    public function filter_gateways_for_non_cod( $available_gateways ) {
        if ( is_admin() && ! ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {
            return $available_gateways;
        }

        $chosen_methods = ( function_exists( 'WC' ) && WC()->session && is_callable( array( WC()->session, 'get' ) ) )
            ? WC()->session->get( 'chosen_shipping_methods', array() )
            : array();
        $is_komerce = false;

        foreach ( (array) $chosen_methods as $method ) {
            if ( strpos( (string) $method, 'komerce_shipping' ) !== false ) {
                $is_komerce = true;
                break;
            }
        }

        if ( ! $is_komerce && function_exists( 'WC' ) && WC()->cart && is_callable( array( WC()->cart, 'needs_shipping' ) ) && WC()->cart->needs_shipping() && WC()->shipping() ) {
            $packages = WC()->shipping()->get_packages();
            foreach ( $packages as $i => $pkg ) {
                $chosen = $chosen_methods[ $i ] ?? '';
                if ( strpos( (string) $chosen, 'komerce_shipping' ) !== false ) {
                    $is_komerce = true;
                    break;
                }
            }
        }

        if ( $is_komerce && isset( $available_gateways['cod'] ) ) {
            unset( $available_gateways['cod'] );
        }

        return $available_gateways;
    }
}
endif;
