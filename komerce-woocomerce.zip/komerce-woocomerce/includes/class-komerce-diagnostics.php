<?php
/**
 * Komerce Diagnostics
 *
 * Admin page that exercises every acceptance-criteria scenario against the real
 * API, plus a webhook simulator that signs payloads exactly the way RajaOngkir
 * does. Lives under WooCommerce > Komerce Test.
 *
 * Nothing here runs automatically — every check is triggered by a button.
 *
 * @package WooCommerce\Komerce
 * @since   2.3.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Komerce_Diagnostics' ) ) :
class Komerce_Diagnostics {

	const NONCE = 'komerce_diagnostics';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_page' ) );

		// Each test is its own AJAX endpoint so failures stay isolated.
		$tests = array(
			'config',
			'destination',
			'tariff',
			'cart_weight',
			'payment_methods',
			'create_payment',
			'payment_status',
			'webhook_payment',
			'webhook_shipping',
			'place_order',
		);

		foreach ( $tests as $t ) {
			add_action( "wp_ajax_komerce_test_{$t}", array( $this, "test_{$t}" ) );
		}
	}

	public function add_page() {
		add_submenu_page(
			'woocommerce',
			'Komerce Test',
			'Komerce Test',
			'manage_woocommerce',
			'komerce-test',
			array( $this, 'render' )
		);
	}

	// ─────────────────────────────────────────────────────────────────────
	// Helpers
	// ─────────────────────────────────────────────────────────────────────

	private function guard() {
		check_ajax_referer( self::NONCE, 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'Unauthorized' );
		}
	}

	/**
	 * Send a uniform test result.
	 *
	 * @param bool   $ok      Whether the scenario passed.
	 * @param string $summary One-line outcome.
	 * @param array  $detail  Extra rows shown under the summary.
	 * @return void
	 */
	private function result( $ok, $summary, $detail = array() ) {
		wp_send_json_success( array(
			'ok'      => (bool) $ok,
			'summary' => $summary,
			'detail'  => $detail,
			'elapsed' => $this->elapsed(),
		) );
	}

	private $started = 0;

	private function start_timer() {
		$this->started = microtime( true );
	}

	private function elapsed() {
		if ( ! $this->started ) {
			return '';
		}
		return round( ( microtime( true ) - $this->started ) * 1000 ) . ' ms';
	}

	private function param( $key, $default = '' ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : $default;
	}

	/**
	 * Truncate an array for display so responses stay readable.
	 *
	 * @param array $arr   Source.
	 * @param int   $limit Max entries.
	 * @return array
	 */
	private function preview( $arr, $limit = 5 ) {
		if ( ! is_array( $arr ) ) {
			return array();
		}
		$out = array_slice( $arr, 0, $limit );
		if ( count( $arr ) > $limit ) {
			$out[] = sprintf( '… %d lainnya', count( $arr ) - $limit );
		}
		return $out;
	}

	// ─────────────────────────────────────────────────────────────────────
	// AC 3 — Config & credentials
	// ─────────────────────────────────────────────────────────────────────

	public function test_config() {
		$this->guard();
		$this->start_timer();

		$api    = Komerce_API_Client::instance();
		$opts   = get_option( 'komerce_settings', array() );
		$detail = array();
		$ok     = true;

		$detail[] = 'Environment: ' . $api->get_environment();
		$detail[] = 'Plugin version: ' . KOMERCE_VERSION;
		$detail[] = 'WooCommerce: ' . ( defined( 'WC_VERSION' ) ? WC_VERSION : 'tidak terdeteksi' );

		$keys = array(
			'API Key Shipping Delivery' => $api->is_order_configured(),
			'API Key Payment'           => $api->is_payment_configured(),
		);
		foreach ( $keys as $label => $set ) {
			$detail[] = sprintf( '%s: %s', $label, $set ? 'terisi' : 'KOSONG' );
			if ( ! $set ) {
				$ok = false;
			}
		}

		$origin = rajaongkir_get_origin_id();
		$detail[] = 'Origin ID: ' . ( $origin ?: 'KOSONG — ongkir tidak akan muncul' );
		if ( '' === $origin ) {
			$ok = false;
		}

		$secret   = rajaongkir_get_webhook_secret();
		$detail[] = 'Callback API Key: ' . ( '' !== $secret ? 'terisi (' . strlen( $secret ) . ' karakter)' : 'KOSONG — callback pembayaran akan ditolak' );

		$reach    = rajaongkir_check_webhook_reachable();
		$detail[] = 'Webhook URL: ' . rajaongkir_get_webhook_url();
		$detail[] = 'Dapat dijangkau publik: ' . ( $reach['ok'] ? 'ya' : 'TIDAK — ' . $reach['reason'] );

		$detail[] = 'Shipper phone: ' . ( rajaongkir_normalize_phone( $opts['shipper_phone'] ?? '' ) ?: 'KOSONG' );
		$detail[] = 'Unit berat toko: ' . get_option( 'woocommerce_weight_unit', 'kg' );
		$detail[] = 'Hold stock (menit): ' . get_option( 'woocommerce_hold_stock_minutes', '60' );

		// Gateway + shipping method registration.
		$gateways = WC()->payment_gateways ? WC()->payment_gateways->payment_gateways() : array();
		$has_gw   = false;
		foreach ( $gateways as $gw ) {
			if ( 'komerce_payment' === $gw->id ) {
				$has_gw   = true;
				$detail[] = 'Gateway Komerce Payment: terdaftar, enabled=' . $gw->enabled;
			}
		}
		if ( ! $has_gw ) {
			$detail[] = 'Gateway Komerce Payment: TIDAK terdaftar';
			$ok       = false;
		}

		$this->result(
			$ok,
			$ok ? 'Konfigurasi lengkap.' : 'Ada konfigurasi yang belum lengkap — lihat detail.',
			$detail
		);
	}

	// ─────────────────────────────────────────────────────────────────────
	// AC 3 — Destination search
	// ─────────────────────────────────────────────────────────────────────

	public function test_destination() {
		$this->guard();

		$keyword = $this->param( 'keyword', 'purwokerto' );

		// Cold call: clear this keyword's cache so the timing is meaningful.
		delete_transient( 'komerce_dest_' . md5( strtolower( trim( $keyword ) ) ) );

		$this->start_timer();
		$result = rajaongkir_search_destination( $keyword );
		$cold   = $this->elapsed();

		if ( is_wp_error( $result ) ) {
			$err_data = $result->get_error_data();
			$this->result( false, 'Gagal: ' . $result->get_error_message(), array(
				'Kode: ' . $result->get_error_code(),
				'Endpoint: ' . Komerce_API_Client::instance()->get_environment() . ' (' . ( Komerce_API_Client::instance()->get_environment() === 'Sandbox' ? 'https://api-sandbox.collaborator.komerce.id/' : 'https://api.collaborator.komerce.id/' ) . ')',
				'Detail Server: ' . ( ! empty( $err_data['raw'] ) ? $err_data['raw'] : '-' ),
			) );
		}

		// Warm call to prove the 24h cache is in play.
		$this->start_timer();
		rajaongkir_search_destination( $keyword );
		$warm = $this->elapsed();

		$detail = array(
			sprintf( 'Keyword: "%s"', $keyword ),
			sprintf( 'Hasil: %d destinasi', count( $result ) ),
			sprintf( 'Tanpa cache: %s | dengan cache: %s', $cold, $warm ),
		);

		foreach ( $this->preview( $result, 5 ) as $row ) {
			$detail[] = is_array( $row )
				? sprintf( 'id=%s → %s', $row['id'], $row['label'] )
				: $row;
		}

		// Validation branch: keyword shorter than 3 characters.
		$short = rajaongkir_search_destination( 'ab' );
		$detail[] = 'Validasi keyword < 3 char: ' . ( is_wp_error( $short ) ? 'ditolak (benar)' : 'LOLOS (salah)' );

		$this->result( ! empty( $result ), sprintf( '%d destinasi ditemukan.', count( $result ) ), $detail );
	}

	// ─────────────────────────────────────────────────────────────────────
	// AC 4 — Tariff calculation
	// ─────────────────────────────────────────────────────────────────────

	public function test_tariff() {
		$this->guard();

		$origin      = $this->param( 'origin_id' ) ?: rajaongkir_get_origin_id();
		$destination = $this->param( 'destination_id' );
		$weight      = (int) $this->param( 'weight', '1000' );

		if ( '' === $origin ) {
			$this->result( false, 'Origin ID kosong. Isi di WooCommerce > Komerce atau di form ini.' );
		}
		if ( '' === $destination ) {
			$this->result( false, 'Destination ID wajib diisi. Ambil dari hasil tes Search Destination.' );
		}

		$detail = array();

		// Error branches first — these must fail cleanly.
		$checks = array(
			'origin_id kosong'      => rajaongkir_calculate_shipping_cost( array( 'destination_id' => $destination, 'weight' => $weight, 'item_value' => 100000 ) ),
			'destination_id kosong' => rajaongkir_calculate_shipping_cost( array( 'origin_id' => $origin, 'weight' => $weight, 'item_value' => 100000 ) ),
			'weight 0'              => rajaongkir_calculate_shipping_cost( array( 'origin_id' => $origin, 'destination_id' => $destination, 'weight' => 0, 'item_value' => 100000 ) ),
			'destination invalid'   => rajaongkir_calculate_shipping_cost( array( 'origin_id' => $origin, 'destination_id' => '99999999', 'weight' => $weight, 'item_value' => 100000 ) ),
		);
		foreach ( $checks as $label => $res ) {
			$detail[] = sprintf(
				'Error handling — %s: %s',
				$label,
				is_wp_error( $res ) ? 'ditolak "' . $res->get_error_message() . '"' : 'LOLOS (seharusnya ditolak)'
			);
		}

		// The real call.
		delete_transient( 'komerce_tariff_' . md5( wp_json_encode( array(
			'shipper_destination_id'  => (string) $origin,
			'receiver_destination_id' => (string) $destination,
			'weight'                  => rajaongkir_grams_to_kg( $weight ),
			'item_value'              => 100000,
			'cod'                     => 'no',
		) ) ) );

		$this->start_timer();
		$result = rajaongkir_calculate_shipping_cost( array(
			'origin_id'      => $origin,
			'destination_id' => $destination,
			'weight'         => $weight,
			'item_value'     => 100000,
		) );
		$took = $this->elapsed();

		if ( is_wp_error( $result ) ) {
			$detail[] = 'Panggilan utama gagal: ' . $result->get_error_message();
			$this->result( false, 'Gagal menghitung ongkir.', $detail );
		}

		$detail[] = sprintf( 'Rute: %s → %s', $origin, $destination );
		$detail[] = sprintf( 'Berat: %d g → dikirim sebagai %s kg', $weight, rajaongkir_grams_to_kg( $weight ) );
		$detail[] = sprintf( 'Waktu respons: %s (AC: < 3 detik)', $took );
		$detail[] = sprintf( 'Kurir tersedia: %d', count( $result ) );

		// Verify every AC-mandated field is present.
		$required = array( 'courier', 'service', 'cost', 'eta', 'courier_code' );
		$missing  = array_diff( $required, array_keys( $result[0] ?? array() ) );
		$detail[] = 'Field wajib AC: ' . ( empty( $missing ) ? 'lengkap' : 'HILANG → ' . implode( ', ', $missing ) );

		foreach ( array_slice( $result, 0, 8 ) as $c ) {
			$detail[] = sprintf(
				'%s %s — Rp %s | eta: %s | %s%s',
				$c['courier'],
				$c['service'],
				number_format_i18n( $c['cost'] ),
				$c['eta'] ?: '-',
				$c['category'],
				$c['is_cod'] ? ' | COD' : ''
			);
		}

		$this->result( true, sprintf( '%d layanan kurir ditemukan.', count( $result ) ), $detail );
	}

	// ─────────────────────────────────────────────────────────────────────
	// AC 4 — Cart weight
	// ─────────────────────────────────────────────────────────────────────

	public function test_cart_weight() {
		$this->guard();
		$this->start_timer();

		$detail = array();
		$unit   = get_option( 'woocommerce_weight_unit', 'kg' );
		$mult   = rajaongkir_weight_multiplier();

		$detail[] = sprintf( 'Unit berat toko: %s (× %s = gram)', $unit, $mult );

		// Live cart, when the admin happens to have one.
		$cart_weight = rajaongkir_get_cart_weight();
		$detail[] = sprintf( 'Berat cart saat ini: %d g', $cart_weight );

		if ( WC()->cart && ! WC()->cart->is_empty() ) {
			foreach ( WC()->cart->get_cart() as $item ) {
				$p = $item['data'] ?? null;
				if ( ! $p ) {
					continue;
				}
				$detail[] = sprintf(
					'  • %s — %s %s × %d = %d g',
					$p->get_name(),
					$p->get_weight() ?: '0',
					$unit,
					$item['quantity'],
					(int) round( (float) $p->get_weight() * $mult * $item['quantity'] )
				);
			}
		} else {
			$detail[] = '  (cart kosong — tambahkan produk untuk melihat rinciannya)';
		}

		// Products missing the _weight meta break tariff calls.
		$no_weight = wc_get_products( array(
			'limit'      => 5,
			'status'     => 'publish',
			'meta_query' => array(
				'relation' => 'OR',
				array( 'key' => '_weight', 'compare' => 'NOT EXISTS' ),
				array( 'key' => '_weight', 'value' => '', 'compare' => '=' ),
			),
		) );

		if ( ! empty( $no_weight ) ) {
			$detail[] = sprintf( 'Produk TANPA berat (%d contoh) — ongkir bisa salah:', count( $no_weight ) );
			foreach ( $no_weight as $p ) {
				$detail[] = sprintf( '  ⚠ #%d %s', $p->get_id(), $p->get_name() );
			}
		} else {
			$detail[] = 'Semua produk (sampel) sudah punya berat.';
		}

		$this->result( true, sprintf( 'Berat cart: %d gram.', $cart_weight ), $detail );
	}

	// ─────────────────────────────────────────────────────────────────────
	// AC 1 — Payment methods
	// ─────────────────────────────────────────────────────────────────────

	public function test_payment_methods() {
		$this->guard();

		delete_transient( 'komerce_pay_methods_normalized' );

		$this->start_timer();
		$methods = rajaongkir_get_payment_methods( true );
		$cold    = $this->elapsed();

		if ( is_wp_error( $methods ) ) {
			$err_data = $methods->get_error_data();
			$this->result( false, 'Gagal: ' . $methods->get_error_message(), array(
				'Kode: ' . $methods->get_error_code(),
				'Endpoint: ' . Komerce_API_Client::instance()->get_environment() . ' (' . ( Komerce_API_Client::instance()->get_environment() === 'Sandbox' ? 'https://api-sandbox.collaborator.komerce.id/' : 'https://api.collaborator.komerce.id/' ) . ')',
				'Detail Server: ' . ( ! empty( $err_data['raw'] ) ? $err_data['raw'] : '-' ),
			) );
		}

		$this->start_timer();
		rajaongkir_get_payment_methods();
		$warm = $this->elapsed();

		$detail = array(
			sprintf( 'Tanpa cache: %s | dengan cache: %s (AC: < 1 detik)', $cold, $warm ),
			sprintf( 'Total channel: %d', count( $methods ) ),
		);

		$va = $qris = 0;
		foreach ( $methods as $m ) {
			if ( 'qris' === $m['payment_method'] ) {
				$qris++;
			} else {
				$va++;
			}
			$detail[] = sprintf(
				'%s (%s) — %s | Rp %s – Rp %s%s',
				$m['display_name'],
				$m['payment_method'],
				$m['payment_type'],
				number_format_i18n( $m['min_amount'] ),
				number_format_i18n( $m['max_amount'] ),
				$m['logo_url'] ? ' | logo ✓' : ' | logo ✗'
			);
		}

		array_splice( $detail, 2, 0, sprintf( 'Bank VA: %d, QRIS: %d', $va, $qris ) );

		$this->result( ! empty( $methods ), sprintf( '%d metode pembayaran tersedia.', count( $methods ) ), $detail );
	}

	// ─────────────────────────────────────────────────────────────────────
	// AC 1 — Create payment transaction
	// ─────────────────────────────────────────────────────────────────────

	public function test_create_payment() {
		$this->guard();

		$order_id = absint( $this->param( 'order_id' ) );
		$method   = strtolower( $this->param( 'payment_method', 'qris' ) );

		if ( ! $order_id ) {
			$this->result( false, 'Order ID wajib diisi. Buat order dulu di WooCommerce, lalu masukkan ID-nya.' );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			$this->result( false, sprintf( 'Order #%d tidak ditemukan.', $order_id ) );
		}

		$detail = array();

		// Error branches.
		$e = rajaongkir_create_payment( array( 'payment_method' => $method ) );
		$detail[] = 'Error handling — order_id kosong: ' . ( is_wp_error( $e ) ? 'ditolak "' . $e->get_error_message() . '"' : 'LOLOS (salah)' );

		$e = rajaongkir_create_payment( array( 'order_id' => 99999999, 'payment_method' => $method ) );
		$detail[] = 'Error handling — order tidak ada: ' . ( is_wp_error( $e ) ? 'ditolak "' . $e->get_error_message() . '"' : 'LOLOS (salah)' );

		$e = rajaongkir_create_payment( array( 'order_id' => $order_id ) );
		$detail[] = 'Error handling — payment_method kosong: ' . ( is_wp_error( $e ) ? 'ditolak "' . $e->get_error_message() . '"' : 'LOLOS (salah)' );

		$e = rajaongkir_validate_amount( 5000, $method );
		$detail[] = 'Error handling — nominal Rp 5.000: ' . ( is_wp_error( $e ) ? 'ditolak "' . $e->get_error_message() . '"' : 'LOLOS (salah)' );

		// Existing transaction? Creating a second one would orphan the first.
		$existing = (string) $order->get_meta( RAJAONGKIR_META_TRANSACTION_ID );
		if ( '' !== $existing ) {
			$detail[] = sprintf( 'Order ini sudah punya transaksi: %s', $existing );
			$detail[] = 'Status tersimpan: ' . ( $order->get_meta( RAJAONGKIR_META_PAYMENT_STATUS ) ?: '-' );
			$detail[] = 'VA: ' . ( $order->get_meta( RAJAONGKIR_META_VIRTUAL_ACCOUNT ) ?: '-' );
			$detail[] = 'Kedaluwarsa: ' . ( $order->get_meta( RAJAONGKIR_META_PAYMENT_EXPIRY ) ?: '-' );
			$detail[] = 'Gunakan order lain untuk menguji pembuatan transaksi baru.';
			$this->result( true, 'Transaksi sudah ada, pembuatan baru dilewati.', $detail );
		}

		// The real call.
		$this->start_timer();
		$result = rajaongkir_create_payment( array(
			'order_id'       => $order_id,
			'payment_method' => $method,
		) );
		$took = $this->elapsed();

		if ( is_wp_error( $result ) ) {
			$detail[] = 'Panggilan utama gagal: ' . $result->get_error_message();
			$detail[] = 'Kode: ' . $result->get_error_code();
			$this->result( false, 'Gagal membuat pembayaran.', $detail );
		}

		$detail[] = sprintf( 'Waktu respons: %s (AC: < 3 detik)', $took );
		$detail[] = 'transaction_id: ' . $result['transaction_id'];
		$detail[] = 'payment_method: ' . $result['payment_method'];
		$detail[] = 'payment_type: ' . $result['payment_type'];
		$detail[] = 'virtual_account: ' . ( $result['virtual_account'] ?: '(QRIS — tidak ada VA)' );
		$detail[] = 'qr_string: ' . ( $result['qr_string'] ? substr( $result['qr_string'], 0, 40 ) . '…' : '(bukan QRIS)' );
		$detail[] = 'payment_url: ' . ( $result['payment_url'] ?: '-' );
		$detail[] = 'amount: Rp ' . number_format_i18n( $result['amount'] );
		$detail[] = 'expiry_date: ' . $result['expiry_date'];

		// Confirm the meta the AC asks for.
		$order = wc_get_order( $order_id );
		$metas = array(
			RAJAONGKIR_META_TRANSACTION_ID  => 'transaction_id',
			RAJAONGKIR_META_PAYMENT_METHOD  => 'payment_method',
			RAJAONGKIR_META_PAYMENT_AMOUNT  => 'payment_amount',
			RAJAONGKIR_META_PAYMENT_EXPIRY  => 'payment_expiry',
			RAJAONGKIR_META_PAYMENT_STATUS  => 'payment_status',
		);
		$detail[] = '— Order meta tersimpan —';
		foreach ( $metas as $key => $label ) {
			$val      = $order->get_meta( $key );
			$detail[] = sprintf( '%s: %s', $key, '' !== $val ? $val : 'KOSONG' );
		}
		$detail[] = 'Status order WooCommerce: ' . $order->get_status() . ' (AC: pending)';

		$this->result( true, 'Transaksi pembayaran berhasil dibuat.', $detail );
	}

	// ─────────────────────────────────────────────────────────────────────
	// AC 1 + 2 — Payment status
	// ─────────────────────────────────────────────────────────────────────

	public function test_payment_status() {
		$this->guard();

		$order_id       = absint( $this->param( 'order_id' ) );
		$transaction_id = $this->param( 'transaction_id' );

		if ( ! $order_id && '' === $transaction_id ) {
			$this->result( false, 'Isi Order ID atau Transaction ID.' );
		}

		$detail = array();

		$e = rajaongkir_check_payment_status( '' );
		$detail[] = 'Error handling — identifier kosong: ' . ( is_wp_error( $e ) ? 'ditolak "' . $e->get_error_message() . '"' : 'LOLOS (salah)' );

		$identifier = $order_id ?: $transaction_id;

		$this->start_timer();
		$status = rajaongkir_check_payment_status( $identifier );
		$took   = $this->elapsed();

		if ( is_wp_error( $status ) ) {
			$detail[] = 'Gagal: ' . $status->get_error_message();
			$this->result( false, 'Gagal cek status.', $detail );
		}

		$detail[] = sprintf( 'Waktu respons: %s', $took );
		$detail[] = 'transaction_id: ' . $status['transaction_id'];
		$detail[] = 'Status ternormalisasi: ' . $status['payment_status'] . ' (AC: pending|success|failed|expired)';
		$detail[] = 'Status mentah dari API: ' . ( $status['raw_status'] ?: '-' );
		$detail[] = 'amount: Rp ' . number_format_i18n( $status['amount'] );
		$detail[] = 'virtual_account: ' . ( $status['virtual_account'] ?: '-' );
		$detail[] = 'expiry_date: ' . ( $status['expiry_date'] ?: '-' );

		// Second call within 3s must be served from cache (rate limit guard).
		$this->start_timer();
		$again    = rajaongkir_check_payment_status( $identifier );
		$detail[] = sprintf(
			'Rate limit guard: panggilan kedua %s (%s) — API membatasi 1 request / 3 detik',
			! empty( $again['from_cache'] ) ? 'dari cache ✓' : 'menembak API (guard tidak aktif)',
			$this->elapsed()
		);

		if ( $status['order_id'] ) {
			$order    = wc_get_order( $status['order_id'] );
			$detail[] = 'Meta order diperbarui: ' . $order->get_meta( RAJAONGKIR_META_PAYMENT_STATUS );
			$detail[] = 'Status order WooCommerce: ' . $order->get_status();
		}

		$this->result( true, 'Status pembayaran: ' . $status['payment_status'], $detail );
	}

	// ─────────────────────────────────────────────────────────────────────
	// AC 1 — Webhook simulator
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * POST a payload to our own webhook endpoint over real HTTP.
	 *
	 * Exercises the full stack including WooCommerce's wc-api routing. Fails on
	 * local domains that cannot resolve themselves — route_direct() covers that
	 * case.
	 *
	 * @param array $payload Body to send.
	 * @param mixed $sign    true = valid HMAC, string = that literal value,
	 *                       false = omit the header.
	 * @return array { code, body, error }
	 */
	private function post_webhook( $payload, $sign = true ) {
		$url  = rajaongkir_get_webhook_url();
		$body = wp_json_encode( $payload );

		$headers = array( 'Content-Type' => 'application/json' );

		if ( true === $sign ) {
			$secret = rajaongkir_get_webhook_secret();
			if ( '' !== $secret ) {
				$headers['X-Callback-Api-Key'] = hash_hmac( 'sha256', $body, $secret );
			}
		} elseif ( is_string( $sign ) && '' !== $sign ) {
			$headers['X-Callback-Api-Key'] = $sign;
		}

		$resp = wp_remote_post( $url, array(
			'timeout'   => 30,
			'headers'   => $headers,
			'body'      => $body,
			'sslverify' => false, // Local certificates are usually self-signed.
		) );

		if ( is_wp_error( $resp ) ) {
			return array( 'code' => 0, 'body' => '', 'error' => $resp->get_error_message() );
		}

		return array(
			'code'  => (int) wp_remote_retrieve_response_code( $resp ),
			'body'  => wp_remote_retrieve_body( $resp ),
			'error' => '',
		);
	}

	/**
	 * Describe one authentication scenario for the report.
	 *
	 * @param string $label    Scenario name.
	 * @param array  $direct   Result from route_direct().
	 * @param array  $expected Acceptable HTTP codes.
	 * @return string
	 */
	private function verdict( $label, $direct, $expected ) {
		$ok = in_array( (int) $direct['code'], $expected, true );

		return sprintf(
			'%s: HTTP %d — %s%s',
			$label,
			$direct['code'],
			$ok ? 'sesuai harapan' : 'TIDAK SESUAI (harusnya ' . implode( '/', $expected ) . ')',
			$ok ? '' : ' | ' . $direct['message']
		);
	}

	public function test_webhook_payment() {
		$this->guard();

		$order_id = absint( $this->param( 'order_id' ) );
		$status   = $this->param( 'status', 'PAID' );

		if ( ! $order_id ) {
			$this->result( false, 'Order ID wajib diisi.' );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			$this->result( false, sprintf( 'Order #%d tidak ditemukan.', $order_id ) );
		}

		$transaction_id = (string) $order->get_meta( RAJAONGKIR_META_TRANSACTION_ID );
		if ( '' === $transaction_id ) {
			$this->result( false, 'Order ini belum punya transaction_id. Jalankan tes Create Payment dulu.' );
		}

		$has_secret = '' !== rajaongkir_get_webhook_secret();

		$detail   = array();
		$detail[] = 'Endpoint: ' . rajaongkir_get_webhook_url();
		$detail[] = 'Callback API Key: ' . ( $has_secret ? 'terisi' : 'KOSONG (semua callback pembayaran akan ditolak 503)' );
		$detail[] = 'Payload: { payment_id, status, external_id }';
		$detail[] = 'Status dikirim: ' . $status;
		$detail[] = 'Status order sebelum: ' . $order->get_status();
		$detail[] = 'payment_status sebelum: ' . ( $order->get_meta( RAJAONGKIR_META_PAYMENT_STATUS ) ?: '-' );

		$payload = array(
			'payment_id'  => $transaction_id,
			'status'      => $status,
			'external_id' => 'WC-' . $order_id,
			'sender_name' => 'Simulator Diagnostik',
		);

		$expect_reject = $has_secret ? array( 401 ) : array( 503 );

		$detail[] = '';
		$detail[] = '— Pengujian keamanan (langsung, tanpa HTTP) —';
		$detail[] = $this->verdict(
			'Tanpa signature',
			$this->route_direct( $payload, null ),
			$expect_reject
		);
		$detail[] = $this->verdict(
			'Signature salah',
			$this->route_direct( $payload, 'signature-palsu-1234567890' ),
			$expect_reject
		);
		$detail[] = $this->verdict(
			'payment_id tak dikenal',
			$this->route_direct( array( 'payment_id' => 'KOMPAY-TIDAK-ADA-999', 'status' => 'PAID' ), true ),
			array( 404, 503 )
		);
		$detail[] = $this->verdict(
			'Body kosong',
			$this->route_direct( array(), null ),
			array( 400 )
		);

		// The real thing, correctly signed.
		$detail[] = '';
		$detail[] = '— Callback valid —';

		$this->start_timer();
		$signed   = $this->route_direct( $payload, true );
		$detail[] = sprintf(
			'Signature valid: HTTP %d (%s) — %s',
			$signed['code'],
			$this->elapsed(),
			200 === (int) $signed['code'] ? 'diterima' : 'DITOLAK: ' . $signed['message']
		);

		// Also try over real HTTP so the wc-api route itself gets exercised.
		$http     = $this->post_webhook( $payload, true );
		$detail[] = $http['error']
			? 'Via HTTP: gagal terhubung (' . $http['error'] . ') — normal di domain lokal, hasil di atas tetap sah'
			: sprintf( 'Via HTTP: HTTP %d %s', $http['code'], 200 === $http['code'] ? '(route wc-api berfungsi)' : '— ' . $http['body'] );

		// Re-read to show the effect.
		$order    = wc_get_order( $order_id );
		$detail[] = '';
		$detail[] = '— Sesudah callback —';
		$detail[] = 'Status order: ' . $order->get_status();
		$detail[] = 'payment_status: ' . ( $order->get_meta( RAJAONGKIR_META_PAYMENT_STATUS ) ?: '-' );
		$detail[] = 'Shipping order_no: ' . ( $order->get_meta( RAJAONGKIR_META_ORDER_NO ) ?: '(belum dibuat)' );
		$detail[] = 'AWB: ' . ( $order->get_meta( RAJAONGKIR_META_AIRWAY_BILL ) ?: '(menunggu callback pengiriman)' );

		if ( 'PAID' === strtoupper( $status ) ) {
			$auto     = ( get_option( 'komerce_settings', array() )['auto_create_order'] ?? '' ) === 'yes';
			$detail[] = 'Auto-Create Order: ' . ( $auto ? 'aktif — order pengiriman dibuat otomatis' : 'nonaktif — buat manual' );
		}

		$notes = wc_get_order_notes( array( 'order_id' => $order_id, 'limit' => 4 ) );
		if ( $notes ) {
			$detail[] = '';
			$detail[] = '— Catatan order terbaru —';
			foreach ( $notes as $n ) {
				$detail[] = '  • ' . wp_strip_all_tags( $n->content );
			}
		}

		$this->result( 200 === (int) $signed['code'], 'Simulasi callback pembayaran selesai.', $detail );
	}

	public function test_webhook_shipping() {
		$this->guard();

		$order_id = absint( $this->param( 'order_id' ) );
		$status   = $this->param( 'status', 'Dikirim' );
		$cnote    = $this->param( 'cnote' );

		if ( '' === $cnote ) {
			$cnote = 'TEST' . wp_rand( 100000000, 999999999 );
		}

		if ( ! $order_id ) {
			$this->result( false, 'Order ID wajib diisi.' );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			$this->result( false, sprintf( 'Order #%d tidak ditemukan.', $order_id ) );
		}

		$order_no = (string) ( $order->get_meta( RAJAONGKIR_META_ORDER_NO ) ?: $order->get_meta( '_komerce_order_no' ) );
		if ( '' === $order_no ) {
			$this->result( false, 'Order ini belum punya order_no pengiriman. Jalankan Place Order (mode eksekusi) dulu.' );
		}

		$detail   = array();
		$detail[] = 'Payload: { order_no, cnote, status } sesuai docs Delivery API';
		$detail[] = 'order_no: ' . $order_no;
		$detail[] = 'cnote (AWB): ' . $cnote;
		$detail[] = 'status: ' . $status;
		$detail[] = 'Status order sebelum: ' . $order->get_status();
		$detail[] = 'AWB sebelum: ' . ( $order->get_meta( RAJAONGKIR_META_AIRWAY_BILL ) ?: '(kosong)' );

		$detail[] = '';
		$detail[] = '— Pengujian keamanan —';
		$detail[] = 'Docs Delivery API tidak mendefinisikan signature untuk callback ini,';
		$detail[] = 'jadi keaslian diverifikasi dengan mencocokkan order_no.';
		$detail[] = $this->verdict(
			'order_no tak dikenal',
			$this->route_direct( array(
				'order_no' => 'KOM-TIDAK-ADA-' . wp_rand( 1000, 9999 ),
				'cnote'    => 'X',
				'status'   => 'Dikirim',
			), null ),
			array( 404 )
		);
		$detail[] = $this->verdict(
			'Tanpa order_no & cnote',
			$this->route_direct( array( 'status' => 'Dikirim' ), null ),
			array( 400 )
		);
		$detail[] = $this->verdict(
			'Signature dikirim tapi salah',
			$this->route_direct( array(
				'order_no' => $order_no,
				'cnote'    => $cnote,
				'status'   => $status,
			), 'signature-palsu' ),
			array( 401 )
		);

		// The real shape: no signature at all.
		$detail[] = '';
		$detail[] = '— Callback sebenarnya (tanpa signature) —';

		$this->start_timer();
		$resp     = $this->route_direct( array(
			'order_no' => $order_no,
			'cnote'    => $cnote,
			'status'   => $status,
		), null );
		$detail[] = sprintf(
			'Hasil: HTTP %d (%s) — %s',
			$resp['code'],
			$this->elapsed(),
			200 === (int) $resp['code'] ? 'diterima' : 'DITOLAK: ' . $resp['message']
		);

		$order    = wc_get_order( $order_id );
		$detail[] = '';
		$detail[] = '— Sesudah callback —';
		$detail[] = 'Status order: ' . $order->get_status();
		$detail[] = 'AWB tersimpan: ' . ( $order->get_meta( RAJAONGKIR_META_AIRWAY_BILL ) ?: 'KOSONG' );
		$detail[] = 'AWB legacy (_komerce_awb): ' . ( $order->get_meta( '_komerce_awb' ) ?: 'KOSONG' );
		$detail[] = 'Status pengiriman: ' . ( $order->get_meta( '_komerce_shipping_status' ) ?: '-' );

		$notes = wc_get_order_notes( array( 'order_id' => $order_id, 'limit' => 3 ) );
		if ( $notes ) {
			$detail[] = '';
			$detail[] = '— Catatan order terbaru —';
			foreach ( $notes as $n ) {
				$detail[] = '  • ' . wp_strip_all_tags( $n->content );
			}
		}

		$this->result( 200 === (int) $resp['code'], 'Simulasi callback pengiriman selesai.', $detail );
	}

	/**
	 * Resolve the registered Komerce payment gateway.
	 *
	 * @return WC_Komerce_Payment|null
	 */
	private function gateway() {
		if ( ! WC()->payment_gateways ) {
			return null;
		}

		foreach ( WC()->payment_gateways->payment_gateways() as $gw ) {
			if ( 'komerce_payment' === $gw->id ) {
				return $gw;
			}
		}

		return null;
	}

	/**
	 * Run a callback payload through the real routing logic without HTTP.
	 *
	 * Local development domains frequently cannot resolve themselves, so a
	 * loopback POST never arrives. This calls the same router the HTTP endpoint
	 * uses, including signature verification.
	 *
	 * @param array       $payload   Callback body.
	 * @param string|null $signature Signature to present; null omits the header.
	 * @return array { code, message }
	 */
	private function route_direct( $payload, $signature = null ) {
		$gateway = $this->gateway();

		if ( ! $gateway ) {
			return array( 'code' => 0, 'message' => 'Gateway Komerce Payment tidak terdaftar' );
		}

		$raw = wp_json_encode( $payload );

		if ( null === $signature ) {
			$signature = '';
		} elseif ( true === $signature ) {
			// Sign it the way RajaOngkir would.
			$secret    = rajaongkir_get_webhook_secret();
			$signature = '' !== $secret ? hash_hmac( 'sha256', $raw, $secret ) : '';
		}

		return $gateway->route_webhook( $raw, $signature );
	}

	// ─────────────────────────────────────────────────────────────────────
	// AC 2 — Verify payment then create order
	// ─────────────────────────────────────────────────────────────────────

	public function test_place_order() {
		$this->guard();

		$order_id = absint( $this->param( 'order_id' ) );
		$execute  = 'yes' === $this->param( 'execute', 'no' );

		if ( ! $order_id ) {
			$this->result( false, 'Order ID wajib diisi.' );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			$this->result( false, sprintf( 'Order #%d tidak ditemukan.', $order_id ) );
		}

		$detail   = array();
		$detail[] = 'Status order sekarang: ' . $order->get_status();
		$detail[] = 'transaction_id: ' . ( $order->get_meta( RAJAONGKIR_META_TRANSACTION_ID ) ?: '(tidak ada — dianggap COD)' );

		// Step 1: verify payment.
		$this->start_timer();
		$status = rajaongkir_verify_payment_status( $order_id );
		$detail[] = sprintf( 'Verifikasi pembayaran: %s', $this->elapsed() );

		if ( is_wp_error( $status ) ) {
			$detail[] = 'Gagal: ' . $status->get_error_message();
			$this->result( false, 'Verifikasi pembayaran gagal.', $detail );
		}

		$detail[] = 'Hasil verifikasi: ' . $status;

		// Step 2: show which branch this takes.
		$branches = array(
			'success' => 'Create order ke RajaOngkir → wc-processing → email customer',
			'pending' => 'TIDAK create order → tetap wc-pending → kembalikan payment_details',
			'expired' => 'Error 409 "pembayaran kedaluwarsa"',
			'failed'  => 'Error 409 "pembayaran gagal"',
		);
		$detail[] = 'Cabang yang diambil: ' . ( $branches[ $status ] ?? 'tidak dikenal' );

		if ( 'success' !== $status ) {
			$detail[] = '— Payment details yang dikembalikan ke frontend —';
			$detail[] = 'virtual_account: ' . ( $order->get_meta( RAJAONGKIR_META_VIRTUAL_ACCOUNT ) ?: '-' );
			$detail[] = 'amount: Rp ' . number_format_i18n( (int) $order->get_meta( RAJAONGKIR_META_PAYMENT_AMOUNT ) );
			$detail[] = 'expiry_date: ' . ( $order->get_meta( RAJAONGKIR_META_PAYMENT_EXPIRY ) ?: '-' );
			$detail[] = 'Status order tetap: ' . $order->get_status() . ' (AC: pending)';

			$this->result( true, sprintf( 'Pembayaran "%s" — order pengiriman TIDAK dibuat (sesuai AC).', $status ), $detail );
		}

		// Payment is settled. Validate the payload before sending anything.
		$validation = rajaongkir_validate_order_data( $order );
		$detail[]   = 'Validasi data order: ' . ( is_wp_error( $validation ) ? 'GAGAL — ' . $validation->get_error_message() : 'lengkap' );

		if ( is_wp_error( $validation ) ) {
			$this->result( false, 'Data order belum lengkap untuk dikirim.', $detail );
		}

		$existing = (string) $order->get_meta( RAJAONGKIR_META_ORDER_ID );
		if ( '' !== $existing ) {
			$detail[] = 'Order pengiriman sudah ada: ' . $existing;
			$detail[] = 'order_no: ' . ( $order->get_meta( RAJAONGKIR_META_ORDER_NO ) ?: '-' );
			$detail[] = 'AWB: ' . ( $order->get_meta( RAJAONGKIR_META_AIRWAY_BILL ) ?: '(menunggu callback pengiriman)' );
			$detail[] = 'Idempotency bekerja: pemanggilan ulang tidak membuat order kedua.';
			$this->result( true, 'Order pengiriman sudah dibuat sebelumnya.', $detail );
		}

		if ( ! $execute ) {
			$detail[] = '';
			$detail[] = 'MODE SIMULASI — belum menembak API.';
			$detail[] = 'Centang "Benar-benar buat order" untuk mengeksekusi. Order akan';
			$detail[] = 'tercipta di RajaOngkir dan ongkir dipotong dari saldo dashboard.';
			$this->result( true, 'Simulasi: pembayaran sudah lunas, siap dibuatkan order pengiriman.', $detail );
		}

		// Step 3: the real thing.
		$this->start_timer();
		$created = rajaongkir_create_order_to_rajaongkir( $order_id );
		$took    = $this->elapsed();

		if ( is_wp_error( $created ) ) {
			$detail[] = 'Gagal: ' . $created->get_error_message();
			$detail[] = 'Kode: ' . $created->get_error_code();
			$this->result( false, 'Gagal membuat order pengiriman.', $detail );
		}

		$detail[] = sprintf( 'Waktu respons: %s', $took );
		$detail[] = 'rajaongkir_order_id: ' . $created['order_id'];
		$detail[] = 'rajaongkir_order_no: ' . ( $created['order_no'] ?: '-' );
		$detail[] = 'airway_bill: ' . ( $created['airway_bill'] ?: '(kosong — normal, AWB datang lewat callback pengiriman)' );

		$order    = wc_get_order( $order_id );
		$detail[] = 'Status order: ' . $order->get_status() . ' (AC: processing)';
		$detail[] = 'Email processing: dikirim via WC_Email_Customer_Processing_Order';

		$this->result( true, 'Order pengiriman berhasil dibuat.', $detail );
	}

	// ─────────────────────────────────────────────────────────────────────
	// Page
	// ─────────────────────────────────────────────────────────────────────

	public function render() {
		$nonce  = wp_create_nonce( self::NONCE );
		$origin = rajaongkir_get_origin_id();
		?>
		<div class="wrap komerce-diag">
			<h1>Komerce Test</h1>
			<p>Setiap tombol menjalankan satu skenario dari acceptance criteria terhadap API sungguhan.
			Tidak ada yang berjalan otomatis.</p>

			<div class="notice notice-warning">
				<p><strong>Perhatian:</strong> tes <em>Create Payment</em> membuat transaksi nyata, dan
				<em>Place Order</em> (mode eksekusi) membuat order pengiriman nyata serta memotong saldo.
				Aktifkan <strong>Sandbox Mode</strong> di WooCommerce &gt; Komerce saat menguji.</p>
			</div>

			<style>
			.komerce-diag .card { max-width:none; padding:16px 20px; margin:0 0 16px; }
			.komerce-diag h2 { margin-top:0; font-size:15px; }
			.komerce-diag .ac-tag { display:inline-block; background:#2271b1; color:#fff; font-size:11px;
				padding:2px 8px; border-radius:10px; margin-right:8px; vertical-align:middle; }
			.komerce-diag .row { display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin:10px 0; }
			.komerce-diag .row label { font-weight:600; min-width:120px; }
			.komerce-diag .out { display:none; margin-top:12px; padding:12px 14px; border-radius:4px;
				border-left:4px solid #ccc; background:#f6f7f7; font-family:Consolas,Monaco,monospace;
				font-size:12px; line-height:1.7; white-space:pre-wrap; max-height:420px; overflow:auto; }
			.komerce-diag .out.ok   { border-left-color:#00a32a; background:#f0f6f0; }
			.komerce-diag .out.bad  { border-left-color:#d63638; background:#fcf0f1; }
			.komerce-diag .out.busy { border-left-color:#dba617; background:#fcf9e8; }
			.komerce-diag .out b { font-family:-apple-system,sans-serif; font-size:13px; }
			</style>

			<div class="card">
				<h2><span class="ac-tag">AC 3</span>Konfigurasi &amp; Kredensial</h2>
				<p class="description">Memeriksa API key, origin, callback key, keterjangkauan webhook,
				dan pendaftaran gateway. Jalankan ini lebih dulu.</p>
				<button class="button button-primary" data-test="config">Periksa Konfigurasi</button>
				<div class="out" id="out-config"></div>
			</div>

			<div class="card">
				<h2><span class="ac-tag">AC 3</span>Search Destination</h2>
				<p class="description">Mengukur waktu tanpa dan dengan cache 24 jam, plus validasi keyword minimal 3 karakter.
				<strong>Catat salah satu <code>id</code> dari hasilnya</strong> — dibutuhkan tes berikutnya.</p>
				<div class="row">
					<label>Keyword</label>
					<input type="text" id="dest-keyword" value="purwokerto" class="regular-text" />
					<button class="button button-primary" data-test="destination" data-fields="keyword:dest-keyword">Cari</button>
				</div>
				<div class="out" id="out-destination"></div>
			</div>

			<div class="card">
				<h2><span class="ac-tag">AC 4</span>Calculate Shipping Cost</h2>
				<p class="description">Menguji param wajib, destinasi tidak valid, error API, kelengkapan field,
				dan waktu respons.</p>
				<div class="row">
					<label>Origin ID</label>
					<input type="text" id="tariff-origin" value="<?php echo esc_attr( $origin ); ?>" class="regular-text" placeholder="dari pengaturan" />
				</div>
				<div class="row">
					<label>Destination ID</label>
					<input type="text" id="tariff-dest" class="regular-text" placeholder="ambil dari hasil Search Destination" />
				</div>
				<div class="row">
					<label>Berat (gram)</label>
					<input type="number" id="tariff-weight" value="1000" class="small-text" />
					<button class="button button-primary" data-test="tariff"
						data-fields="origin_id:tariff-origin,destination_id:tariff-dest,weight:tariff-weight">Hitung Ongkir</button>
				</div>
				<div class="out" id="out-tariff"></div>
			</div>

			<div class="card">
				<h2><span class="ac-tag">AC 4</span>Cart Weight</h2>
				<p class="description">Membaca <code>_weight</code> tiap produk di cart, dikali qty, dikonversi ke gram.
				Sekaligus menandai produk yang belum punya berat.</p>
				<button class="button button-primary" data-test="cart_weight">Hitung Berat Cart</button>
				<div class="out" id="out-cart_weight"></div>
			</div>

			<div class="card">
				<h2><span class="ac-tag">AC 1</span>Payment Methods</h2>
				<p class="description">Mengambil daftar VA &amp; QRIS, mengukur waktu dengan dan tanpa cache,
				serta menampilkan batas nominal tiap channel.</p>
				<button class="button button-primary" data-test="payment_methods">Ambil Metode Pembayaran</button>
				<div class="out" id="out-payment_methods"></div>
			</div>

			<div class="card">
				<h2><span class="ac-tag">AC 1</span>Create Payment Transaction</h2>
				<p class="description">Menguji semua cabang error lebih dulu (order_id kosong, order tidak ada,
				payment_method kosong, nominal di bawah Rp 10.000), lalu membuat transaksi nyata dan memeriksa
				seluruh order meta yang diminta AC.</p>
				<div class="row">
					<label>Order ID</label>
					<input type="number" id="pay-order" class="small-text" placeholder="mis. 123" />
					<label>Metode</label>
					<input type="text" id="pay-method" value="qris" class="regular-text" placeholder="qris / bca / bni / mandiri" />
					<button class="button button-primary" data-test="create_payment"
						data-fields="order_id:pay-order,payment_method:pay-method">Buat Transaksi</button>
				</div>
				<div class="out" id="out-create_payment"></div>
			</div>

			<div class="card">
				<h2><span class="ac-tag">AC 1</span><span class="ac-tag">AC 2</span>Payment Status</h2>
				<p class="description">Mengambil status terkini, memetakannya ke
				<code>pending|success|failed|expired</code>, memperbarui meta order, dan membuktikan
				pelindung rate limit 3 detik bekerja.</p>
				<div class="row">
					<label>Order ID</label>
					<input type="number" id="status-order" class="small-text" />
					<label>atau Transaction ID</label>
					<input type="text" id="status-txn" class="regular-text" />
					<button class="button button-primary" data-test="payment_status"
						data-fields="order_id:status-order,transaction_id:status-txn">Cek Status</button>
				</div>
				<div class="out" id="out-payment_status"></div>
			</div>

			<div class="card">
				<h2><span class="ac-tag">Payment Callback</span>Simulasi Webhook Pembayaran (VA / QRIS)</h2>
				<p class="description">
					<strong>Alur:</strong> Callback ini dikirim otomatis oleh Komerce ke URL endpoint yang disisipkan saat <em>create payment</em> (tidak perlu didaftarkan manual di Collaborator).
					Tes ini menembak endpoint dengan tiga variasi: tanpa signature, signature salah, dan signature valid. Hanya signature valid yang diproses untuk mengubah status order ke <em>Processing</em>.
				</p>
				<div class="row">
					<label>Order ID</label>
					<input type="number" id="wh-pay-order" class="small-text" />
					<label>Status</label>
					<select id="wh-pay-status">
						<option value="PAID">PAID</option>
						<option value="PENDING">PENDING</option>
						<option value="EXPIRED">EXPIRED</option>
						<option value="CANCELED">CANCELED</option>
					</select>
					<button class="button button-primary" data-test="webhook_payment"
						data-fields="order_id:wh-pay-order,status:wh-pay-status">Kirim Callback</button>
				</div>
				<div class="out" id="out-webhook_payment"></div>
			</div>

			<div class="card">
				<h2><span class="ac-tag" style="background:#d63638;color:#fff;">Shipping Callback</span>Simulasi Webhook Pengiriman &amp; AWB (Collaborator)</h2>
				<p class="description">
					<strong>Alur:</strong> Callback ini berasal dari webhook global yang <strong>wajib didaftarkan di Dashboard Collaborator</strong>.
					Merupakan satu-satunya sumber nomor resi (AWB / <code>cnote</code>) dan pembaruan status kurir secara real-time. Keasliannya diverifikasi melalui pencocokan <code>order_no</code>.
				</p>
				<div class="row">
					<label>Order ID</label>
					<input type="number" id="wh-ship-order" class="small-text" />
					<label>Status</label>
					<select id="wh-ship-status">
						<option value="Diajukan">Diajukan</option>
						<option value="Dijemput">Dijemput</option>
						<option value="Dikirim" selected>Dikirim</option>
						<option value="Selesai">Selesai</option>
						<option value="Dibatalkan">Dibatalkan</option>
					</select>
				</div>
				<div class="row">
					<label>AWB (cnote)</label>
					<input type="text" id="wh-ship-cnote" class="regular-text" placeholder="kosongkan untuk digenerate" />
					<button class="button button-primary" data-test="webhook_shipping"
						data-fields="order_id:wh-ship-order,status:wh-ship-status,cnote:wh-ship-cnote">Kirim Callback</button>
				</div>
				<div class="out" id="out-webhook_shipping"></div>
			</div>

			<div class="card">
				<h2><span class="ac-tag">AC 2</span>Verify Payment &amp; Create Order</h2>
				<p class="description">Inti AC 2: verifikasi status pembayaran, lalu bercabang.
				Mode simulasi hanya menampilkan cabang yang akan diambil tanpa menembak API.</p>
				<div class="row">
					<label>Order ID</label>
					<input type="number" id="place-order" class="small-text" />
					<label style="min-width:auto;">
						<input type="checkbox" id="place-execute" /> Benar-benar buat order (bukan simulasi)
					</label>
					<button class="button button-primary" data-test="place_order"
						data-fields="order_id:place-order,execute:place-execute">Jalankan</button>
				</div>
				<div class="out" id="out-place_order"></div>
			</div>

			<script>
			(function(){
				var nonce = '<?php echo esc_js( $nonce ); ?>';

				document.querySelectorAll('[data-test]').forEach(function(btn){
					btn.addEventListener('click', function(){
						var test = btn.getAttribute('data-test');
						var out  = document.getElementById('out-' + test);
						var data = { action: 'komerce_test_' + test, nonce: nonce };

						(btn.getAttribute('data-fields') || '').split(',').forEach(function(pair){
							if (!pair) return;
							var p = pair.split(':');
							var el = document.getElementById(p[1]);
							if (!el) return;
							data[p[0]] = (el.type === 'checkbox') ? (el.checked ? 'yes' : 'no') : el.value;
						});

						out.style.display = 'block';
						out.className = 'out busy';
						out.textContent = 'Menjalankan…';
						btn.disabled = true;

						jQuery.post(ajaxurl, data)
							.done(function(resp){
								if (!resp.success) {
									out.className = 'out bad';
									out.textContent = 'Error: ' + (resp.data || 'tidak diketahui');
									return;
								}
								var r = resp.data;
								out.className = 'out ' + (r.ok ? 'ok' : 'bad');
								var html = '<b>' + (r.ok ? '✓ ' : '✗ ') + r.summary + '</b>';
								if (r.elapsed) html += '  (' + r.elapsed + ')';
								if (r.detail && r.detail.length) {
									html += '\n\n' + r.detail.join('\n');
								}
								out.innerHTML = html;
							})
							.fail(function(x){
								out.className = 'out bad';
								out.textContent = 'Request gagal: HTTP ' + x.status + '\n' +
									(x.responseText || '').substring(0, 800);
							})
							.always(function(){ btn.disabled = false; });
					});
				});
			})();
			</script>
		</div>
		<?php
	}
}
endif;
