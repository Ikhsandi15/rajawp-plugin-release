<?php
/**
 * Komerce Destination Search
 *
 * AJAX-based subdistrict-level destination search + checkout field integration.
 *
 * @package WooCommerce\Komerce
 * @since   2.0.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Komerce_Destination' ) ) :
class Komerce_Destination {

    private $api;

    public function __construct() {
        $this->api = Komerce_API_Client::instance();

        add_action( 'wp_ajax_komerce_search_destination', array( $this, 'ajax_search' ) );
        add_action( 'wp_ajax_nopriv_komerce_search_destination', array( $this, 'ajax_search' ) );
        add_filter( 'woocommerce_checkout_fields', array( $this, 'add_destination_fields' ) );
        add_action( 'woocommerce_after_checkout_validation', array( $this, 'validate_destination_field' ), 10, 2 );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
    }

    /**
     * Validate that a destination ID is selected before placing order.
     */
    public function validate_destination_field( $data, $errors ) {
        if ( ! WC()->cart || ! WC()->cart->needs_shipping() ) {
            return;
        }

        $dest_id = function_exists( 'komerce_get_posted_or_session_destination_id' )
            ? komerce_get_posted_or_session_destination_id()
            : 0;

        if ( ! $dest_id ) {
            $candidates = array(
                $_POST['billing_komerce_destination_id'] ?? '',
                $_POST['billing_komerce_destination'] ?? '',
                $_POST['shipping_komerce_destination_id'] ?? '',
                $_POST['shipping_komerce_destination'] ?? '',
                $_POST['billing_destination'] ?? '',
                $_POST['destination_id'] ?? '',
            );
            foreach ( $candidates as $c ) {
                if ( ! empty( $c ) && is_numeric( $c ) && (int) $c > 0 ) {
                    $dest_id = (int) $c;
                    break;
                }
            }
            if ( ! $dest_id && WC()->session && is_callable( array( WC()->session, 'get' ) ) ) {
                $dest_id = (int) WC()->session->get( 'komerce_destination_id' );
            }
        }

        if ( empty( $dest_id ) ) {
            $errors->add(
                'billing_komerce_destination_id_required',
                __( 'Kecamatan / Kota tujuan pengiriman wajib dipilih dari pilihan yang tersedia.', 'komerce-shipping' )
            );
        }
    }

    /**
     * AJAX: search destination by keyword.
     */
    public function ajax_search() {
        check_ajax_referer( 'komerce_dest_nonce', 'nonce' );

        $keyword = isset( $_POST['keyword'] ) ? sanitize_text_field( wp_unslash( $_POST['keyword'] ) ) : '';

        if ( strlen( $keyword ) < 3 ) {
            wp_send_json_success( array() );
        }

        $response = $this->api->search_destination( $keyword );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( $response->get_error_message() );
        }

        wp_send_json_success( $this->normalize( $response ) );
    }

    /**
     * Normalize API response for Select2.
     */
    private function normalize( $response ) {
        $out  = array();
        $data = isset( $response['data'] ) ? $response['data'] : $response;

        if ( ! is_array( $data ) ) {
            return $out;
        }

        foreach ( $data as $item ) {
            $id   = $item['id'] ?? $item['destination_id'] ?? '';
            $sub  = $item['subdistrict_name'] ?? $item['subdistrict'] ?? '';
            $city = $item['city_name'] ?? $item['city'] ?? '';
            $prov = $item['province_name'] ?? $item['province'] ?? '';
            $zip  = $item['postal_code'] ?? $item['zip_code'] ?? '';

            $parts = array_filter( array( $sub, $city, $prov ) );
            $label = implode( ', ', $parts );
            if ( $zip ) {
                $label .= " ({$zip})";
            }

            $out[] = array(
                'id'               => $id,
                'text'             => $label,
                'subdistrict_name' => $sub,
                'city_name'        => $city,
                'province_name'    => $prov,
                'postal_code'      => $zip,
            );
        }

        return $out;
    }

    /**
     * Inject destination search fields into checkout.
     */
    public function add_destination_fields( $fields ) {
        $field = array(
            'type'     => 'select',
            'label'    => __( 'Kecamatan / Kota Tujuan', 'woocommerce' ),
            'required' => true,
            'class'    => array( 'form-row-wide', 'komerce-destination-field' ),
            'priority' => 55,
            'options'  => array( '' => __( 'Ketik kecamatan / kota...', 'woocommerce' ) ),
        );

        $hidden = array(
            'type'  => 'hidden',
            'label' => '',
            'class' => array( 'komerce-hidden' ),
        );

        $fields['billing']['billing_komerce_destination']    = $field;
        $fields['billing']['billing_komerce_destination_id'] = $hidden;

        $ship_field             = $field;
        $ship_field['required'] = false;

        $fields['shipping']['shipping_komerce_destination']    = $ship_field;
        $fields['shipping']['shipping_komerce_destination_id'] = $hidden;

        return $fields;
    }

    /**
     * Enqueue Select2 + checkout autocomplete JS.
     */
    public function enqueue_assets() {
        if ( ! is_checkout() && ! is_cart() ) {
            return;
        }

        wp_enqueue_style( 'select2' );
        wp_enqueue_script( 'select2' );

        wp_enqueue_script(
            'komerce-checkout',
            KOMERCE_PLUGIN_URL . 'assets/js/komerce-checkout.js',
            array( 'jquery', 'select2' ),
            KOMERCE_VERSION,
            true
        );

        wp_localize_script( 'komerce-checkout', 'komerce_checkout', array(
            'ajax_url'  => admin_url( 'admin-ajax.php' ),
            'nonce'     => wp_create_nonce( 'komerce_dest_nonce' ),
            'min_chars' => 3,
        ) );
    }
}
endif;
