<?php
/**
 * Komerce Tracking
 *
 * AWB tracking — admin area (AJAX) + customer order detail page.
 *
 * @package WooCommerce\Komerce
 * @since   2.2.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Komerce_Tracking' ) ) :
class Komerce_Tracking {

    private $api;

    public function __construct() {
        $this->api = Komerce_API_Client::instance();

        // AJAX tracking.
        add_action( 'wp_ajax_komerce_track_awb', array( $this, 'ajax_track' ) );
        add_action( 'wp_ajax_nopriv_komerce_track_awb', array( $this, 'ajax_track_public' ) );

        // Customer order detail page.
        add_action( 'woocommerce_order_details_after_order_table', array( $this, 'show_tracking' ) );

        // Admin orders list column.
        add_filter( 'manage_edit-shop_order_columns', array( $this, 'add_column' ) );
        add_action( 'manage_shop_order_posts_custom_column', array( $this, 'render_column' ), 10, 2 );
    }

    // ── Admin AJAX ──

    public function ajax_track() {
        $nonce = $_POST['nonce'] ?? '';
        if ( ! wp_verify_nonce( $nonce, 'komerce_order_actions' ) && ! wp_verify_nonce( $nonce, 'komerce_public_track' ) ) {
            wp_send_json_error( 'Invalid security token' );
        }

        $order_id = absint( $_POST['order_id'] ?? 0 );
        if ( $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order ) {
                wp_send_json_error( 'Order tidak ditemukan' );
            }
            $awb     = $order->get_meta( Komerce_Order::META_AWB );
            $courier = $order->get_meta( Komerce_Order::META_COURIER );
        } else {
            $awb     = sanitize_text_field( $_POST['awb'] ?? '' );
            $courier = sanitize_text_field( $_POST['courier'] ?? '' );
        }

        if ( ! $awb ) {
            wp_send_json_error( 'AWB belum tersedia' );
        }

        $resp = $this->api->track_awb( $awb, $courier );
        if ( is_wp_error( $resp ) ) {
            wp_send_json_error( $resp->get_error_message() );
        }

        $data  = $resp['data'] ?? $resp;
        $items = $data['history'] ?? $data['manifest'] ?? array();

        $history = array();
        foreach ( $items as $h ) {
            $history[] = array(
                'date'        => $h['date'] ?? $h['manifest_date'] ?? '',
                'description' => $h['desc'] ?? $h['description'] ?? $h['manifest_description'] ?? '',
                'code'        => $h['code'] ?? '',
                'status'      => $h['status'] ?? '',
                'location'    => $h['location'] ?? $h['city_name'] ?? '',
            );
        }

        wp_send_json_success( array(
            'awb'     => $awb,
            'courier' => strtoupper( $courier ),
            'status'  => $data['last_status'] ?? ( $data['delivery_status']['status'] ?? ( $data['status'] ?? '' ) ),
            'history' => $history,
        ) );
    }

    // ── Customer AJAX ──

    public function ajax_track_public() {
        check_ajax_referer( 'komerce_public_track', 'nonce' );

        $awb     = sanitize_text_field( $_POST['awb'] ?? '' );
        $courier = sanitize_text_field( $_POST['courier'] ?? '' );

        if ( ! $awb ) {
            wp_send_json_error( 'AWB wajib diisi' );
        }

        $resp = $this->api->track_awb( $awb, $courier );
        if ( is_wp_error( $resp ) ) {
            wp_send_json_error( $resp->get_error_message() );
        }

        $data = $resp['data'] ?? $resp;
        wp_send_json_success( $data );
    }

    // ── Customer order detail ──

    public function show_tracking( $order ) {
        $awb     = $order->get_meta( Komerce_Order::META_AWB );
        $courier = $order->get_meta( Komerce_Order::META_COURIER );

        if ( ! $awb ) {
            return;
        }

        echo '<h2 style="margin-top:2em;">Status Pengiriman</h2>';
        echo '<table class="woocommerce-table shop_table" style="margin-bottom:2em;">';
        echo '<tr><th>Kurir</th><td>' . esc_html( strtoupper( $courier ) ) . '</td></tr>';
        echo '<tr><th>Nomor Resi (AWB)</th><td><code>' . esc_html( $awb ) . '</code></td></tr>';
        echo '</table>';

        // Live tracking via AJAX.
        $nonce = wp_create_nonce( 'komerce_public_track' );
        ?>
        <div id="komerce-tracking-results"></div>
        <button type="button" class="button" id="komerce-track-btn" data-awb="<?php echo esc_attr( $awb ); ?>" data-courier="<?php echo esc_attr( $courier ); ?>">Lacak Paket</button>
        <script>
        (function($){
            $('#komerce-track-btn').on('click', function(){
                var btn = $(this), box = $('#komerce-tracking-results');
                btn.prop('disabled', true).text('Melacak...');
                $.post('<?php echo esc_url( admin_url('admin-ajax.php') ); ?>', {
                    action: 'komerce_track_awb',
                    nonce: '<?php echo esc_js( $nonce ); ?>',
                    awb: btn.data('awb'),
                    courier: btn.data('courier')
                }, function(r){
                    btn.prop('disabled', false).text('Lacak Paket');
                    if (!r.success) { box.html('<p style="color:red;">'+r.data+'</p>'); return; }
                    var d = r.data, h = '<table class="woocommerce-table shop_table"><thead><tr><th>Waktu</th><th>Status</th><th>Lokasi</th></tr></thead><tbody>';
                    if (d.history && d.history.length) {
                        d.history.forEach(function(i){ h += '<tr><td>'+i.date+'</td><td>'+i.description+'</td><td>'+(i.location||'-')+'</td></tr>'; });
                    } else { h += '<tr><td colspan="3">Belum ada data</td></tr>'; }
                    h += '</tbody></table>';
                    box.html(h);
                });
            });
        })(jQuery);
        </script>
        <?php
    }

    // ── Admin column ──

    public function add_column( $cols ) {
        $new = array();
        foreach ( $cols as $k => $v ) {
            $new[ $k ] = $v;
            if ( $k === 'order_status' ) {
                $new['komerce_awb'] = 'AWB';
            }
        }
        return $new;
    }

    public function render_column( $col, $post_id ) {
        if ( $col !== 'komerce_awb' ) {
            return;
        }
        $order = wc_get_order( $post_id );
        $awb   = $order ? $order->get_meta( Komerce_Order::META_AWB ) : '';
        echo $awb ? '<code>' . esc_html( $awb ) . '</code>' : '—';
    }
}
endif;
