<?php
/**
 * RajaOngkir / Komerce Integration Functions
 *
 * Procedural API consumed by the AJAX layer (class-komerce-ajax.php) and by
 * other plugin modules. Every function performs a *direct* call to the
 * RajaOngkir (Komerce Collaborator) OpenAPI through Komerce_API_Client.
 *
 * Groups:
 *   1. Destination            — search subdistricts (24h cache)
 *   2. Tariff / Shipping      — calculate cost, cart weight, session storage
 *   3. Payment                — methods, create transaction, status check
 *   4. Order                  — verify payment then create shipping order
 *
 * @package WooCommerce\Komerce
 * @since   2.3.0
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'KOMERCE_RO_FUNCTIONS_LOADED' ) ) {
	return;
}
define( 'KOMERCE_RO_FUNCTIONS_LOADED', true );

// ─────────────────────────────────────────────────────────────────────────────
// Meta key constants
// ─────────────────────────────────────────────────────────────────────────────

// Payment.
if ( ! defined( 'RAJAONGKIR_META_TRANSACTION_ID' ) ) {
	define( 'RAJAONGKIR_META_TRANSACTION_ID', '_rajaongkir_transaction_id' );
	define( 'RAJAONGKIR_META_PAYMENT_METHOD', '_rajaongkir_payment_method' );
	define( 'RAJAONGKIR_META_VIRTUAL_ACCOUNT', '_rajaongkir_virtual_account' );
	define( 'RAJAONGKIR_META_PAYMENT_AMOUNT', '_rajaongkir_payment_amount' );
	define( 'RAJAONGKIR_META_PAYMENT_EXPIRY', '_rajaongkir_payment_expiry' );
	define( 'RAJAONGKIR_META_PAYMENT_STATUS', '_rajaongkir_payment_status' );
	define( 'RAJAONGKIR_META_QR_STRING', '_rajaongkir_qr_string' );
	define( 'RAJAONGKIR_META_PAYMENT_URL', '_rajaongkir_payment_url' );

	// Shipping / order.
	define( 'RAJAONGKIR_META_ORDER_ID', '_rajaongkir_order_id' );
	define( 'RAJAONGKIR_META_ORDER_NO', '_rajaongkir_order_no' );
	define( 'RAJAONGKIR_META_AIRWAY_BILL', '_rajaongkir_airway_bill' );
	define( 'RAJAONGKIR_META_COURIER_ID', '_rajaongkir_courier_id' );
	define( 'RAJAONGKIR_META_COURIER_NAME', '_rajaongkir_courier_name' );
	define( 'RAJAONGKIR_META_SHIPPING_COST', '_rajaongkir_shipping_cost' );
	define( 'RAJAONGKIR_META_SHIPPING_ETA', '_rajaongkir_shipping_eta' );
	define( 'RAJAONGKIR_META_DESTINATION_ID', '_rajaongkir_destination_id' );
}

/** Session key holding the customer's selected courier. */
if ( ! defined( 'RAJAONGKIR_SESSION_SHIPPING' ) ) {
	define( 'RAJAONGKIR_SESSION_SHIPPING', 'rajaongkir_selected_shipping' );
}

/**
 * Payment constraints from the RajaOngkir Payment API docs.
 *
 * - Global minimum transaction amount is Rp 10.000.
 * - VA expiry minimum is 3600s; AC specifies 3600s as the default.
 * - QRIS expiry is fixed at 5 minutes (300s) by the QRIS standard.
 */
if ( ! defined( 'RAJAONGKIR_MIN_AMOUNT' ) ) {
	define( 'RAJAONGKIR_MIN_AMOUNT', 10000 );
	define( 'RAJAONGKIR_MIN_EXPIRY_VA', 3600 );
	define( 'RAJAONGKIR_DEFAULT_EXPIRY_VA', 3600 );
	define( 'RAJAONGKIR_MIN_EXPIRY_QRIS', 300 );
	define( 'RAJAONGKIR_DEFAULT_EXPIRY_QRIS', 300 );
}

// ─────────────────────────────────────────────────────────────────────────────
// 1. Destination
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Search destinations (province / city / subdistrict) by keyword.
 *
 * Direct call: GET /tariff/api/v1/destination/search?keyword=...
 * Results are cached for 24 hours (see Komerce_API_Client::search_destination()).
 *
 * @param string $keyword Search keyword, minimum 3 characters.
 * @return array|WP_Error Normalized list of destinations, or WP_Error on failure.
 */
function rajaongkir_search_destination( $keyword ) {
	$keyword = trim( (string) $keyword );

	if ( strlen( $keyword ) < 3 ) {
		return new WP_Error(
			'rajaongkir_invalid_keyword',
			__( 'Keyword minimal 3 karakter.', 'komerce-shipping' )
		);
	}

	$api = Komerce_API_Client::instance();

	if ( ! $api->is_order_configured() ) {
		return new WP_Error(
			'rajaongkir_not_configured',
			__( 'API Key Shipping Delivery belum dikonfigurasi. Buka WooCommerce > Komerce.', 'komerce-shipping' )
		);
	}

	$response = $api->search_destination( $keyword );

	if ( is_wp_error( $response ) ) {
		Komerce_Logger::error( 'destination.search', 'Gagal mencari destinasi', array(
			'keyword' => $keyword,
			'error'   => $response->get_error_message(),
		) );
		return $response;
	}

	return rajaongkir_normalize_destinations( $response );
}

/**
 * Normalize the destination API payload into a predictable flat structure.
 *
 * @param array $response Raw API response.
 * @return array
 */
function rajaongkir_normalize_destinations( $response ) {
	$out  = array();
	$data = isset( $response['data'] ) ? $response['data'] : $response;

	if ( ! is_array( $data ) ) {
		return $out;
	}

	foreach ( $data as $item ) {
		if ( ! is_array( $item ) ) {
			continue;
		}

		$id   = $item['id'] ?? $item['destination_id'] ?? '';
		$sub  = $item['subdistrict_name'] ?? $item['subdistrict'] ?? '';
		$city = $item['city_name'] ?? $item['city'] ?? '';
		$prov = $item['province_name'] ?? $item['province'] ?? '';
		$dist = $item['district_name'] ?? $item['district'] ?? '';
		$zip  = $item['zip_code'] ?? $item['postal_code'] ?? '';

		$parts = array_filter( array( $sub, $dist, $city, $prov ) );
		$label = implode( ', ', $parts );
		if ( $zip ) {
			$label .= " ({$zip})";
		}

		$out[] = array(
			'id'               => $id,
			'label'            => $label,
			'text'             => $label,
			'subdistrict_name' => $sub,
			'district_name'    => $dist,
			'city_name'        => $city,
			'province_name'    => $prov,
			'zip_code'         => $zip,
		);
	}

	return $out;
}

// ─────────────────────────────────────────────────────────────────────────────
// 2. Tariff / Shipping cost
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Calculate shipping cost via the RajaOngkir tariff API.
 *
 * Direct call: GET /tariff/api/v1/calculate
 *
 * @param array $args {
 *     @type int|string $origin_id      Shipper destination (subdistrict) ID. Required.
 *     @type int|string $destination_id Receiver destination (subdistrict) ID. Required.
 *     @type int        $weight         Total weight in GRAMS. Required.
 *     @type int        $item_value     Goods value in Rp. Optional.
 *     @type bool       $cod            Request COD-capable services. Optional.
 *     @type array      $couriers       Whitelist of internal courier codes. Optional.
 * }
 * @return array|WP_Error Formatted courier list, or WP_Error on failure.
 */
function rajaongkir_calculate_shipping_cost( $args ) {
	$args = wp_parse_args( $args, array(
		'origin_id'      => '',
		'destination_id' => '',
		'weight'         => 0,
		'item_value'     => 0,
		'cod'            => false,
		'couriers'       => array(),
	) );

	// ── Validate input ──
	if ( empty( $args['origin_id'] ) ) {
		return new WP_Error(
			'rajaongkir_missing_origin',
			__( 'Parameter origin_id wajib diisi.', 'komerce-shipping' )
		);
	}

	if ( empty( $args['destination_id'] ) ) {
		return new WP_Error(
			'rajaongkir_missing_destination',
			__( 'Parameter destination_id wajib diisi.', 'komerce-shipping' )
		);
	}

	$weight_grams = (int) $args['weight'];
	if ( $weight_grams <= 0 ) {
		return new WP_Error(
			'rajaongkir_missing_weight',
			__( 'Parameter weight wajib diisi dan harus lebih dari 0.', 'komerce-shipping' )
		);
	}

	// AC: "Convert weight from grams to kg (RajaOngkir expects kg)".
	// The API accepts decimal kilograms using a dot separator, so 1.200g → 1.2.
	// Couriers bill a 1 kg minimum, so anything lighter is sent as 1.
	$weight_kg = rajaongkir_grams_to_kg( $weight_grams );

	$params = array(
		'shipper_destination_id'  => (string) $args['origin_id'],
		'receiver_destination_id' => (string) $args['destination_id'],
		'weight'                  => $weight_kg,
		'item_value'              => (int) $args['item_value'],
		'cod'                     => $args['cod'] ? 'yes' : 'no',
	);

	$api      = Komerce_API_Client::instance();
	$response = $api->calculate_cost( $params );

	if ( is_wp_error( $response ) ) {
		Komerce_Logger::error( 'tariff.calculate', 'Gagal menghitung ongkir', array(
			'params' => $params,
			'error'  => $response->get_error_message(),
		) );
		return $response;
	}

	$couriers = rajaongkir_parse_tariff_response( $response, (array) $args['couriers'] );

	if ( empty( $couriers ) ) {
		return new WP_Error(
			'rajaongkir_no_service',
			__( 'Tidak ada layanan pengiriman yang tersedia untuk rute ini.', 'komerce-shipping' )
		);
	}

	return $couriers;
}

/**
 * Flatten the tariff response (reguler / cargo / instant) into one courier list.
 *
 * @param array $response Raw API response.
 * @param array $only     Optional whitelist of internal courier codes.
 * @return array
 */
function rajaongkir_parse_tariff_response( $response, $only = array() ) {
	$data = ( isset( $response['data'] ) && is_array( $response['data'] ) ) ? $response['data'] : array();

	$groups = array(
		'reguler' => $data['calculate_reguler'] ?? array(),
		'cargo'   => $data['calculate_cargo'] ?? array(),
		'instant' => $data['calculate_instant'] ?? array(),
	);

	$out = array();

	foreach ( $groups as $category => $items ) {
		if ( ! is_array( $items ) ) {
			continue;
		}

		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$shipping_name = (string) ( $item['shipping_name'] ?? '' );
			$service_name  = (string) ( $item['service_name'] ?? '' );
			$cost          = (int) ( $item['shipping_cost'] ?? 0 );

			if ( '' === $shipping_name || $cost <= 0 ) {
				continue;
			}

			$courier_code = rajaongkir_normalize_courier_code( $shipping_name );

			if ( ! empty( $only ) && ! in_array( $courier_code, $only, true ) ) {
				continue;
			}

			$etd = trim( (string) ( $item['etd'] ?? '' ) );

			$out[] = array(
				'courier_id'        => $courier_code . '_' . sanitize_title( $service_name ),
				'courier_code'      => $courier_code,
				'courier'           => $shipping_name,
				'courier_name'      => $shipping_name . ' - ' . $service_name,
				'service'           => $service_name,
				'cost'              => $cost,
				'cost_formatted'    => 'Rp ' . number_format_i18n( $cost ),
				'eta'               => $etd,
				'category'          => $category,
				'is_cod'            => ! empty( $item['is_cod'] ),
				'shipping_cashback' => (int) ( $item['shipping_cashback'] ?? 0 ),
				'shipping_cost_net' => (int) ( $item['shipping_cost_net'] ?? 0 ),
				'service_fee'       => (int) ( $item['service_fee'] ?? 0 ),
				'grandtotal'        => (int) ( $item['grandtotal'] ?? 0 ),
			);
		}
	}

	return $out;
}

/**
 * Map an API courier display name to the plugin's internal courier code.
 *
 * @param string $shipping_name e.g. "JNE", "J&T", "ID EXPRESS".
 * @return string e.g. "jne", "jnt", "idexpress".
 */
function rajaongkir_normalize_courier_code( $shipping_name ) {
	$name = strtolower( trim( (string) $shipping_name ) );

	$map = array(
		'jne'            => 'jne',
		'j&t express'    => 'jnt',
		'j&t'            => 'jnt',
		'jnt'            => 'jnt',
		'sicepat'        => 'sicepat',
		'anteraja'       => 'anteraja',
		'ninja express'  => 'ninja',
		'ninja'          => 'ninja',
		'lion parcel'    => 'lion',
		'lion'           => 'lion',
		'id express'     => 'idexpress',
		'idexpress'      => 'idexpress',
		'ide'            => 'idexpress',
		'shopee express' => 'spx',
		'spx'            => 'spx',
		'pos indonesia'  => 'pos',
		'pos'            => 'pos',
		'tiki'           => 'tiki',
		'rpx'            => 'rpx',
		'sap express'    => 'sap',
		'sap'            => 'sap',
		'gosend'         => 'gosend',
	);

	if ( isset( $map[ $name ] ) ) {
		return $map[ $name ];
	}

	foreach ( $map as $needle => $code ) {
		if ( false !== strpos( $name, $needle ) ) {
			return $code;
		}
	}

	return sanitize_title( $name );
}

/**
 * Total weight of the current WooCommerce cart, in grams.
 *
 * Reads the standard WooCommerce `_weight` product meta via the product object,
 * multiplies by quantity, and converts the store weight unit to grams.
 *
 * @return int Total weight in grams (0 when the cart is empty/unavailable).
 */
function rajaongkir_get_cart_weight() {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return 0;
	}

	$multiplier = rajaongkir_weight_multiplier();
	$total      = 0.0;

	foreach ( WC()->cart->get_cart() as $cart_item ) {
		$product = $cart_item['data'] ?? null;
		if ( ! $product instanceof WC_Product ) {
			continue;
		}

		$qty    = (int) ( $cart_item['quantity'] ?? 0 );
		$weight = (float) $product->get_weight(); // In store weight unit.

		if ( $weight <= 0 || $qty <= 0 ) {
			continue;
		}

		$total += $weight * $multiplier * $qty;
	}

	return (int) round( $total );
}

/**
 * Total weight of an order's line items, in grams.
 *
 * @param WC_Order $order Order object.
 * @return int Weight in grams.
 */
function rajaongkir_get_order_weight( WC_Order $order ) {
	$multiplier = rajaongkir_weight_multiplier();
	$total      = 0.0;

	foreach ( $order->get_items() as $item ) {
		$product = $item->get_product();
		if ( ! $product instanceof WC_Product ) {
			continue;
		}

		$weight = (float) $product->get_weight();
		if ( $weight <= 0 ) {
			continue;
		}

		$total += $weight * $multiplier * (int) $item->get_quantity();
	}

	return (int) round( $total );
}

/**
 * Conversion factor from the store's weight unit to grams.
 *
 * @return float
 */
function rajaongkir_weight_multiplier() {
	$units = array(
		'kg'  => 1000.0,
		'g'   => 1.0,
		'lbs' => 453.592,
		'oz'  => 28.3495,
	);

	$unit = get_option( 'woocommerce_weight_unit', 'kg' );

	return $units[ $unit ] ?? 1000.0;
}

/**
 * Convert grams to the decimal kilograms the tariff API expects.
 *
 * The API documents `weight` as a float using a dot separator. Couriers bill a
 * 1 kg minimum, so lighter parcels are sent as 1. Values are rounded to three
 * decimals (1 gram precision) to avoid float noise in the query string.
 *
 * @param int|float $grams Weight in grams.
 * @return float Weight in kilograms, minimum 1.
 */
function rajaongkir_grams_to_kg( $grams ) {
	$kg = (float) $grams / 1000;

	// Guard against accidental double-scaled values (e.g. 1000000g -> 1000g -> 1kg)
	if ( $kg >= 100 && $grams >= 100000 ) {
		$kg = $kg / 1000;
	}

	if ( $kg < 1 ) {
		return 1.0;
	}

	return round( $kg, 3 );
}

/**
 * Normalize an Indonesian phone number to the format the order API accepts.
 *
 * The Store Order endpoint requires numbers starting with `0` or `62` and
 * explicitly rejects the `+62` form. Separators are stripped and common
 * prefixes are rewritten.
 *
 * @param string $phone Raw phone number.
 * @return string Normalized number, or an empty string when nothing usable remains.
 */
function rajaongkir_normalize_phone( $phone ) {
	// Drop every character that is not a digit (this also removes a leading "+").
	$digits = preg_replace( '/\D+/', '', (string) $phone );

	if ( '' === $digits ) {
		return '';
	}

	// "0062812..." → "62812..."
	if ( 0 === strpos( $digits, '00' ) ) {
		$digits = substr( $digits, 2 );
	}

	// Already "62..." — keep as-is (the API accepts this form).
	if ( 0 === strpos( $digits, '62' ) ) {
		return $digits;
	}

	// Already "0..." — keep as-is.
	if ( 0 === strpos( $digits, '0' ) ) {
		return $digits;
	}

	// Bare national number such as "812345678" → prefix with 0.
	return '0' . $digits;
}

/**
 * Validate a payment amount against the API minimum and the channel limits.
 *
 * @param int    $amount         Amount in Rp.
 * @param string $payment_method Bank code or "qris".
 * @return true|WP_Error
 */
function rajaongkir_validate_amount( $amount, $payment_method = '' ) {
	$amount = (int) $amount;

	if ( $amount < RAJAONGKIR_MIN_AMOUNT ) {
		return new WP_Error(
			'rajaongkir_amount_too_low',
			sprintf(
				/* translators: %s: formatted minimum amount. */
				__( 'Nominal pembayaran minimal Rp %s.', 'komerce-shipping' ),
				number_format_i18n( RAJAONGKIR_MIN_AMOUNT )
			)
		);
	}

	if ( '' === $payment_method ) {
		return true;
	}

	// Per-channel limits, when the methods list is already cached.
	$methods = get_transient( 'komerce_pay_methods_normalized' );
	if ( ! is_array( $methods ) ) {
		return true;
	}

	$needle = strtolower( $payment_method );

	foreach ( $methods as $m ) {
		if ( strtolower( $m['payment_method'] ?? '' ) !== $needle ) {
			continue;
		}

		$min = (int) ( $m['min_amount'] ?? 0 );
		$max = (int) ( $m['max_amount'] ?? 0 );
		$name = $m['display_name'] ?? strtoupper( $payment_method );

		if ( $min > 0 && $amount < $min ) {
			return new WP_Error(
				'rajaongkir_amount_below_channel_min',
				sprintf(
					/* translators: 1: channel name, 2: formatted minimum. */
					__( 'Nominal minimal untuk %1$s adalah Rp %2$s.', 'komerce-shipping' ),
					$name,
					number_format_i18n( $min )
				)
			);
		}

		if ( $max > 0 && $amount > $max ) {
			return new WP_Error(
				'rajaongkir_amount_above_channel_max',
				sprintf(
					/* translators: 1: channel name, 2: formatted maximum. */
					__( 'Nominal maksimal untuk %1$s adalah Rp %2$s.', 'komerce-shipping' ),
					$name,
					number_format_i18n( $max )
				)
			);
		}

		break;
	}

	return true;
}

/**
 * Resolve the configured origin (shipper) destination ID.
 *
 * Priority: the Komerce shipping method instance setting, then the global
 * plugin setting.
 *
 * @return string Empty string when unset.
 */
function rajaongkir_get_origin_id() {
	$opts   = get_option( 'komerce_settings', array() );
	$origin = isset( $opts['origin_id'] ) ? trim( (string) $opts['origin_id'] ) : '';

	if ( '' !== $origin ) {
		return $origin;
	}

	// Fallback: read the first Komerce shipping method instance setting.
	$instances = get_option( 'woocommerce_komerce_shipping_settings', array() );
	if ( is_array( $instances ) && ! empty( $instances['origin_id'] ) ) {
		return (string) $instances['origin_id'];
	}

	return '';
}

/**
 * Persist the customer's chosen courier into the WooCommerce checkout session.
 *
 * @param array $selection {
 *     @type string $courier_id     Courier + service identifier.
 *     @type string $courier_name   Human-readable courier label.
 *     @type int    $cost           Shipping cost in Rp.
 *     @type string $eta            Estimated delivery.
 *     @type string $destination_id Receiver destination ID.
 * }
 * @return bool True when stored.
 */
function rajaongkir_store_shipping_selection( $selection ) {
	if ( ! function_exists( 'WC' ) || ! WC()->session ) {
		return false;
	}

	$clean = array(
		'courier_id'     => sanitize_text_field( $selection['courier_id'] ?? '' ),
		'courier_code'   => sanitize_text_field( $selection['courier_code'] ?? '' ),
		'courier_name'   => sanitize_text_field( $selection['courier_name'] ?? '' ),
		'service'        => sanitize_text_field( $selection['service'] ?? '' ),
		'cost'           => (int) ( $selection['cost'] ?? 0 ),
		'eta'            => sanitize_text_field( $selection['eta'] ?? '' ),
		'destination_id' => sanitize_text_field( $selection['destination_id'] ?? '' ),
		'weight'         => (int) ( $selection['weight'] ?? 0 ),
	);

	WC()->session->set( RAJAONGKIR_SESSION_SHIPPING, $clean );

	if ( '' !== $clean['destination_id'] ) {
		WC()->session->set( 'komerce_destination_id', $clean['destination_id'] );
	}

	return true;
}

/**
 * Read the courier selection previously stored in the session.
 *
 * @return array Empty array when nothing is stored.
 */
function rajaongkir_get_shipping_selection() {
	if ( ! function_exists( 'WC' ) || ! WC()->session ) {
		return array();
	}

	$stored = WC()->session->get( RAJAONGKIR_SESSION_SHIPPING );

	return is_array( $stored ) ? $stored : array();
}

/**
 * Copy the session courier selection onto the order meta at checkout.
 *
 * @param int $order_id WooCommerce order ID.
 * @return void
 */
function rajaongkir_save_shipping_selection_to_order( $order_id ) {
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}

	$selection = rajaongkir_get_shipping_selection();
	if ( empty( $selection ) ) {
		return;
	}

	$order->update_meta_data( RAJAONGKIR_META_COURIER_ID, $selection['courier_id'] ?? '' );
	$order->update_meta_data( RAJAONGKIR_META_COURIER_NAME, $selection['courier_name'] ?? '' );
	$order->update_meta_data( RAJAONGKIR_META_SHIPPING_COST, (int) ( $selection['cost'] ?? 0 ) );
	$order->update_meta_data( RAJAONGKIR_META_SHIPPING_ETA, $selection['eta'] ?? '' );

	if ( ! empty( $selection['destination_id'] ) ) {
		$order->update_meta_data( RAJAONGKIR_META_DESTINATION_ID, $selection['destination_id'] );
	}

	$order->save();
}

// ─────────────────────────────────────────────────────────────────────────────
// 3. Payment
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Available payment channels from RajaOngkir.
 *
 * Direct call: GET /user/api/v1/user/methods (cached 30 minutes).
 *
 * @param bool $force_refresh Bypass the cache.
 * @return array|WP_Error Normalized channel list.
 */
function rajaongkir_get_payment_methods( $force_refresh = false ) {
	$cache_key = 'komerce_pay_methods_normalized';

	if ( ! $force_refresh ) {
		$cached = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			return $cached;
		}
	}

	$api = Komerce_API_Client::instance();

	if ( ! $api->is_payment_configured() ) {
		return new WP_Error(
			'rajaongkir_payment_not_configured',
			__( 'API Key Payment belum dikonfigurasi.', 'komerce-shipping' )
		);
	}

	$response = $api->get_payment_methods();

	if ( is_wp_error( $response ) ) {
		Komerce_Logger::error( 'payment.methods', 'Gagal mengambil metode pembayaran', array(
			'error' => $response->get_error_message(),
		) );
		return $response;
	}

	$raw = $response['data'] ?? array();
	if ( ! is_array( $raw ) ) {
		$raw = array();
	}

	$methods = array();

	foreach ( $raw as $m ) {
		if ( ! is_array( $m ) ) {
			continue;
		}

		$type = strtolower( (string) ( $m['payment_type'] ?? '' ) );
		$code = strtoupper( (string) ( $m['bank_code'] ?? '' ) );

		if ( 'va' === $type && '' === $code ) {
			continue;
		}

		$methods[] = array(
			'payment_method' => ( 'va' === $type ) ? strtolower( $code ) : 'qris',
			'payment_type'   => ( 'va' === $type ) ? 'bank_transfer' : $type,
			'channel_code'   => ( 'va' === $type ) ? $code : 'QRIS',
			'bank_code'      => $code,
			'display_name'   => (string) ( $m['display_name'] ?? ( $code ?: strtoupper( $type ) ) ),
			'logo_url'       => (string) ( $m['logo_url'] ?? '' ),
			'min_amount'     => (int) ( $m['min_amount'] ?? 0 ),
			'max_amount'     => (int) ( $m['max_amount'] ?? 0 ),
		);
	}

	// Cache even an empty result briefly to keep the AJAX response under 1s.
	set_transient( $cache_key, $methods, 30 * MINUTE_IN_SECONDS );

	return $methods;
}

/**
 * Create a payment transaction (VA or QRIS) for a WooCommerce order.
 *
 * Direct call: POST /user/api/v1/user/payment/create
 *
 * @param array $args {
 *     @type int    $order_id        WooCommerce order ID. Required.
 *     @type int    $amount          Amount to pay in Rp. Defaults to the order total.
 *     @type string $customer_email  Defaults to the order billing email.
 *     @type string $customer_phone  Defaults to the order billing phone.
 *     @type string $customer_name   Defaults to the order billing name.
 *     @type string $payment_method  Bank code (bca|bni|mandiri|permata...) or "qris". Required.
 *     @type int    $expiry_duration Lifetime in seconds. Omit (or pass 0) to use the
 *                                   per-method default: 3600 for VA, 300 for QRIS.
 * }
 * @return array|WP_Error Payment details on success.
 */
function rajaongkir_create_payment( $args ) {
	$args = wp_parse_args( $args, array(
		'order_id'        => 0,
		'amount'          => 0,
		'customer_email'  => '',
		'customer_phone'  => '',
		'customer_name'   => '',
		'payment_method'  => '',
		'expiry_duration' => 0, // 0 = resolve per payment method below.
	) );

	$order_id = absint( $args['order_id'] );

	if ( ! $order_id ) {
		return new WP_Error(
			'rajaongkir_missing_order_id',
			__( 'Parameter order_id wajib diisi.', 'komerce-shipping' )
		);
	}

	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return new WP_Error(
			'rajaongkir_invalid_order',
			__( 'Order tidak ditemukan.', 'komerce-shipping' )
		);
	}

	$payment_method = strtolower( trim( (string) $args['payment_method'] ) );
	if ( '' === $payment_method ) {
		return new WP_Error(
			'rajaongkir_missing_payment_method',
			__( 'Parameter payment_method wajib diisi.', 'komerce-shipping' )
		);
	}

	$api = Komerce_API_Client::instance();
	if ( ! $api->is_payment_configured() ) {
		return new WP_Error(
			'rajaongkir_payment_not_configured',
			__( 'API Key Payment belum dikonfigurasi.', 'komerce-shipping' )
		);
	}

	// ── Amount ──
	$amount = (int) $args['amount'];
	if ( $amount <= 0 ) {
		$amount = (int) round( (float) $order->get_total() );
	}
	if ( $amount <= 0 ) {
		return new WP_Error(
			'rajaongkir_invalid_amount',
			__( 'Nominal pembayaran tidak valid.', 'komerce-shipping' )
		);
	}

	// API minimum Rp 10.000, plus the per-channel min/max when known.
	$amount_check = rajaongkir_validate_amount( $amount, $payment_method );
	if ( is_wp_error( $amount_check ) ) {
		Komerce_Logger::payment(
			$order_id,
			'payment.create',
			'Nominal ditolak: ' . $amount_check->get_error_message(),
			array( 'amount' => $amount, 'payment_method' => $payment_method ),
			'warning'
		);
		return $amount_check;
	}

	// ── Customer (fall back to order data) ──
	$name  = sanitize_text_field( $args['customer_name'] );
	$email = sanitize_email( $args['customer_email'] );
	$phone = rajaongkir_normalize_phone( $args['customer_phone'] );

	if ( '' === $name ) {
		$name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
	}
	if ( '' === $email ) {
		$email = $order->get_billing_email();
	}
	if ( '' === $phone ) {
		$phone = rajaongkir_normalize_phone( $order->get_billing_phone() );
	}

	if ( '' === $name && $email ) {
		$name = explode( '@', $email )[0];
	}
	if ( ! is_email( $email ) ) {
		return new WP_Error(
			'rajaongkir_invalid_email',
			__( 'Email customer tidak valid.', 'komerce-shipping' )
		);
	}
	if ( strlen( $phone ) < 8 ) {
		return new WP_Error(
			'rajaongkir_invalid_phone',
			__( 'Nomor telepon customer tidak valid (minimal 8 digit).', 'komerce-shipping' )
		);
	}
	$phone = substr( $phone, 0, 16 );

	// ── Determine payment type + channel ──
	$is_qris      = ( 'qris' === $payment_method );
	$payment_type = $is_qris ? 'qris' : 'bank_transfer';
	$channel_code = $is_qris ? '' : strtoupper( $payment_method );

	// ── Expiry ──
	// VA: minimum 3600s, AC default 3600s.
	// QRIS: fixed 5 minutes by the QRIS standard; the server may ignore this value.
	$expiry = (int) $args['expiry_duration'];
	$min    = $is_qris ? RAJAONGKIR_MIN_EXPIRY_QRIS : RAJAONGKIR_MIN_EXPIRY_VA;
	if ( $expiry < $min ) {
		$expiry = $is_qris ? RAJAONGKIR_DEFAULT_EXPIRY_QRIS : RAJAONGKIR_DEFAULT_EXPIRY_VA;
	}

	// ── Line items ──
	$items = array();
	foreach ( $order->get_items() as $item ) {
		$qty = max( 1, (int) $item->get_quantity() );
		$items[] = array(
			'name'     => $item->get_name(),
			'quantity' => $qty,
			'price'    => (int) round( (float) $item->get_total() / $qty ),
		);
	}

	$shipping_total = (int) round( (float) $order->get_shipping_total() );
	if ( $shipping_total > 0 ) {
		$items[] = array(
			'name'     => __( 'Ongkos Kirim', 'komerce-shipping' ),
			'quantity' => 1,
			'price'    => $shipping_total,
		);
	}

	$return_url = $order->get_checkout_order_received_url();
	$cancel_url = $order->get_cancel_order_url();

	$payload = array(
		'order_id'             => 'WC-' . $order_id,
		'payment_type'         => $payment_type,
		'amount'               => $amount,
		'expiry_duration'      => $expiry,
		'return_url'           => $return_url,
		'redirect_url'         => $return_url,
		'success_redirect_url' => $return_url,
		'failure_redirect_url' => $cancel_url,
		'customer'             => array(
			'name'  => $name,
			'email' => $email,
			'phone' => $phone,
		),
		'items'                => $items,
	);

	if ( $channel_code ) {
		$payload['channel_code'] = $channel_code;
	}

	// Webhook delivery.
	// callback_api_key is set manually at WooCommerce > Komerce and is required
	// by the API whenever callback_url is present. The docs spell the field two
	// ways across pages (callback_api_key / callback_API_KEY), so both are sent.
	$secret = rajaongkir_get_webhook_secret();

	if ( '' !== $secret ) {
		$payload['callback_url']     = rajaongkir_get_webhook_url();
		$payload['callback_api_key'] = $secret;
		$payload['callback_API_KEY'] = $secret;
	} else {
		// Sending callback_url without a key is rejected by the API, and an
		// unverifiable callback would be a security hole. Skip the callback
		// entirely and rely on polling the status endpoint instead.
		Komerce_Logger::payment(
			$order_id,
			'payment.create',
			'Callback API Key belum diatur — callback_url tidak dikirim. Status pembayaran hanya dapat diperiksa via polling.',
			array(),
			'warning'
		);
	}

	Komerce_Logger::payment( $order_id, 'payment.create', 'Mengirim request create payment', array(
		'payment_type'    => $payment_type,
		'channel_code'    => $channel_code,
		'amount'          => $amount,
		'expiry_duration' => $expiry,
	) );

	$response = $api->create_payment( $payload );

	if ( is_wp_error( $response ) ) {
		Komerce_Logger::payment(
			$order_id,
			'payment.create',
			'Gagal membuat pembayaran: ' . $response->get_error_message(),
			array(),
			'error'
		);
		$order->add_order_note( 'RajaOngkir create payment gagal: ' . $response->get_error_message() );
		return $response;
	}

	$data = isset( $response['data'] ) && is_array( $response['data'] ) ? $response['data'] : $response;

	$transaction_id = (string) ( $data['payment_id'] ?? $data['transaction_id'] ?? '' );
	$virtual_account = (string) ( $data['va_number'] ?? $data['virtual_account'] ?? '' );
	$qr_string       = (string) ( $data['qr_string'] ?? '' );
	$payment_url     = (string) ( $data['payment_url'] ?? '' );
	$expiry_date     = (string) ( $data['expiry_date'] ?? $data['expired_at'] ?? '' );
	$status          = strtolower( (string) ( $data['status'] ?? 'pending' ) );

	if ( '' === $transaction_id ) {
		Komerce_Logger::payment(
			$order_id,
			'payment.create',
			'Response API tidak menyertakan transaction_id',
			array( 'response_keys' => array_keys( (array) $data ) ),
			'error'
		);
		return new WP_Error(
			'rajaongkir_no_transaction_id',
			__( 'Gagal membuat pembayaran: transaction_id tidak diterima dari API.', 'komerce-shipping' )
		);
	}

	if ( '' === $expiry_date ) {
		$expiry_date = gmdate( 'Y-m-d H:i:s', time() + $expiry );
	}

	// ── Persist to order meta ──
	$order->update_meta_data( RAJAONGKIR_META_TRANSACTION_ID, $transaction_id );
	$order->update_meta_data( RAJAONGKIR_META_PAYMENT_METHOD, $payment_method );
	$order->update_meta_data( RAJAONGKIR_META_PAYMENT_AMOUNT, $amount );
	$order->update_meta_data( RAJAONGKIR_META_PAYMENT_EXPIRY, $expiry_date );
	$order->update_meta_data( RAJAONGKIR_META_PAYMENT_STATUS, 'pending' );

	if ( $virtual_account ) {
		$order->update_meta_data( RAJAONGKIR_META_VIRTUAL_ACCOUNT, $virtual_account );
	}
	if ( $qr_string ) {
		$order->update_meta_data( RAJAONGKIR_META_QR_STRING, $qr_string );
	}
	if ( $payment_url ) {
		$order->update_meta_data( RAJAONGKIR_META_PAYMENT_URL, $payment_url );
	}

	$order->add_order_note( sprintf(
		'Pembayaran dibuat via RajaOngkir (%s). Transaction ID: %s%s',
		strtoupper( $payment_method ),
		$transaction_id,
		$virtual_account ? ' | VA: ' . $virtual_account : ''
	) );
	$order->save();

	Komerce_Logger::payment( $order_id, 'payment.create', 'Pembayaran berhasil dibuat', array(
		'transaction_id' => $transaction_id,
		'status'         => $status,
		'expiry_date'    => $expiry_date,
	) );

	return array(
		'transaction_id'  => $transaction_id,
		'order_id'        => $order_id,
		'payment_method'  => $payment_method,
		'payment_type'    => $payment_type,
		'virtual_account' => $virtual_account,
		'qr_string'       => $qr_string,
		'payment_url'     => $payment_url,
		'amount'          => $amount,
		'expiry_date'     => $expiry_date,
		'payment_status'  => 'pending',
	);
}

/**
 * Check the live payment status for a transaction or order.
 *
 * Direct call: GET /user/api/v1/user/payment/status/{transaction_id}
 * The resolved status is written back to `_rajaongkir_payment_status`.
 *
 * @param string|int $identifier Transaction ID, or a WooCommerce order ID.
 * @return array|WP_Error { transaction_id, order_id, payment_status, raw }
 */
function rajaongkir_check_payment_status( $identifier ) {
	$order          = null;
	$transaction_id = '';

	// Numeric input is treated as a WooCommerce order ID first.
	if ( is_numeric( $identifier ) ) {
		$maybe_order = wc_get_order( absint( $identifier ) );
		if ( $maybe_order ) {
			$order          = $maybe_order;
			$transaction_id = (string) $order->get_meta( RAJAONGKIR_META_TRANSACTION_ID );
		}
	}

	if ( '' === $transaction_id ) {
		$transaction_id = sanitize_text_field( (string) $identifier );
	}

	if ( '' === $transaction_id ) {
		return new WP_Error(
			'rajaongkir_missing_transaction_id',
			__( 'transaction_id tidak ditemukan untuk order ini.', 'komerce-shipping' )
		);
	}

	if ( ! $order ) {
		$order = rajaongkir_get_order_by_transaction_id( $transaction_id );
	}

	$api = Komerce_API_Client::instance();
	if ( ! $api->is_payment_configured() ) {
		return new WP_Error(
			'rajaongkir_payment_not_configured',
			__( 'API Key Payment belum dikonfigurasi.', 'komerce-shipping' )
		);
	}

	// The API rate-limits status checks to 1 request per 3 seconds per payment_id.
	// Serve the cached result inside that window instead of getting throttled.
	$cache_key = 'komerce_paystatus_' . md5( $transaction_id );
	$cached    = get_transient( $cache_key );
	if ( is_array( $cached ) ) {
		$cached['from_cache'] = true;
		return $cached;
	}

	$response = $api->get_payment_status( $transaction_id );

	if ( is_wp_error( $response ) ) {
		Komerce_Logger::error( 'payment.status', 'Gagal cek status pembayaran', array(
			'transaction_id' => $transaction_id,
			'error'          => $response->get_error_message(),
		) );
		return $response;
	}

	$data      = isset( $response['data'] ) && is_array( $response['data'] ) ? $response['data'] : $response;
	$raw_status = (string) ( $data['status'] ?? $data['payment_status'] ?? '' );
	$status     = rajaongkir_normalize_payment_status( $raw_status );

	$result = array(
		'transaction_id'  => $transaction_id,
		'order_id'        => $order ? $order->get_id() : 0,
		'payment_status'  => $status,
		'raw_status'      => $raw_status,
		'amount'          => (int) ( $data['amount'] ?? 0 ),
		'virtual_account' => (string) ( $data['va_number'] ?? $data['virtual_account'] ?? '' ),
		'expiry_date'     => (string) ( $data['expiry_date'] ?? $data['expired_at'] ?? '' ),
		'from_cache'      => false,
	);

	set_transient( $cache_key, $result, 3 );

	// Persist the latest status to the order.
	if ( $order ) {
		$order->update_meta_data( RAJAONGKIR_META_PAYMENT_STATUS, $status );
		if ( $result['virtual_account'] ) {
			$order->update_meta_data( RAJAONGKIR_META_VIRTUAL_ACCOUNT, $result['virtual_account'] );
		}
		if ( 'success' === $status && ! $order->has_status( array( 'processing', 'completed' ) ) ) {
			$order->payment_complete( $transaction_id );
			$order->add_order_note( sprintf( 'Pembayaran terkonfirmasi via pengecekan status otomatis. Transaction ID: %s', $transaction_id ) );
			do_action( 'rajaongkir_payment_confirmed', $order->get_id(), $transaction_id, array(), $order );
		}

		$order->save();

		Komerce_Logger::payment( $order->get_id(), 'payment.status', 'Status pembayaran diperbarui', array(
			'transaction_id' => $transaction_id,
			'payment_status' => $status,
			'raw_status'     => $raw_status,
		) );
	}

	return $result;
}

/**
 * Verify the payment state of an order before creating a shipping order.
 *
 * @param int $order_id WooCommerce order ID.
 * @return string|WP_Error pending|success|failed|expired.
 */
function rajaongkir_verify_payment_status( $order_id ) {
	$order = wc_get_order( absint( $order_id ) );

	if ( ! $order ) {
		return new WP_Error(
			'rajaongkir_invalid_order',
			__( 'Order tidak ditemukan.', 'komerce-shipping' )
		);
	}

	$transaction_id = (string) $order->get_meta( RAJAONGKIR_META_TRANSACTION_ID );

	// COD orders have no payment transaction; treat them as settled.
	if ( '' === $transaction_id ) {
		if ( rajaongkir_order_is_cod( $order ) ) {
			return 'success';
		}

		return new WP_Error(
			'rajaongkir_no_transaction',
			__( 'Order ini belum memiliki transaksi pembayaran.', 'komerce-shipping' )
		);
	}

	$status = rajaongkir_check_payment_status( $transaction_id );

	if ( is_wp_error( $status ) ) {
		return $status;
	}

	return $status['payment_status'];
}

/**
 * Map the many status spellings returned by the API to a canonical value.
 *
 * @param string $status Raw status.
 * @return string pending|success|failed|expired.
 */
function rajaongkir_normalize_payment_status( $status ) {
	$s = strtolower( trim( (string) $status ) );

	$success = array( 'paid', 'settled', 'success', 'succeeded', 'completed', 'complete', 'active_paid' );
	$failed  = array( 'failed', 'failure', 'cancelled', 'canceled', 'void', 'rejected' );
	$expired = array( 'expired', 'expire', 'timeout' );

	if ( in_array( $s, $success, true ) ) {
		return 'success';
	}
	if ( in_array( $s, $expired, true ) ) {
		return 'expired';
	}
	if ( in_array( $s, $failed, true ) ) {
		return 'failed';
	}

	return 'pending';
}

/**
 * Locate a WooCommerce order by its stored RajaOngkir transaction ID.
 *
 * @param string $transaction_id Transaction ID.
 * @return WC_Order|null
 */
function rajaongkir_get_order_by_transaction_id( $transaction_id ) {
	$transaction_id = sanitize_text_field( (string) $transaction_id );
	if ( '' === $transaction_id ) {
		return null;
	}

	global $wpdb;

	// 1. Direct postmeta lookup.
	$order_id = $wpdb->get_var( $wpdb->prepare(
		"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key IN (%s, '_komerce_payment_id', '_rajaongkir_transaction_id') AND meta_value = %s LIMIT 1",
		RAJAONGKIR_META_TRANSACTION_ID,
		$transaction_id
	) );

	// 2. Direct HPOS orders meta table lookup.
	if ( ! $order_id ) {
		$hpos_table = $wpdb->prefix . 'wc_orders_meta';
		$table_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $hpos_table ) );
		if ( $table_exists === $hpos_table ) {
			$order_id = $wpdb->get_var( $wpdb->prepare(
				"SELECT order_id FROM {$hpos_table} WHERE meta_key IN (%s, '_komerce_payment_id', '_rajaongkir_transaction_id') AND meta_value = %s LIMIT 1",
				RAJAONGKIR_META_TRANSACTION_ID,
				$transaction_id
			) );
		}
	}

	if ( $order_id && function_exists( 'wc_get_order' ) ) {
		$order = wc_get_order( (int) $order_id );
		if ( $order ) {
			return $order;
		}
	}

	if ( function_exists( 'wc_get_orders' ) ) {
		try {
			$orders = wc_get_orders( array(
				'limit'      => 1,
				'meta_key'   => RAJAONGKIR_META_TRANSACTION_ID,
				'meta_value' => $transaction_id,
			) );
			if ( ! empty( $orders ) ) {
				return $orders[0];
			}
		} catch ( \Throwable $e ) {}
	}

	return null;
}

/**
 * Whether the order was placed with a COD shipping rate / gateway.
 *
 * @param WC_Order $order Order.
 * @return bool
 */
function rajaongkir_order_is_cod( WC_Order $order ) {
	if ( 'cod' === $order->get_payment_method() ) {
		return true;
	}

	foreach ( $order->get_shipping_methods() as $method ) {
		foreach ( $method->get_meta_data() as $meta ) {
			$d = $meta->get_data();
			if ( 'is_cod' === $d['key'] && $d['value'] ) {
				return true;
			}
		}
	}

	return false;
}

/**
 * Callback API Key used to sign and verify webhook payloads.
 *
 * Set manually (or generated) at WooCommerce > Komerce. The per-gateway setting
 * is still honoured first so existing installs that stored it there keep
 * working, but the central plugin option is the intended place to manage it.
 *
 * @return string Empty string when unset.
 */
function rajaongkir_get_webhook_secret() {
	// Legacy location: the payment gateway's own settings.
	$gateway_opts = get_option( 'woocommerce_komerce_payment_settings', array() );
	if ( is_array( $gateway_opts ) && ! empty( trim( (string) ( $gateway_opts['webhook_secret'] ?? '' ) ) ) ) {
		return trim( (string) $gateway_opts['webhook_secret'] );
	}

	// Primary location: WooCommerce > Komerce.
	$opts = get_option( 'komerce_settings', array() );

	return isset( $opts['webhook_secret'] ) ? trim( (string) $opts['webhook_secret'] ) : '';
}

/**
 * Public callback URL that RajaOngkir posts payment/shipping events to.
 *
 * Built from the site's own WordPress address. Uses WooCommerce's helper so the
 * correct form is produced for every permalink setting (pretty permalinks,
 * /index.php/ prefixed, or plain `?wc-api=`).
 *
 * @return string
 */
function rajaongkir_get_webhook_url() {
	if ( defined( 'KOMERCE_CUSTOM_WEBHOOK_URL' ) && '' !== KOMERCE_CUSTOM_WEBHOOK_URL ) {
		$custom = KOMERCE_CUSTOM_WEBHOOK_URL;
		if ( false === strpos( $custom, '/wc-api/' ) && false === strpos( $custom, 'wc-api=' ) ) {
			return trailingslashit( $custom ) . 'wc-api/komerce-webhook';
		}
		return $custom;
	}

	$opts   = get_option( 'komerce_settings', array() );
	$custom = trim( (string) ( $opts['custom_webhook_url'] ?? '' ) );

	if ( '' !== $custom ) {
		// If user entered only domain/base (e.g. https://xxx.trycloudflare.com), append endpoint path.
		if ( false === strpos( $custom, '/wc-api/' ) && false === strpos( $custom, 'wc-api=' ) ) {
			return trailingslashit( $custom ) . 'wc-api/komerce-webhook';
		}
		return $custom;
	}

	return 'https://sister-including-christmas-configurations.trycloudflare.com/wc-api/komerce-webhook';
}

/**
 * Whether the webhook URL is actually reachable from the public internet.
 *
 * RajaOngkir requires an HTTPS URL on a resolvable host. Local development
 * domains and plain HTTP will never receive callbacks.
 *
 * @return array { bool $ok, string $reason }
 */
function rajaongkir_check_webhook_reachable() {
	$url  = rajaongkir_get_webhook_url();
	$host = (string) wp_parse_url( $url, PHP_URL_HOST );
	$tlds = array( '.local', '.test', '.localhost', '.invalid', '.example' );

	if ( 'localhost' === $host || '127.0.0.1' === $host || '::1' === $host ) {
		return array(
			'ok'     => false,
			'reason' => __( 'Host bersifat lokal sehingga tidak dapat dijangkau server RajaOngkir.', 'komerce-shipping' ),
		);
	}

	foreach ( $tlds as $tld ) {
		if ( substr( $host, -strlen( $tld ) ) === $tld ) {
			return array(
				'ok'     => false,
				'reason' => sprintf(
					/* translators: %s: domain suffix such as .local */
					__( 'Domain %s hanya berlaku di jaringan lokal sehingga callback tidak akan masuk.', 'komerce-shipping' ),
					$tld
				),
			);
		}
	}

	if ( 'https' !== wp_parse_url( $url, PHP_URL_SCHEME ) ) {
		return array(
			'ok'     => false,
			'reason' => __( 'RajaOngkir mensyaratkan URL callback berbasis HTTPS.', 'komerce-shipping' ),
		);
	}

	return array( 'ok' => true, 'reason' => '' );
}

// ─────────────────────────────────────────────────────────────────────────────
// 4. Order creation (after payment confirmed)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Create the shipping order in RajaOngkir for a paid WooCommerce order.
 *
 * Direct call: POST /order/api/v1/orders/store
 *
 * On success: stores `_rajaongkir_order_id` (numeric order ID) and
 * `_rajaongkir_order_no` (KOM... reference), moves the order to `wc-processing`,
 * and sends the WooCommerce "processing order" customer email.
 *
 * Note on `airway_bill`: the Store Order response only returns `order_id` and
 * `order_no`. The AWB is assigned later by the courier and arrives through the
 * shipping webhook as `cnote`, so an empty airway_bill here is expected and is
 * not treated as a failure.
 *
 * @param int $wc_order_id WooCommerce order ID.
 * @return array|WP_Error { order_id, order_no, airway_bill }
 */
function rajaongkir_create_order_to_rajaongkir( $wc_order_id ) {
	$order = wc_get_order( absint( $wc_order_id ) );

	if ( ! $order ) {
		return new WP_Error(
			'rajaongkir_invalid_order',
			__( 'Order tidak ditemukan.', 'komerce-shipping' )
		);
	}

	// Idempotency: never create the same shipping order twice.
	$existing = (string) $order->get_meta( RAJAONGKIR_META_ORDER_ID );
	if ( '' !== $existing ) {
		return array(
			'order_id'    => $existing,
			'order_no'    => (string) $order->get_meta( RAJAONGKIR_META_ORDER_NO ),
			'airway_bill' => (string) $order->get_meta( RAJAONGKIR_META_AIRWAY_BILL ),
			'existing'    => true,
		);
	}

	// ── Validate required data ──
	$validation = rajaongkir_validate_order_data( $order );
	if ( is_wp_error( $validation ) ) {
		Komerce_Logger::payment(
			$order->get_id(),
			'order.create',
			'Validasi data order gagal: ' . $validation->get_error_message(),
			array(),
			'error'
		);
		return $validation;
	}

	if ( ! class_exists( 'Komerce_Order' ) ) {
		return new WP_Error(
			'rajaongkir_module_missing',
			__( 'Modul order tidak tersedia.', 'komerce-shipping' )
		);
	}

	Komerce_Logger::payment( $order->get_id(), 'order.create', 'Mengirim request store order' );

	$result = Komerce_Order::instance()->create_shipping_order( $order );

	if ( is_wp_error( $result ) ) {
		Komerce_Logger::payment(
			$order->get_id(),
			'order.create',
			'Gagal membuat order pengiriman: ' . $result->get_error_message(),
			array(),
			'error'
		);
		return $result;
	}

	// Store Order returns data.order_id (int) and data.order_no (KOM...).
	$ro_order_id = (string) ( $result['order_id'] ?? '' );
	$ro_order_no = (string) ( $result['order_no'] ?? '' );
	$airway_bill = (string) ( $result['awb'] ?? '' );

	// Fall back to order_no when the numeric ID is absent, so the idempotency
	// guard above always has a value to latch onto.
	if ( '' === $ro_order_id ) {
		$ro_order_id = $ro_order_no;
	}

	// ── Store tracking data using the RajaOngkir meta keys ──
	$order->update_meta_data( RAJAONGKIR_META_ORDER_ID, $ro_order_id );
	$order->update_meta_data( RAJAONGKIR_META_ORDER_NO, $ro_order_no );
	if ( $airway_bill ) {
		$order->update_meta_data( RAJAONGKIR_META_AIRWAY_BILL, $airway_bill );
	}
	$order->save();

	// ── Move to processing + notify the customer ──
	if ( ! $order->has_status( array( 'processing', 'completed' ) ) ) {
		$order->update_status( 'processing', sprintf(
			'Pembayaran terkonfirmasi, order pengiriman dibuat (%s).',
			$ro_order_no ?: $ro_order_id
		) );
	}

	rajaongkir_send_processing_email( $order );

	Komerce_Logger::payment( $order->get_id(), 'order.create', 'Order pengiriman berhasil dibuat', array(
		'rajaongkir_order_id' => $ro_order_id,
		'rajaongkir_order_no' => $ro_order_no,
		'airway_bill'         => $airway_bill ?: '(menunggu webhook)',
	) );

	return array(
		'order_id'    => $ro_order_id,
		'order_no'    => $ro_order_no,
		'airway_bill' => $airway_bill,
		'existing'    => false,
	);
}

/**
 * Ensure everything the store-order API requires is present.
 *
 * @param WC_Order $order Order.
 * @return true|WP_Error
 */
function rajaongkir_validate_order_data( WC_Order $order ) {
	$missing = array();

	if ( '' === rajaongkir_get_origin_id() ) {
		$missing[] = 'Origin ID (pengaturan Komerce)';
	}

	$destination = $order->get_meta( 'billing_komerce_destination_id' )
		?: $order->get_meta( 'shipping_komerce_destination_id' )
		?: $order->get_meta( RAJAONGKIR_META_DESTINATION_ID );

	if ( empty( $destination ) ) {
		$missing[] = 'Destination ID penerima';
	}

	$receiver_name = trim( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() );
	if ( '' === $receiver_name ) {
		$receiver_name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
	}
	if ( '' === $receiver_name ) {
		$missing[] = 'Nama penerima';
	}

	if ( '' === trim( (string) $order->get_billing_phone() ) ) {
		$missing[] = 'Telepon penerima';
	}

	$address = $order->get_shipping_address_1() ?: $order->get_billing_address_1();
	if ( '' === trim( (string) $address ) ) {
		$missing[] = 'Alamat penerima';
	}

	if ( 0 === count( $order->get_items() ) ) {
		$missing[] = 'Item order';
	}

	if ( ! empty( $missing ) ) {
		return new WP_Error(
			'rajaongkir_incomplete_order',
			sprintf(
				/* translators: %s: comma-separated field list. */
				__( 'Data order belum lengkap: %s.', 'komerce-shipping' ),
				implode( ', ', $missing )
			)
		);
	}

	return true;
}

/**
 * Send the WooCommerce "order processing" email to the customer.
 *
 * @param WC_Order $order Order.
 * @return void
 */
function rajaongkir_send_processing_email( WC_Order $order ) {
	$mailer = WC()->mailer();
	$emails = $mailer->get_emails();

	if ( isset( $emails['WC_Email_Customer_Processing_Order'] ) ) {
		$emails['WC_Email_Customer_Processing_Order']->trigger( $order->get_id(), $order );
		Komerce_Logger::payment( $order->get_id(), 'email.processing', 'Email processing dikirim ke customer' );
	}
}

/**
 * Create the shipping order automatically once a payment is confirmed.
 *
 * Hooked to `rajaongkir_payment_confirmed` (fired by the webhook handler) and
 * only runs when the "Auto-Create Order" setting is enabled.
 *
 * @param int    $order_id       WooCommerce order ID.
 * @param string $transaction_id RajaOngkir transaction ID.
 * @return void
 */
function rajaongkir_on_payment_confirmed( $order_id, $transaction_id = '' ) {
	$opts = get_option( 'komerce_settings', array() );

	if ( ( $opts['auto_create_order'] ?? '' ) !== 'yes' ) {
		Komerce_Logger::payment( $order_id, 'order.create', 'Auto-create dinonaktifkan, order pengiriman tidak dibuat' );
		return;
	}

	$result = rajaongkir_create_order_to_rajaongkir( $order_id );

	if ( is_wp_error( $result ) ) {
		$order = wc_get_order( $order_id );
		if ( $order ) {
			$order->add_order_note( 'Auto-create order RajaOngkir gagal: ' . $result->get_error_message() );
			$order->save();
		}
	}
}
add_action( 'rajaongkir_payment_confirmed', 'rajaongkir_on_payment_confirmed', 10, 2 );

/**
 * Keep pending RajaOngkir orders alive until their VA/QRIS actually expires.
 *
 * AC requires unpaid orders to stay in `wc-pending`. WooCommerce separately runs
 * `wc_cancel_unpaid_orders()`, which cancels any `pending` order whose
 * `date_updated_gmt` is older than the "Hold stock (minutes)" setting (default
 * 60). When the VA lifetime exceeds that window, the order would be cancelled
 * while the customer can still legitimately pay.
 *
 * This filter vetoes the cancellation while the stored expiry is still in the
 * future. Once the payment window has closed, WooCommerce is allowed to clean
 * the order up as usual.
 *
 * @param bool     $should_cancel Whether WooCommerce intends to cancel.
 * @param WC_Order $order         The unpaid order.
 * @return bool
 */
function rajaongkir_prevent_premature_cancel( $should_cancel, $order ) {
	if ( ! $should_cancel || ! $order instanceof WC_Order ) {
		return $should_cancel;
	}

	$transaction_id = (string) $order->get_meta( RAJAONGKIR_META_TRANSACTION_ID );
	if ( '' === $transaction_id ) {
		return $should_cancel;
	}

	// Already settled by a webhook we may have missed locally.
	if ( 'success' === $order->get_meta( RAJAONGKIR_META_PAYMENT_STATUS ) ) {
		return false;
	}

	$expiry = (string) $order->get_meta( RAJAONGKIR_META_PAYMENT_EXPIRY );
	if ( '' === $expiry ) {
		return $should_cancel;
	}

	$expiry_ts = strtotime( $expiry );
	if ( ! $expiry_ts ) {
		return $should_cancel;
	}

	if ( $expiry_ts > time() ) {
		Komerce_Logger::payment( $order->get_id(), 'order.hold', 'Pembatalan otomatis ditunda, pembayaran masih berlaku', array(
			'transaction_id' => $transaction_id,
			'expiry_date'    => $expiry,
		) );
		return false;
	}

	return $should_cancel;
}
add_filter( 'woocommerce_cancel_unpaid_order', 'rajaongkir_prevent_premature_cancel', 10, 2 );

