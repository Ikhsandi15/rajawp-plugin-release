<?php
/**
 * Komerce Logger
 *
 * Centralized audit logging for payment actions, order creation, and webhook events.
 * Writes to the WooCommerce logger (WooCommerce > Status > Logs) so entries are
 * timestamped and viewable from the admin, with a fallback to error_log().
 *
 * AC coverage:
 *   - All payment actions logged with timestamp
 *   - Errors logged for debugging
 *   - Webhook events logged
 *
 * @package WooCommerce\Komerce
 * @since   2.3.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Komerce_Logger' ) ) :
class Komerce_Logger {

	/** WooCommerce log source/handle. */
	const SOURCE = 'komerce';

	/** Option key holding the recent webhook event ring buffer. */
	const OPTION_WEBHOOK_LOG = 'komerce_webhook_log';

	/** Max webhook events retained in the ring buffer. */
	const WEBHOOK_LOG_LIMIT = 50;

	/** @var WC_Logger_Interface|null */
	private static $wc_logger = null;

	/**
	 * Keys that must never be written to the log in clear text.
	 *
	 * @var string[]
	 */
	private static $sensitive_keys = array(
		'api_key',
		'api-key',
		'x-api-key',
		'apikey',
		'callback_api_key',
		'webhook_secret',
		'secret',
		'token',
		'authorization',
		'password',
	);

	/**
	 * Write a log entry.
	 *
	 * @param string $level   debug|info|notice|warning|error|critical|alert|emergency.
	 * @param string $action  Short action identifier, e.g. "payment.create".
	 * @param string $message Human-readable message.
	 * @param array  $context Extra structured data (will be redacted + JSON encoded).
	 * @return void
	 */
	public static function log( $level, $action, $message, $context = array() ) {
		$entry = sprintf( '[%s] %s', $action, $message );

		if ( ! empty( $context ) ) {
			$entry .= ' | ' . wp_json_encode( self::redact( $context ) );
		}

		if ( function_exists( 'wc_get_logger' ) ) {
			if ( null === self::$wc_logger ) {
				self::$wc_logger = wc_get_logger();
			}
			if ( self::$wc_logger ) {
				self::$wc_logger->log( $level, $entry, array( 'source' => self::SOURCE ) );
				return;
			}
		}

		// Fallback: WooCommerce logger unavailable.
		error_log( sprintf( '[Komerce][%s] %s', strtoupper( $level ), $entry ) );
	}

	public static function info( $action, $message, $context = array() ) {
		self::log( 'info', $action, $message, $context );
	}

	public static function debug( $action, $message, $context = array() ) {
		self::log( 'debug', $action, $message, $context );
	}

	public static function warning( $action, $message, $context = array() ) {
		self::log( 'warning', $action, $message, $context );
	}

	public static function error( $action, $message, $context = array() ) {
		self::log( 'error', $action, $message, $context );
	}

	/**
	 * Log a payment action against a specific order.
	 *
	 * @param int    $order_id WooCommerce order ID.
	 * @param string $action   Action identifier, e.g. "payment.create".
	 * @param string $message  Message.
	 * @param array  $context  Extra data.
	 * @param string $level    Log level.
	 * @return void
	 */
	public static function payment( $order_id, $action, $message, $context = array(), $level = 'info' ) {
		$context = array_merge( array( 'order_id' => (int) $order_id ), $context );
		self::log( $level, $action, $message, $context );
	}

	/**
	 * Log a webhook event and retain it in a small ring buffer for admin review.
	 *
	 * @param string $event   Event name, e.g. "payment" or "shipping".
	 * @param string $message Message.
	 * @param array  $context Payload/extra data.
	 * @param string $level   Log level.
	 * @return void
	 */
	public static function webhook( $event, $message, $context = array(), $level = 'info' ) {
		self::log( $level, 'webhook.' . $event, $message, $context );

		$log = get_option( self::OPTION_WEBHOOK_LOG, array() );
		if ( ! is_array( $log ) ) {
			$log = array();
		}

		array_unshift( $log, array(
			'time'    => current_time( 'mysql' ),
			'event'   => $event,
			'level'   => $level,
			'message' => $message,
			'context' => self::redact( $context ),
		) );

		if ( count( $log ) > self::WEBHOOK_LOG_LIMIT ) {
			$log = array_slice( $log, 0, self::WEBHOOK_LOG_LIMIT );
		}

		update_option( self::OPTION_WEBHOOK_LOG, $log, false );
	}

	/**
	 * Retrieve the retained webhook events (newest first).
	 *
	 * @param int $limit Max entries to return.
	 * @return array
	 */
	public static function get_webhook_log( $limit = 20 ) {
		$log = get_option( self::OPTION_WEBHOOK_LOG, array() );
		if ( ! is_array( $log ) ) {
			return array();
		}
		return array_slice( $log, 0, max( 1, (int) $limit ) );
	}

	/**
	 * Clear the retained webhook events.
	 *
	 * @return void
	 */
	public static function clear_webhook_log() {
		delete_option( self::OPTION_WEBHOOK_LOG );
	}

	/**
	 * Recursively mask sensitive values so credentials never reach the log files.
	 *
	 * @param mixed $data Data to redact.
	 * @return mixed
	 */
	private static function redact( $data ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}

		$out = array();
		foreach ( $data as $key => $value ) {
			$needle = is_string( $key ) ? strtolower( $key ) : '';

			$is_sensitive = false;
			if ( '' !== $needle ) {
				foreach ( self::$sensitive_keys as $sk ) {
					if ( false !== strpos( $needle, $sk ) ) {
						$is_sensitive = true;
						break;
					}
				}
			}

			if ( $is_sensitive ) {
				$out[ $key ] = '***REDACTED***';
			} elseif ( is_array( $value ) ) {
				$out[ $key ] = self::redact( $value );
			} elseif ( is_scalar( $value ) || null === $value ) {
				$out[ $key ] = $value;
			} else {
				$out[ $key ] = '(object)';
			}
		}

		return $out;
	}
}
endif;
