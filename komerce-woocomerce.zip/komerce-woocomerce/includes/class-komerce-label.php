<?php
/**
 * Komerce Print Label Handler
 *
 * Exposes endpoints and actions to print official shipping labels from Komerce Order OpenAPI.
 * Endpoint: POST /orders/api/v1/orders/print-label?page=page_1&order_no={order_no}
 *
 * Supported Entrypoints:
 *   1. REST API: GET /wp-json/komerce/v1/print-label?order_id={id}&page=page_1
 *                GET /wp-json/komerce/v1/orders/{id}/print-label
 *   2. WC-API:   GET /wc-api/komerce-print-label?order_id={id}&page=page_1
 *   3. Admin AJAX: GET/POST admin-ajax.php?action=komerce_print_label&order_id={id}
 *
 * @package WooCommerce\Komerce
 * @since   2.3.6
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Komerce_Label' ) ) :
class Komerce_Label {

    private $api;

    public function __construct() {
        $this->api = Komerce_API_Client::instance();

        // 1. WordPress REST API
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );

        // 2. WooCommerce API endpoint (/wc-api/komerce-print-label)
        add_action( 'woocommerce_api_komerce-print-label', array( $this, 'handle_wc_api' ) );
        add_action( 'woocommerce_api_komerce_print_label', array( $this, 'handle_wc_api' ) );

        // 3. Admin AJAX handler
        add_action( 'wp_ajax_komerce_print_label', array( $this, 'handle_ajax' ) );
    }

    /**
     * Register REST API routes.
     */
    public function register_rest_routes() {
        register_rest_route( 'komerce/v1', '/print-label', array(
            'methods'             => array( 'GET', 'POST' ),
            'callback'            => array( $this, 'rest_print_label' ),
            'permission_callback' => array( $this, 'rest_permissions_check' ),
            'args'                => array(
                'order_id' => array(
                    'description'       => 'WooCommerce Order ID',
                    'type'              => 'integer',
                    'required'          => false,
                    'sanitize_callback' => 'absint',
                ),
                'order_no' => array(
                    'description'       => 'Komerce Order Number (e.g. KOM...)',
                    'type'              => 'string',
                    'required'          => false,
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'page'     => array(
                    'description'       => 'Label page format (page_1, page_4, page_5, page_6, thermal)',
                    'type'              => 'string',
                    'default'           => 'page_1',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ) );

        register_rest_route( 'komerce/v1', '/orders/(?P<id>\d+)/print-label', array(
            'methods'             => array( 'GET', 'POST' ),
            'callback'            => array( $this, 'rest_print_label_by_id' ),
            'permission_callback' => array( $this, 'rest_permissions_check' ),
            'args'                => array(
                'id'   => array(
                    'description'       => 'WooCommerce Order ID',
                    'type'              => 'integer',
                    'required'          => true,
                    'sanitize_callback' => 'absint',
                ),
                'page' => array(
                    'description'       => 'Label page format (page_1, page_4, page_5, page_6, thermal)',
                    'type'              => 'string',
                    'default'           => 'page_1',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ) );
    }

    /**
     * Permission check for REST API.
     */
    public function rest_permissions_check( $request ) {
        if ( current_user_can( 'edit_shop_orders' ) ) {
            return true;
        }

        // Check secret or API key in headers if provided
        $secret = $request->get_header( 'x-api-key' ) ?: $request->get_param( 'secret' );
        if ( ! empty( $secret ) ) {
            $opts = get_option( 'komerce_settings', array() );
            $valid_key = $opts['api_key_order'] ?? ( $opts['api_key'] ?? '' );
            $valid_wh  = $opts['webhook_secret'] ?? '';
            if ( ( ! empty( $valid_key ) && hash_equals( $valid_key, $secret ) ) ||
                 ( ! empty( $valid_wh ) && hash_equals( $valid_wh, $secret ) ) ) {
                return true;
            }
        }

        return new WP_Error( 'rest_forbidden', 'Unauthorized to print order labels.', array( 'status' => 401 ) );
    }

    /**
     * REST callback for /wp-json/komerce/v1/print-label.
     */
    public function rest_print_label( $request ) {
        $order_id = absint( $request->get_param( 'order_id' ) );
        $order_no = sanitize_text_field( $request->get_param( 'order_no' ) );
        $page     = sanitize_text_field( $request->get_param( 'page' ) ?: 'page_1' );

        $is_browser = ( false !== strpos( (string) $request->get_header( 'accept' ), 'text/html' ) );
        return $this->process_label( $order_id, $order_no, $page, ! $is_browser );
    }

    /**
     * REST callback for /wp-json/komerce/v1/orders/{id}/print-label.
     */
    public function rest_print_label_by_id( $request ) {
        $order_id = absint( $request->get_param( 'id' ) );
        $page     = sanitize_text_field( $request->get_param( 'page' ) ?: 'page_1' );

        $is_browser = ( false !== strpos( (string) $request->get_header( 'accept' ), 'text/html' ) );
        return $this->process_label( $order_id, '', $page, ! $is_browser );
    }

    /**
     * Handle WC-API endpoint: /wc-api/komerce-print-label?order_id=...&page=page_1.
     */
    public function handle_wc_api() {
        $order_id = absint( $_GET['order_id'] ?? ( $_POST['order_id'] ?? 0 ) );
        $order_no = sanitize_text_field( $_GET['order_no'] ?? ( $_POST['order_no'] ?? '' ) );
        $page     = sanitize_text_field( $_GET['page'] ?? ( $_POST['page'] ?? 'page_1' ) );
        $nonce    = sanitize_text_field( $_GET['_wpnonce'] ?? ( $_GET['nonce'] ?? '' ) );

        // Security check: nonce or current user capability
        if ( ! current_user_can( 'edit_shop_orders' ) ) {
            if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'komerce_print_label' ) ) {
                wp_die( 'Akses tidak sah untuk mencetak label.', 'Unauthorized', array( 'response' => 403 ) );
            }
        }

        $this->process_label( $order_id, $order_no, $page, false );
        exit;
    }

    /**
     * Handle Admin AJAX: action=komerce_print_label.
     */
    public function handle_ajax() {
        $nonce = sanitize_text_field( $_REQUEST['_wpnonce'] ?? ( $_REQUEST['nonce'] ?? '' ) );
        if ( ! current_user_can( 'edit_shop_orders' ) ) {
            if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'komerce_print_label' ) ) {
                wp_send_json_error( 'Unauthorized' );
            }
        }

        $order_id = absint( $_REQUEST['order_id'] ?? 0 );
        $order_no = sanitize_text_field( $_REQUEST['order_no'] ?? '' );
        $page     = sanitize_text_field( $_REQUEST['page'] ?? 'page_1' );

        // If direct navigation in new tab, output directly or redirect
        if ( ! empty( $_SERVER['HTTP_ACCEPT'] ) && false !== strpos( $_SERVER['HTTP_ACCEPT'], 'text/html' ) ) {
            $this->process_label( $order_id, $order_no, $page, false );
            exit;
        }

        $result = $this->process_label( $order_id, $order_no, $page, true );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }

        wp_send_json_success( $result );
    }

    /**
     * Core label processor.
     *
     * @param int    $order_id    WooCommerce order ID.
     * @param string $order_no    Komerce order number.
     * @param string $page        Page size (page_1, page_4, page_5, page_6, thermal).
     * @param bool   $return_json Whether to return JSON array or output/redirect.
     * @return array|WP_Error
     */
    public function process_label( $order_id, $order_no = '', $page = 'page_1', $return_json = false ) {
        if ( empty( $order_no ) && $order_id > 0 ) {
            $order = wc_get_order( $order_id );
            if ( $order ) {
                $order_no = (string) $order->get_meta( Komerce_Order::META_ORDER_NO );
            }
        }

        if ( empty( $order_no ) ) {
            $err = new WP_Error( 'komerce_no_order_no', 'Order pengiriman Komerce belum dibuat untuk pesanan ini.' );
            if ( ! $return_json ) {
                wp_die( esc_html( $err->get_error_message() ), 'Label Not Found', array( 'response' => 404 ) );
            }
            return $err;
        }

        if ( 'thermal' === strtolower( (string) $page ) ) {
            $page = 'page_1';
        }

        // Call Komerce OpenAPI print-label
        $resp = $this->api->print_label( $order_no, $page );

        if ( is_wp_error( $resp ) ) {
            if ( ! $return_json ) {
                wp_die( 'Gagal mengambil label dari Komerce: ' . esc_html( $resp->get_error_message() ), 'Print Label Error', array( 'response' => 500 ) );
            }
            return $resp;
        }

        // 1. Inspect response for label URL
        $label_url = '';
        if ( is_array( $resp ) ) {
            if ( ! empty( $resp['data'] ) ) {
                if ( is_string( $resp['data'] ) && filter_var( $resp['data'], FILTER_VALIDATE_URL ) ) {
                    $label_url = $resp['data'];
                } elseif ( is_array( $resp['data'] ) ) {
                    $label_url = $resp['data']['url'] ?? ( $resp['data']['pdf_url'] ?? ( $resp['data']['label_url'] ?? '' ) );
                }
            }
            if ( empty( $label_url ) && ! empty( $resp['url'] ) ) {
                $label_url = $resp['url'];
            }
        }

        // If a direct URL was returned
        if ( ! empty( $label_url ) ) {
            if ( $return_json ) {
                return array(
                    'order_no'  => $order_no,
                    'label_url' => $label_url,
                    'page'      => $page,
                    'format'    => 'thermal',
                );
            }

            // Stream the PDF inline so browser opens native PDF viewer with print button in new tab
            $pdf_res = wp_remote_get( $label_url, array( 'timeout' => 30, 'sslverify' => false ) );
            if ( ! is_wp_error( $pdf_res ) && 200 === (int) wp_remote_retrieve_response_code( $pdf_res ) ) {
                $pdf_body = wp_remote_retrieve_body( $pdf_res );
                if ( ! empty( $pdf_body ) && ( 0 === strpos( $pdf_body, '%PDF' ) || strpos( (string) wp_remote_retrieve_header( $pdf_res, 'content-type' ), 'pdf' ) !== false ) ) {
                    header( 'Content-Type: application/pdf' );
                    header( 'Content-Disposition: inline; filename="label-' . sanitize_file_name( $order_no ) . '-thermal.pdf"' );
                    header( 'Content-Length: ' . strlen( $pdf_body ) );
                    echo $pdf_body;
                    exit;
                }
            }

            // Fallback: direct redirect
            wp_redirect( $label_url );
            exit;
        }

        // 2. Raw binary PDF response
        if ( ! empty( $resp['raw'] ) ) {
            $raw          = $resp['raw'];
            $content_type = $resp['content_type'] ?? '';

            if ( strpos( (string) $content_type, 'pdf' ) !== false || 0 === strpos( $raw, '%PDF' ) ) {
                if ( $return_json ) {
                    return array(
                        'order_no' => $order_no,
                        'format'   => 'pdf_binary',
                        'data'     => base64_encode( $raw ),
                    );
                }
                header( 'Content-Type: application/pdf' );
                header( 'Content-Disposition: inline; filename="label-' . sanitize_file_name( $order_no ) . '-thermal.pdf"' );
                header( 'Content-Length: ' . strlen( $raw ) );
                echo $raw;
                exit;
            }

            // HTML content
            if ( strpos( (string) $content_type, 'html' ) !== false || false !== strpos( $raw, '<html' ) ) {
                if ( $return_json ) {
                    return array(
                        'order_no' => $order_no,
                        'format'   => 'html',
                        'html'     => $raw,
                    );
                }
                header( 'Content-Type: text/html; charset=utf-8' );
                echo $raw;
                exit;
            }
        }

        // Fallback: return array representation
        if ( $return_json ) {
            return array(
                'order_no' => $order_no,
                'response' => $resp,
            );
        }

        // Dump fallback
        echo '<pre>' . esc_html( wp_json_encode( $resp, JSON_PRETTY_PRINT ) ) . '</pre>';
        exit;
    }

    /**
     * Get direct print label URL for an order.
     *
     * @param int    $order_id
     * @param string $page
     * @return string
     */
    public static function get_label_url( $order_id, $page = 'page_1' ) {
        $nonce = wp_create_nonce( 'komerce_print_label' );
        return add_query_arg( array(
            'action'   => 'komerce_print_label',
            'order_id' => absint( $order_id ),
            'page'     => sanitize_text_field( $page ),
            'nonce'    => $nonce,
            '_wpnonce' => $nonce,
        ), admin_url( 'admin-ajax.php' ) );
    }
}
endif;
