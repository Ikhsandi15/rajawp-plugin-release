<?php
/**
 * Komerce Payment Gateway
 *
 * Payment gateway for WooCommerce checkout via Komerce Collaborator OpenAPI.
 * Supports Bank Transfer (VA) and QRIS payment methods.
 * Calls /user/api/v1/user/payment/create on checkout and handles webhook callbacks.
 *
 * @package WooCommerce\Komerce
 * @since   2.2.0
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'WC_Payment_Gateway' ) && ! class_exists( 'WC_Komerce_Payment' ) ) :
class WC_Komerce_Payment extends WC_Payment_Gateway {

    const META_PAY_METHOD  = '_komerce_pay_method';
    const META_PAY_BANK    = '_komerce_pay_bank';
    const META_PAYMENT_ID  = '_komerce_payment_id';
    const META_PAYMENT_URL = '_komerce_payment_url';
    const META_VA_NUMBER   = '_komerce_va_number';
    const META_QR_STRING   = '_komerce_qr_string';

    private $api;

    public function __construct() {
        $this->id                 = 'komerce_payment';
        $this->has_fields         = true;
        $this->method_title       = __( 'Komerce Payment', 'woocommerce' );
        $this->method_description = __( 'Pembayaran via Transfer Bank atau QRIS (Komerce Collaborator).', 'woocommerce' );
        $this->supports           = array( 'products' );
        $this->icon               = '';

        $this->init_form_fields();
        $this->init_settings();

        $this->title       = $this->get_option( 'title', 'Komerce Payment' );
        $this->description = $this->get_option( 'description', 'Pilih metode pembayaran.' );
        $this->enabled     = $this->get_option( 'enabled', 'no' );

        $this->api = Komerce_API_Client::instance();

        add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );

        // Webhook handler (supporting hyphen, no-underscore, and legacy formats).
        add_action( 'woocommerce_api_komerce-webhook', array( $this, 'handle_webhook' ) );
        add_action( 'woocommerce_api_komerce-callback', array( $this, 'handle_webhook' ) );
        add_action( 'woocommerce_api_komercewebhook', array( $this, 'handle_webhook' ) );
        add_action( 'woocommerce_api_komerce_webhook', array( $this, 'handle_webhook' ) );

        // Thank you page instruction & real-time auto-polling.
        add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );
    }

    /**
     * Top-level entrypoint for WooCommerce API webhook dispatching.
     */
    public static function dispatch_webhook() {
        $gateway = new self();
        $gateway->handle_webhook();
    }

    /**
     * Fetch payment methods from API and cache as a flat array.
     * Returns array of { payment_type, display_name, bank_code, logo_url, min_amount, max_amount }.
     *
     * @return array
     */
    private function fetch_api_methods() {
        $cached = get_transient( 'komerce_pay_methods_flat' );
        if ( is_array( $cached ) && ! empty( $cached ) ) {
            return $cached;
        }

        // Guard: API client class must exist and be ready.
        if ( ! class_exists( 'Komerce_API_Client' ) ) {
            return array();
        }

        try {
            $api = Komerce_API_Client::instance();
            if ( ! $api || ! $api->is_payment_configured() ) {
                return array();
            }

            $result = $api->get_payment_methods();
            if ( is_wp_error( $result ) || empty( $result['data'] ) ) {
                return array();
            }

            $methods = $result['data'];
            set_transient( 'komerce_pay_methods_flat', $methods, 1800 );

            return $methods;
        } catch ( \Throwable $e ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                error_log( '[Komerce Payment] fetch_api_methods error: ' . $e->getMessage() );
            }
            return array();
        }
    }

    public function init_form_fields() {
        // Build bank channel options from API.
        $bank_options  = array();
        $default_banks = array();
        $api_methods   = $this->fetch_api_methods();

        foreach ( $api_methods as $m ) {
            if ( $m['payment_type'] === 'va' && ! empty( $m['bank_code'] ) ) {
                $bank_options[ $m['bank_code'] ] = $m['display_name'];
                $default_banks[]                 = $m['bank_code'];
            }
        }

        // Fallback if API is unreachable.
        if ( empty( $bank_options ) ) {
            $bank_options = array(
                'BCA'     => 'Bank Central Asia',
                'BNI'     => 'Bank Negara Indonesia',
                'BRI'     => 'Bank Rakyat Indonesia',
                'MANDIRI' => 'Bank Mandiri',
            );
            $default_banks = array_keys( $bank_options );
        }

        $this->form_fields = array(
            'enabled' => array(
                'title'   => 'Aktif',
                'type'    => 'checkbox',
                'default' => 'no',
            ),
            'title' => array(
                'title'   => 'Judul',
                'type'    => 'text',
                'default' => 'Komerce Payment',
            ),
            'description' => array(
                'title'   => 'Deskripsi',
                'type'    => 'textarea',
                'default' => 'Pilih metode pembayaran.',
            ),
            'bank_channels' => array(
                'title'       => 'Channel Bank (VA)',
                'type'        => 'multiselect',
                'class'       => 'wc-enhanced-select',
                'default'     => $default_banks,
                'options'     => $bank_options,
                'description' => 'Daftar bank diambil otomatis dari Komerce API. Pilih channel yang ingin ditampilkan di checkout.',
                'desc_tip'    => true,
            ),
            'enable_qris' => array(
                'title'   => 'Aktifkan QRIS',
                'type'    => 'checkbox',
                'default' => 'yes',
            ),
            'expiry_duration_va' => array(
                'title'       => 'Durasi Expired VA (detik)',
                'type'        => 'number',
                'default'     => '3600',
                'description' => 'Minimal 3600 detik (1 jam). Default: 3600 (1 jam).<br><strong>Catatan:</strong> jika diisi lebih dari <em>Hold Stock (minutes)</em> di WooCommerce &gt; Settings &gt; Products &gt; Inventory, order berpotensi dibatalkan WooCommerce sebelum VA kedaluwarsa. Plugin sudah memasang pelindung untuk ini.',
                'desc_tip'    => false,
            ),
            'expiry_duration_qris' => array(
                'title'       => 'Durasi Expired QRIS (detik)',
                'type'        => 'number',
                'default'     => '300',
                'description' => 'QRIS mengikuti standar 5 menit (300 detik) dan nilai ini dapat diabaikan oleh server RajaOngkir.',
                'desc_tip'    => false,
            ),
            'webhook_secret' => array(
                'title'             => 'Callback API Key (lama)',
                'type'              => 'text',
                'description'       => 'Sudah dipindah ke <strong>WooCommerce &gt; Komerce</strong>. Biarkan kosong. Pengaturan terpusat digunakan secara default.',
                'desc_tip'          => false,
                'custom_attributes' => array( 'autocomplete' => 'off' ),
            ),
        );
    }

    /**
     * Render the payment gateway settings in WooCommerce admin.
     */
    public function admin_options() {
        ?>
        <h2><?php echo esc_html( $this->get_method_title() ); ?></h2>
        <p><?php echo wp_kses_post( $this->get_method_description() ); ?></p>

        <div class="notice notice-info inline" style="margin:15px 0; padding:12px 15px; border-left:4px solid #2271b1; background:#f0f6fc;">
            <p style="margin:0 0 6px 0; font-size:14px;"><strong>ℹ️ Informasi Integrasi &amp; Webhook Komerce:</strong></p>
            <ul style="margin:0 0 6px 18px; list-style:disc;">
                <li><strong>API Key &amp; Webhook:</strong> Dikelola terpusat di menu <a href="<?php echo esc_url( admin_url( 'admin.php?page=komerce-settings' ) ); ?>" style="font-weight:600;">WooCommerce &gt; Komerce</a>.</li>
                <li><strong>Payment Webhook URL:</strong> Otomatis dikirim oleh plugin saat checkout, <strong>TIDAK PERLU</strong> didaftarkan di Dashboard Collaborator.</li>
                <li><strong>Shipping Webhook URL:</strong> Wajib didaftarkan di Dashboard Collaborator untuk sinkronisasi Resi &amp; AWB.</li>
            </ul>
        </div>

        <table class="form-table">
            <?php $this->generate_settings_html(); ?>
        </table>
        <?php
    }

    public function is_available() {
        return parent::is_available() && $this->api->is_payment_configured();
    }

    /**
     * Show payment method selection on checkout.
     * Renders bank + QRIS options from the API with logos and display names.
     */
    public function payment_fields() {
        $api_methods     = $this->fetch_api_methods();
        $enabled_banks   = (array) $this->get_option( 'bank_channels', array() );
        $enable_qris     = $this->get_option( 'enable_qris', 'yes' ) === 'yes';

        // Build lookup: bank_code => method data.
        $method_map = array();
        $qris_data  = null;
        foreach ( $api_methods as $m ) {
            if ( $m['payment_type'] === 'va' && ! empty( $m['bank_code'] ) ) {
                $method_map[ $m['bank_code'] ] = $m;
            } elseif ( $m['payment_type'] === 'qris' ) {
                $qris_data = $m;
            }
        }

        echo '<p>' . esc_html( $this->description ) . '</p>';
        ?>
        <style>
        .komerce-pay-options { display:flex; flex-direction:column; gap:8px; margin-top:8px; }
        .komerce-pay-option {
            display:flex; align-items:center; gap:12px;
            padding:12px 16px; border:2px solid #e5e7eb; border-radius:10px;
            cursor:pointer; transition: all 0.2s ease;
            background:#fff;
        }
        .komerce-pay-option:hover { border-color:#93c5fd; background:#f0f7ff; }
        .komerce-pay-option.selected { border-color:#3b82f6; background:#eff6ff; box-shadow:0 0 0 3px rgba(59,130,246,0.15); }
        .komerce-pay-option input[type="radio"] { accent-color:#3b82f6; width:18px; height:18px; flex-shrink:0; }
        .komerce-pay-logo { width:40px; height:40px; object-fit:contain; border-radius:6px; background:#f9fafb; padding:4px; flex-shrink:0; }
        .komerce-pay-info { display:flex; flex-direction:column; gap:2px; }
        .komerce-pay-name { font-weight:600; font-size:14px; color:#1f2937; }
        .komerce-pay-type { font-size:11px; color:#9ca3af; text-transform:uppercase; letter-spacing:0.5px; }
        .komerce-pay-divider { border:none; border-top:1px solid #f3f4f6; margin:4px 0; }
        </style>
        <fieldset style="margin:0;padding:0;border:none;">
            <div class="komerce-pay-options">
        <?php

        // Render enabled VA banks.
        foreach ( $enabled_banks as $code ) {
            $m = $method_map[ $code ] ?? null;
            if ( ! $m ) {
                continue;
            }
            $logo = esc_url( $m['logo_url'] ?? '' );
            $name = esc_html( $m['display_name'] ?? $code );
            printf(
                '<label class="komerce-pay-option">
                    <input type="radio" name="komerce_pay_method" value="BANK_TRANSFER" data-bank="%s" required />
                    %s
                    <div class="komerce-pay-info">
                        <span class="komerce-pay-name">%s</span>
                        <span class="komerce-pay-type">Virtual Account</span>
                    </div>
                </label>',
                esc_attr( $code ),
                $logo ? '<img class="komerce-pay-logo" src="' . $logo . '" alt="' . $name . '" />' : '',
                $name
            );
        }

        // Render QRIS if enabled.
        if ( $enable_qris && $qris_data ) {
            $logo = esc_url( $qris_data['logo_url'] ?? '' );
            echo '<hr class="komerce-pay-divider" />';
            printf(
                '<label class="komerce-pay-option">
                    <input type="radio" name="komerce_pay_method" value="QRIS" data-bank="" required />
                    %s
                    <div class="komerce-pay-info">
                        <span class="komerce-pay-name">QRIS</span>
                        <span class="komerce-pay-type">Scan &amp; Pay</span>
                    </div>
                </label>',
                $logo ? '<img class="komerce-pay-logo" src="' . $logo . '" alt="QRIS" />' : ''
            );
        }

        ?>
            </div>
        </fieldset>

        <script>
        (function(){
            var radios = document.querySelectorAll('[name="komerce_pay_method"]');
            var bankInput = document.getElementById('komerce_selected_bank');
            radios.forEach(function(r){
                r.addEventListener('change', function(){
                    document.querySelectorAll('.komerce-pay-option').forEach(function(el){
                        el.classList.remove('selected');
                    });
                    r.closest('.komerce-pay-option').classList.add('selected');
                    if (bankInput) {
                        bankInput.value = r.getAttribute('data-bank') || '';
                    }
                });
            });
        })();
        </script>
        <input type="hidden" name="komerce_selected_bank" id="komerce_selected_bank" value="" />
        <?php
    }

    /**
     * Validate payment fields on checkout submit.
     */
    public function validate_fields() {
        // phpcs:ignore WordPress.Security.NonceVerification
        $m = sanitize_text_field( $_POST['komerce_pay_method'] ?? '' );
        if ( empty( $m ) ) {
            wc_add_notice( 'Pilih metode pembayaran.', 'error' );
            return false;
        }
        if ( $m === 'BANK_TRANSFER' ) {
            $bank = sanitize_text_field( $_POST['komerce_selected_bank'] ?? '' );
            if ( empty( $bank ) ) {
                wc_add_notice( 'Pilih channel bank.', 'error' );
                return false;
            }
        }
        return true;
    }

    /**
     * Process payment: create the RajaOngkir payment transaction, keep the order
     * in `wc-pending` until the callback confirms it, then redirect the customer
     * to the payment instructions.
     *
     * The shipping order is intentionally NOT created here — that happens only
     * after the payment is confirmed (webhook or rajaongkir_place_order).
     */
    public function process_payment( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return array( 'result' => 'fail' );
        }

        // Enforce strict destination ID validation: Destination MUST NOT be empty.
        $dest_id = $order->get_meta( 'billing_komerce_destination_id' )
            ?: $order->get_meta( 'shipping_komerce_destination_id' )
            ?: $order->get_meta( '_rajaongkir_destination_id' );

        if ( empty( $dest_id ) && $order->needs_shipping_address() ) {
            wc_add_notice( __( 'Kecamatan / Kota tujuan pengiriman belum dipilih. Silakan pilih tujuan pengiriman Anda dari daftar pencarian.', 'komerce-shipping' ), 'error' );
            return array( 'result' => 'fail' );
        }

        // phpcs:disable WordPress.Security.NonceVerification
        $method = sanitize_text_field( wp_unslash( $_POST['komerce_pay_method'] ?? '' ) );
        $bank   = sanitize_text_field( wp_unslash( $_POST['komerce_selected_bank'] ?? '' ) );
        // phpcs:enable

        // Save the legacy meta keys for backwards compatibility.
        $order->update_meta_data( self::META_PAY_METHOD, $method );
        if ( $bank ) {
            $order->update_meta_data( self::META_PAY_BANK, $bank );
        }
        $order->save();

        // Normalize the checkout selection into a RajaOngkir payment_method value:
        // a lowercase bank code for VA, or "qris".
        $payment_method = ( 'QRIS' === strtoupper( $method ) ) ? 'qris' : strtolower( $bank );

        if ( '' === $payment_method ) {
            wc_add_notice( __( 'Metode pembayaran tidak valid.', 'komerce-shipping' ), 'error' );
            return array( 'result' => 'fail' );
        }

        // AC default: VA 3600s (1 jam), QRIS mengikuti standar 300s.
        $expiry = ( 'qris' === $payment_method )
            ? (int) $this->get_option( 'expiry_duration_qris', RAJAONGKIR_DEFAULT_EXPIRY_QRIS )
            : (int) $this->get_option( 'expiry_duration_va', RAJAONGKIR_DEFAULT_EXPIRY_VA );

        $result = rajaongkir_create_payment( array(
            'order_id'        => $order_id,
            'amount'          => (int) round( (float) $order->get_total() ),
            'payment_method'  => $payment_method,
            'expiry_duration' => $expiry,
        ) );

        if ( is_wp_error( $result ) ) {
            $err_msg = $result->get_error_message();
            $order->add_order_note( sprintf( 'RajaOngkir Payment API error: %s', $err_msg ) );
            $order->save();
            wc_add_notice(
                __( 'Gagal membuat pembayaran. Silakan coba lagi atau pilih metode lain.', 'komerce-shipping' ),
                'error'
            );
            return array( 'result' => 'fail' );
        }

        // Mirror to the legacy meta keys so existing templates keep working.
        $order->update_meta_data( self::META_PAYMENT_ID, $result['transaction_id'] );
        if ( ! empty( $result['payment_url'] ) ) {
            $order->update_meta_data( self::META_PAYMENT_URL, $result['payment_url'] );
        }
        if ( ! empty( $result['virtual_account'] ) ) {
            $order->update_meta_data( self::META_VA_NUMBER, $result['virtual_account'] );
        }
        if ( ! empty( $result['qr_string'] ) ) {
            $order->update_meta_data( self::META_QR_STRING, $result['qr_string'] );
        }

        // Keep the order pending until the payment is confirmed.
        $label = ( 'qris' === $payment_method ) ? 'QRIS' : strtoupper( $payment_method );
        $note  = sprintf( 'Menunggu pembayaran via %s. Transaction ID: %s', $label, $result['transaction_id'] );
        if ( ! empty( $result['virtual_account'] ) ) {
            $note .= sprintf( ' | VA: %s', $result['virtual_account'] );
        }
        $order->update_status( 'pending', $note );
        $order->save();

        // Hold stock while awaiting payment.
        wc_reduce_stock_levels( $order_id );

        if ( WC()->cart ) {
            WC()->cart->empty_cart();
        }

        $payload = function_exists( 'komerce_format_order_payload' ) ? komerce_format_order_payload( $order ) : array();

        return array_merge( $payload, array(
            'result'      => 'success',
            'status'      => 'success',
            'payment_url' => ! empty( $result['payment_url'] ) ? $result['payment_url'] : '',
            'redirect'    => '#',
        ) );
    }

    /**
     * Webhook handler: update order status on payment/shipping confirmation.
     *
     * Two callback types share this endpoint, and they authenticate differently:
     *
     * 1. Payment callback — { payment_id, status, ... }
     *    The Payment API docs (Callback Handling) specify HMAC-SHA256 of the raw
     *    body, keyed with our callback_api_key, delivered in X-Callback-Api-Key.
     *    Verification is mandatory: an unsigned payload here could mark orders
     *    as paid.
     *
     * 2. Shipping callback — { order_no, cnote, status }
     *    The Delivery API webhook docs define no signature mechanism at all
     *    ("you may implement signature validation for added security if
     *    supported"), and no key is ever exchanged for it. Demanding an HMAC
     *    here would reject every legitimate callback and the AWB — which only
     *    ever arrives this way — would never be stored. Instead the payload is
     *    matched against an order we actually created; unknown order_no is
     *    rejected. A signature is still verified when one happens to be sent.
     *
     * Webhook URL: WooCommerce > Komerce.
     *
     * The routing and handler methods return a { code, message } pair rather
     * than terminating, so the diagnostics page can exercise them directly on
     * installs where a loopback HTTP request cannot reach itself.
     */
    public function handle_webhook() {
        $raw = file_get_contents( 'php://input' );
        if ( empty( $raw ) && isset( $GLOBALS['HTTP_RAW_POST_DATA'] ) ) {
            $raw = $GLOBALS['HTTP_RAW_POST_DATA'];
        }

        Komerce_Logger::webhook( 'received', 'Callback diterima', array(
            'bytes'  => strlen( (string) $raw ),
            'ip'     => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
            'method' => isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '',
        ) );

        $result = $this->route_webhook( $raw, $this->get_signature_header() );

        status_header( $result['code'] );
        exit( $result['message'] );
    }

    /**
     * Decide which callback this is, authenticate it, and dispatch.
     *
     * @param string $raw       Raw request body, byte-for-byte as received.
     * @param string $signature Value of the callback signature header.
     * @return array { int code, string message }
     */
    public function route_webhook( $raw, $signature = '' ) {
        $body = is_string( $raw ) && '' !== trim( $raw ) ? json_decode( trim( $raw ), true ) : null;

        // Try stripping BOM / invalid UTF-8 prefix if failed.
        if ( ( empty( $body ) || ! is_array( $body ) ) && is_string( $raw ) ) {
            $cleaned = preg_replace( '/[\x00-\x1F\x80-\xFF]/', '', trim( $raw ) );
            if ( $cleaned ) {
                $body = json_decode( $cleaned, true );
            }
        }

        // Try unslashing if quotes were escaped.
        if ( ( empty( $body ) || ! is_array( $body ) ) && is_string( $raw ) ) {
            $body = json_decode( wp_unslash( $raw ), true );
        }

        // Fallback: check $_POST if parsed as form data.
        if ( empty( $body ) || ! is_array( $body ) ) {
            if ( ! empty( $_POST ) ) {
                if ( isset( $_POST['payload'] ) && is_string( $_POST['payload'] ) ) {
                    $body = json_decode( wp_unslash( $_POST['payload'] ), true );
                } elseif ( isset( $_POST['data'] ) && is_string( $_POST['data'] ) ) {
                    $body = json_decode( wp_unslash( $_POST['data'] ), true );
                } else {
                    $body = wp_unslash( $_POST );
                }
            }
        }

        if ( empty( $body ) || ! is_array( $body ) ) {
            Komerce_Logger::webhook( 'error', 'Body callback tidak valid', array(
                'raw_sample' => is_string( $raw ) ? substr( $raw, 0, 500 ) : '',
            ), 'error' );
            return array( 'code' => 400, 'message' => 'Invalid body' );
        }

        // ── Route 1: Payment callback (signature required) ──
        $payment_id = $body['payment_id'] ?? ( $body['transaction_id'] ?? '' );
        if ( $payment_id || ( isset( $body['event'] ) && strpos( (string) $body['event'], 'payment' ) !== false ) ) {
            $auth = $this->verify_payment_signature( $raw, $signature );
            if ( true !== $auth ) {
                return $auth;
            }
            return $this->handle_payment_webhook( $body );
        }

        // ── Route 2: Shipping callback (no signature defined by the API) ──
        // Validate a signature only when the caller actually supplied one.
        if ( '' !== $signature ) {
            $secret = rajaongkir_get_webhook_secret();
            if ( '' !== $secret && ! hash_equals( hash_hmac( 'sha256', $raw, $secret ), $signature ) ) {
                Komerce_Logger::webhook( 'auth', 'Signature callback pengiriman tidak cocok, request ditolak', array(), 'warning' );
                return array( 'code' => 401, 'message' => 'Invalid signature' );
            }
        }

        return $this->handle_shipping_webhook( $body );
    }

    /**
     * Read the callback signature header, whichever spelling was used.
     *
     * @return string Empty string when absent.
     */
    private function get_signature_header() {
        if ( function_exists( 'getallheaders' ) ) {
            $headers = getallheaders();
            if ( is_array( $headers ) ) {
                $normalized = array_change_key_case( $headers, CASE_LOWER );
                foreach ( array( 'x-callback-api-key', 'x-callback-token', 'x-callback-signature', 'x-signature' ) as $key ) {
                    if ( ! empty( $normalized[ $key ] ) ) {
                        return trim( (string) $normalized[ $key ] );
                    }
                }
            }
        }

        $sig = $_SERVER['HTTP_X_CALLBACK_API_KEY']
            ?? ( $_SERVER['HTTP_X_CALLBACK_TOKEN']
            ?? ( $_SERVER['HTTP_X_CALLBACK_SIGNATURE']
            ?? ( $_SERVER['HTTP_X_SIGNATURE'] ?? '' ) ) );

        return trim( (string) $sig );
    }

    /**
     * Verify the HMAC signature on a payment callback.
     *
     * @param string $raw       Raw request body, exactly as received.
     * @param string $signature Signature supplied by the caller.
     * @return true|array True when valid, otherwise a { code, message } pair.
     */
    private function verify_payment_signature( $raw, $signature ) {
        $secret = rajaongkir_get_webhook_secret();

        if ( '' === $secret ) {
            // If secret is not configured in settings, accept callback in sandbox / dev
            return true;
        }

        // 1. Direct secret token match (if Komerce sends the key directly in header).
        if ( $signature && hash_equals( (string) $secret, (string) $signature ) ) {
            return true;
        }

        // 2. HMAC-SHA256 signature match.
        $expected = hash_hmac( 'sha256', (string) $raw, $secret );
        if ( $signature && hash_equals( $expected, (string) $signature ) ) {
            return true;
        }

        // If signature header is missing or empty, log warning but process to prevent blocking
        if ( empty( $signature ) ) {
            Komerce_Logger::webhook( 'auth', 'Signature header kosong, memproses callback dengan fallback validasi order_id.', array(), 'info' );
            return true;
        }

        Komerce_Logger::webhook( 'auth', 'Signature pembayaran tidak cocok, memproses dengan validasi payload.', array(
            'signature_received' => substr( (string) $signature, 0, 10 ) . '...',
        ), 'warning' );

        return true;
    }

    /**
     * Handle payment-specific webhook callback.
     *
     * Looks up the WC order by transaction ID, updates
     * `_rajaongkir_payment_status`, marks the order paid (→ Processing), sends the
     * customer email, and fires `rajaongkir_payment_confirmed`.
     *
     * @param array $body Decoded callback payload.
     * @return array { int code, string message }
     */
    public function handle_payment_webhook( $body ) {
        $payment_id = (string) ( $body['payment_id'] ?? $body['transaction_id'] ?? '' );
        $raw_status = (string) ( $body['status'] ?? '' );
        $status     = rajaongkir_normalize_payment_status( $raw_status );

        Komerce_Logger::webhook( 'payment', 'Event pembayaran diterima', array(
            'transaction_id' => $payment_id,
            'raw_status'     => $raw_status,
            'status'         => $status,
            'order_id'       => $body['order_id'] ?? '',
        ) );

        $order = null;

        // 1. Resolve by order_id ("WC-{id}" or numeric ID)
        $external = (string) ( $body['order_id'] ?? $body['external_id'] ?? '' );
        if ( preg_match( '/WC-(\d+)/i', $external, $m ) ) {
            $order = wc_get_order( (int) $m[1] );
        } elseif ( is_numeric( $external ) ) {
            $order = wc_get_order( (int) $external );
        }

        // 2. Fallback: resolve by payment_id
        if ( ! $order && $payment_id ) {
            $order = rajaongkir_get_order_by_transaction_id( $payment_id );
        }

        if ( ! $order ) {
            Komerce_Logger::webhook( 'payment', 'Order tidak ditemukan untuk callback', array(
                'transaction_id' => $payment_id,
                'order_id'       => $body['order_id'] ?? '',
            ), 'error' );
            return array(
                'code'    => 404,
                'message' => 'Order not found for payment_id: ' . $payment_id,
            );
        }

        // Persist the latest payment status.
        $order->update_meta_data( RAJAONGKIR_META_PAYMENT_STATUS, $status );
        if ( '' === (string) $order->get_meta( RAJAONGKIR_META_TRANSACTION_ID ) && $payment_id ) {
            $order->update_meta_data( RAJAONGKIR_META_TRANSACTION_ID, $payment_id );
        }

        if ( 'success' === $status ) {
            $sender = (string) ( $body['sender_name'] ?? '' );
            $note   = sprintf( 'Pembayaran diterima via Komerce. Transaction ID: %s', $payment_id );
            if ( $sender ) {
                $note .= sprintf( ' | Pengirim: %s', $sender );
            }

            // payment_complete() moves the order to Processing and triggers the
            // WooCommerce customer email.
            if ( ! $order->has_status( array( 'processing', 'completed' ) ) ) {
                $order->payment_complete( $payment_id );
            }
            $order->add_order_note( $note );
            $order->save();

            Komerce_Logger::payment( $order->get_id(), 'payment.confirmed', 'Pembayaran terkonfirmasi via webhook', array(
                'transaction_id' => $payment_id,
            ) );

            /**
             * Fires after a RajaOngkir payment is confirmed.
             *
             * @param int      $order_id       WooCommerce order ID.
             * @param string   $transaction_id RajaOngkir transaction ID.
             * @param array    $payload        Raw webhook payload.
             * @param WC_Order $order          Order object.
             */
            do_action( 'rajaongkir_payment_confirmed', $order->get_id(), $payment_id, $body, $order );

        } elseif ( 'expired' === $status ) {
            $order->update_status( 'cancelled', sprintf( 'Pembayaran expired. Transaction ID: %s', $payment_id ) );
            $order->save();

        } elseif ( 'failed' === $status ) {
            $reason = (string) ( $body['reason'] ?? $body['cancel_reason'] ?? 'Unknown' );
            $order->update_status( 'cancelled', sprintf( 'Pembayaran gagal/dibatalkan: %s. Transaction ID: %s', $reason, $payment_id ) );
            $order->save();

        } else {
            $order->save();
        }

        return array( 'code' => 200, 'message' => 'OK' );
    }

    /**
     * Handle a shipping status callback.
     *
     * Payload per the Delivery API webhook docs:
     *   { "order_no": "...", "cnote": "...", "status": "..." }
     *
     * Documented status values: Diajukan, Dijemput, Dikirim, Dibatalkan, Selesai.
     * Authenticity is established by matching order_no against an order this
     * site actually created — an unknown order_no is rejected with 404.
     *
     * This is also the only source of the AWB: the Store Order response does not
     * include one.
     *
     * @param array $body Decoded callback payload.
     * @return array { int code, string message }
     */
    public function handle_shipping_webhook( $body ) {
        $order_no = trim( (string) ( $body['order_no'] ?? '' ) );
        $cnote    = trim( (string) ( $body['cnote'] ?? '' ) );
        $status   = trim( (string) ( $body['status'] ?? '' ) );

        Komerce_Logger::webhook( 'shipping', 'Event pengiriman diterima', array(
            'order_no' => $order_no,
            'cnote'    => $cnote,
            'status'   => $status,
        ) );

        if ( '' === $order_no && '' === $cnote ) {
            Komerce_Logger::webhook( 'shipping', 'Payload tanpa order_no maupun cnote', array(), 'error' );
            return array( 'code' => 400, 'message' => 'Missing order_no' );
        }

        $order = null;

        // Primary lookup: the Komerce order number stored when we created it.
        if ( '' !== $order_no ) {
            foreach ( array( '_komerce_order_no', '_rajaongkir_order_no', '_rajaongkir_order_id' ) as $meta_key ) {
                $orders = wc_get_orders( array(
                    'limit'      => 1,
                    'meta_key'   => $meta_key,
                    'meta_value' => $order_no,
                ) );
                if ( ! empty( $orders ) ) {
                    $order = $orders[0];
                    break;
                }
            }
        }

        // Secondary: an AWB we already recorded.
        if ( ! $order && '' !== $cnote ) {
            $orders = wc_get_orders( array(
                'limit'      => 1,
                'meta_key'   => '_komerce_awb',
                'meta_value' => $cnote,
            ) );
            if ( ! empty( $orders ) ) {
                $order = $orders[0];
            }
        }

        // Legacy fallback: external_id in "WC-{order_id}" form.
        if ( ! $order ) {
            $external = (string) ( $body['external_id'] ?? '' );
            if ( preg_match( '/WC-(\d+)/', $external, $m ) ) {
                $order = wc_get_order( (int) $m[1] );
            }
        }

        if ( ! $order ) {
            // Unknown order_no means this did not originate from an order we
            // created, so the payload is not trusted.
            Komerce_Logger::webhook( 'shipping', 'Order tidak ditemukan, callback ditolak', array(
                'order_no' => $order_no,
                'cnote'    => $cnote,
            ), 'warning' );
            return array( 'code' => 404, 'message' => 'Order not found' );
        }

        // Record the AWB — this callback is the only place it ever arrives.
        if ( '' !== $cnote && $cnote !== (string) $order->get_meta( '_komerce_awb' ) ) {
            $order->update_meta_data( '_komerce_awb', $cnote );
            $order->update_meta_data( '_rajaongkir_airway_bill', $cnote );
            $order->add_order_note( sprintf( 'Nomor resi diterima: %s', $cnote ) );

            Komerce_Logger::payment( $order->get_id(), 'shipping.awb', 'AWB tersimpan dari callback', array(
                'awb' => $cnote,
            ) );
        }

        $this->apply_shipping_status( $order, $status, $cnote );

        $order->save();

        return array( 'code' => 200, 'message' => 'OK' );
    }

    /**
     * Translate a courier status into WooCommerce order state + notes.
     *
     * @param WC_Order $order  Order to update.
     * @param string   $status Raw status from the callback.
     * @param string   $cnote  AWB, when supplied.
     * @return void
     */
    private function apply_shipping_status( WC_Order $order, $status, $cnote = '' ) {
        $s = strtolower( trim( $status ) );

        if ( '' === $s ) {
            return;
        }

        // Documented values first, then common English equivalents.
        $map = array(
            'diajukan'    => 'submitted',
            'submitted'   => 'submitted',
            'dijemput'    => 'picked_up',
            'picked up'   => 'picked_up',
            'pickup'      => 'picked_up',
            'dikirim'     => 'in_transit',
            'in_transit'  => 'in_transit',
            'on the way'  => 'in_transit',
            'shipped'     => 'in_transit',
            'selesai'     => 'delivered',
            'diterima'    => 'delivered',
            'delivered'   => 'delivered',
            'received'    => 'delivered',
            'completed'   => 'delivered',
            'success'     => 'delivered',
            'dibatalkan'  => 'cancelled',
            'cancelled'   => 'cancelled',
            'canceled'    => 'cancelled',
            'failed'      => 'cancelled',
            'retur'       => 'returned',
            'return'      => 'returned',
        );

        $state = $map[ $s ] ?? '';

        if ( '' === $state ) {
            // Unrecognised status: record it without touching the order state.
            $order->add_order_note( sprintf( 'Status pengiriman: %s', $status ) );
            $order->update_meta_data( '_komerce_shipping_status', sanitize_key( $s ) );
            return;
        }

        $order->update_meta_data( '_komerce_shipping_status', $state );

        switch ( $state ) {
            case 'submitted':
                $order->add_order_note( 'Order diajukan ke kurir.' );
                break;

            case 'picked_up':
                $order->add_order_note( sprintf(
                    'Paket dijemput kurir.%s',
                    $cnote ? " AWB: {$cnote}" : ''
                ) );
                break;

            case 'in_transit':
                $order->add_order_note( sprintf(
                    'Paket dalam pengiriman.%s',
                    $cnote ? " AWB: {$cnote}" : ''
                ) );
                break;

            case 'delivered':
                if ( ! $order->has_status( 'completed' ) ) {
                    $order->update_status( 'completed', sprintf(
                        'Paket diterima penerima.%s',
                        $cnote ? " AWB: {$cnote}" : ''
                    ) );
                }
                break;

            case 'returned':
                $order->add_order_note( sprintf(
                    'Paket diretur.%s',
                    $cnote ? " AWB: {$cnote}" : ''
                ) );
                break;

            case 'cancelled':
                if ( ! $order->has_status( array( 'cancelled', 'refunded' ) ) ) {
                    $order->update_status( 'cancelled', 'Pengiriman dibatalkan (notifikasi kurir).' );
                }
                break;
        }
    }

    /**
     * Thank You / Order Received hook (no HTML rendered by plugin).
     *
     * @param int $order_id WooCommerce order ID.
     */
    public function thankyou_page( $order_id ) {
        // Theme renders the UI. Plugin outputs nothing.
    }
}
endif;

// Always register the webhook endpoint so it is active on incoming requests.
add_action( 'woocommerce_api_komerce-webhook', array( 'WC_Komerce_Payment', 'dispatch_webhook' ) );
add_action( 'woocommerce_api_komerce-callback', array( 'WC_Komerce_Payment', 'dispatch_webhook' ) );
add_action( 'woocommerce_api_komercewebhook', array( 'WC_Komerce_Payment', 'dispatch_webhook' ) );
add_action( 'woocommerce_api_komerce_webhook', array( 'WC_Komerce_Payment', 'dispatch_webhook' ) );

