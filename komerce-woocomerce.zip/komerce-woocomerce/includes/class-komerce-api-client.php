<?php
/**
 * Komerce API Client
 *
 * Centralized HTTP wrapper for Komerce Collaborator OpenAPI.
 * Supports three API keys:
 *   - Tariff  (prefix /tariff/) — Cek ongkir & destination search
 *   - Order   (prefix /order/)  — Shipping, Pickup, Tracking, Label
 *   - Payment (prefix /user/)   — Create Payment, Cancel, Status, Methods
 *
 * Auth, environment switching, retry logic, caching, error handling.
 *
 * @package WooCommerce\Komerce
 * @since   2.2.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Komerce_API_Client' ) ) :
class Komerce_API_Client {

    /** @var self|null */
    private static $instance = null;

    const BASE_PRODUCTION = 'https://api.collaborator.komerce.id';
    const BASE_SANDBOX    = 'https://api-sandbox.collaborator.komerce.id';

    private $base_url        = '';
    private $api_key_order   = '';
    private $api_key_payment = '';
    private $max_retries     = 2;
    private $cache_ttl       = 3600;
    private $options         = array();

    /** Destination search cache lifetime: 24 hours. */
    const DESTINATION_CACHE_TTL = 86400;

    private function __construct() {
        $this->options         = get_option( 'komerce_settings', array() );
        $legacy                = $this->opt( 'api_key' );
        $this->api_key_order   = $this->opt( 'api_key_order', $legacy );
        $this->api_key_payment = $this->opt( 'api_key_payment', $this->api_key_order );
        $this->base_url        = ( $this->opt( 'sandbox_mode' ) === 'yes' )
            ? self::BASE_SANDBOX
            : self::BASE_PRODUCTION;
    }

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /** Force re-create instance (useful after settings update). */
    public static function refresh() {
        self::$instance = null;
        return self::instance();
    }

    // ── helpers ──

    private function opt( $key, $default = '' ) {
        return isset( $this->options[ $key ] ) ? $this->options[ $key ] : $default;
    }

    public function is_configured() {
        return ! empty( $this->api_key_order ) || ! empty( $this->api_key_payment );
    }

    public function is_order_configured() {
        return ! empty( $this->api_key_order );
    }

    public function is_payment_configured() {
        return ! empty( $this->api_key_payment );
    }

    public function get_environment() {
        return ( $this->opt( 'sandbox_mode' ) === 'yes' ) ? 'Sandbox' : 'Production';
    }

    /**
     * Base URL for order service assets (labels, PDF storage).
     * Sandbox: https://api-sandbox.collaborator.komerce.id/order
     * Production: https://api.collaborator.komerce.id/order
     */
    public function get_order_base_url() {
        return ( $this->opt( 'sandbox_mode' ) === 'yes' )
            ? 'https://api-sandbox.collaborator.komerce.id/order'
            : 'https://api.collaborator.komerce.id/order';
    }

    // ── generic HTTP ──

    /**
     * Make an HTTP request to the Komerce API.
     *
     * @param string $method   HTTP method.
     * @param string $endpoint API endpoint path (without base URL).
     * @param string $api_key  API key to use for authentication.
     * @param array  $body     Request body (for POST/PUT/PATCH).
     * @param array  $query    Query parameters (for GET).
     * @return array|WP_Error
     */
    public function request( $method, $endpoint, $api_key, $body = array(), $query = array() ) {
        $url = trailingslashit( $this->base_url ) . ltrim( $endpoint, '/' );

        if ( ! empty( $query ) ) {
            $url = add_query_arg( $query, $url );
        }

        $api_key = trim( (string) $api_key );

        $args = array(
            'method'  => strtoupper( $method ),
            'timeout' => 30,
            'headers' => array(
                'x-api-key'    => $api_key,
                'X-API-KEY'    => $api_key,
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
            ),
        );

        if ( ! empty( $body ) && in_array( $method, array( 'POST', 'PUT', 'PATCH' ), true ) ) {
            $args['body'] = wp_json_encode( $body );
        }

        $last_err = null;

        for ( $i = 0; $i <= $this->max_retries; $i++ ) {
            $resp = wp_remote_request( $url, $args );

            if ( is_wp_error( $resp ) ) {
                $last_err = $resp;
                if ( $i < $this->max_retries ) {
                    usleep( 500000 * ( $i + 1 ) );
                }
                continue;
            }

            $code = wp_remote_retrieve_response_code( $resp );
            $raw  = wp_remote_retrieve_body( $resp );
            $data = json_decode( $raw, true );

            if ( $code >= 200 && $code < 300 ) {
                if ( is_array( $data ) ) {
                    return $data;
                }
                return array(
                    'raw'          => $raw,
                    'content_type' => wp_remote_retrieve_header( $resp, 'content-type' ),
                );
            }

            if ( $code >= 500 && $i < $this->max_retries ) {
                usleep( 500000 * ( $i + 1 ) );
                continue;
            }

            // Extract meaningful message from Komerce response structures
            $msg = '';
            if ( is_array( $data ) ) {
                $meta_msg = $data['meta']['message'] ?? ( $data['message'] ?? ( $data['error'] ?? ( $data['msg'] ?? '' ) ) );
                $data_msg = is_string( $data['data'] ?? null ) ? $data['data'] : '';

                if ( ! empty( $meta_msg ) && ! empty( $data_msg ) ) {
                    $msg = $meta_msg . ': ' . $data_msg;
                } elseif ( ! empty( $data_msg ) ) {
                    $msg = $data_msg;
                } else {
                    $msg = $meta_msg;
                }
            }
            if ( empty( $msg ) ) {
                $msg = "HTTP {$code}" . ( ! empty( $raw ) ? ': ' . substr( strip_tags( $raw ), 0, 200 ) : '' );
            }

            // Debug logging for non-2xx responses
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                $masked_key = strlen( $api_key ) > 12
                    ? substr( $api_key, 0, 8 ) . '...' . substr( $api_key, -4 )
                    : '(empty/short)';
                error_log( sprintf(
                    '[Komerce API] %s %s → HTTP %d | key=%s | resp=%s',
                    strtoupper( $method ),
                    $url,
                    $code,
                    $masked_key,
                    substr( $raw, 0, 500 )
                ) );
            }

            return new WP_Error( 'komerce_api_error', $msg, array( 'status' => $code, 'raw' => $raw ) );
        }

        return $last_err ?: new WP_Error( 'komerce_api_error', 'Request failed after retries' );
    }

    // ── Service-specific request helpers ──

    /**
     * Request to Tariff API (cek ongkir & destination search).
     * Prefix: /tariff/
     */
    public function tariff_get( $endpoint, $query = array() ) {
        return $this->request( 'GET', 'tariff/' . ltrim( $endpoint, '/' ), $this->api_key_order, array(), $query );
    }

    /**
     * Request to Order API (shipping, tracking, pickup, label).
     * Automatically handles gateway routing with fallback between 'order/' and 'orders/'.
     */
    public function order_get( $endpoint, $query = array() ) {
        $clean = ltrim( $endpoint, '/' );
        $resp  = $this->request( 'GET', 'order/' . $clean, $this->api_key_order, array(), $query );
        if ( is_wp_error( $resp ) && ( 404 === (int) $resp->get_error_data( 'status' ) || false !== strpos( $resp->get_error_message(), '404' ) ) ) {
            return $this->request( 'GET', 'orders/' . $clean, $this->api_key_order, array(), $query );
        }
        return $resp;
    }

    public function order_post( $endpoint, $body = array(), $query = array() ) {
        $clean = ltrim( $endpoint, '/' );
        $resp  = ! empty( $query )
            ? $this->request( 'POST', 'order/' . $clean, $this->api_key_order, $body, $query )
            : $this->request( 'POST', 'order/' . $clean, $this->api_key_order, $body );

        if ( is_wp_error( $resp ) && ( 404 === (int) $resp->get_error_data( 'status' ) || false !== strpos( $resp->get_error_message(), '404' ) ) ) {
            return ! empty( $query )
                ? $this->request( 'POST', 'orders/' . $clean, $this->api_key_order, $body, $query )
                : $this->request( 'POST', 'orders/' . $clean, $this->api_key_order, $body );
        }

        return $resp;
    }

    public function order_put( $endpoint, $body = array() ) {
        $clean = ltrim( $endpoint, '/' );
        $resp  = $this->request( 'PUT', 'order/' . $clean, $this->api_key_order, $body );
        if ( is_wp_error( $resp ) && ( 404 === (int) $resp->get_error_data( 'status' ) || false !== strpos( $resp->get_error_message(), '404' ) ) ) {
            return $this->request( 'PUT', 'orders/' . $clean, $this->api_key_order, $body );
        }
        return $resp;
    }

    /**
     * Request to Payment API (user-service).
     * Prefix: /user/
     */
    public function user_get( $endpoint, $query = array() ) {
        return $this->request( 'GET', 'user/' . ltrim( $endpoint, '/' ), $this->api_key_payment, array(), $query );
    }

    public function user_post( $endpoint, $body = array() ) {
        return $this->request( 'POST', 'user/' . ltrim( $endpoint, '/' ), $this->api_key_payment, $body );
    }

    // ── Destination (Tariff API) ──

    /**
     * Search destinations by keyword. Cached for 24 hours.
     *
     * @param string $keyword Search keyword.
     * @return array|WP_Error
     */
    public function search_destination( $keyword ) {
        $key    = 'komerce_dest_' . md5( strtolower( trim( $keyword ) ) );
        $cached = get_transient( $key );
        if ( false !== $cached ) {
            return $cached;
        }
        $r = $this->tariff_get( 'api/v1/destination/search', array( 'keyword' => $keyword ) );
        if ( ! is_wp_error( $r ) ) {
            set_transient( $key, $r, self::DESTINATION_CACHE_TTL );
        }
        return $r;
    }

    // ── Tariff / Cost (Tariff API — GET with query params) ──

    public function calculate_cost( $params ) {
        foreach ( array( 'shipper_destination_id', 'receiver_destination_id', 'weight' ) as $k ) {
            if ( empty( $params[ $k ] ) ) {
                return new WP_Error( 'komerce_invalid_param', "Parameter '{$k}' wajib diisi" );
            }
        }
        $key    = 'komerce_tariff_' . md5( wp_json_encode( $params ) );
        $cached = get_transient( $key );
        if ( false !== $cached ) {
            return $cached;
        }
        $r = $this->tariff_get( 'api/v1/calculate', $params );
        if ( ! is_wp_error( $r ) ) {
            set_transient( $key, $r, 1800 );
        }
        return $r;
    }

    // ── Order / Shipping (Order API) ──

    public function create_order( $data )  { return $this->order_post( 'api/v1/orders/store', $data ); }
    public function cancel_order( $order_no ) {
        return $this->order_put( 'api/v1/orders/cancel', array( 'order_no' => $order_no ) );
    }
    public function get_order_detail( $order_no ) {
        return $this->order_get( 'api/v1/orders/detail', array( 'order_no' => $order_no ) );
    }

    // ── Pickup (Order API) ──

    public function request_pickup( $data ) { return $this->order_post( 'api/v1/pickup/request', $data ); }

    // ── Tracking (Order API — GET) ──

    public function track_awb( $awb, $courier = '' ) {
        $q = array(
            'shipping'    => strtolower( trim( (string) $courier ) ),
            'airway_bill' => trim( (string) $awb ),
        );
        return $this->order_get( 'api/v1/orders/history-airway-bill', $q );
    }

    // ── Label (Order API) ──
    // Endpoint: POST /order/api/v1/orders/print-label?page={page}&order_no={order_no}

    public function print_label( $order_no, $page = 'page_1' ) {
        $q = array(
            'page'     => $page ?: 'page_1',
            'order_no' => trim( (string) $order_no ),
        );
        return $this->request( 'POST', 'order/api/v1/orders/print-label', $this->api_key_order, array(), $q );
    }

    // ── Payment (User/Payment API) ──

    /**
     * Get available payment methods.
     * GET /user/api/v1/user/methods
     */
    public function get_payment_methods() {
        $key    = 'komerce_pay_methods';
        $cached = get_transient( $key );
        if ( false !== $cached ) {
            return $cached;
        }
        $r = $this->user_get( 'api/v1/user/methods' );
        if ( ! is_wp_error( $r ) ) {
            set_transient( $key, $r, 1800 );
        }
        return $r;
    }

    /**
     * Create a payment (VA or QRIS).
     * POST /user/api/v1/user/payment/create
     *
     * @param array $data Payment payload matching XenditCreatePaymentRequest.
     * @return array|WP_Error
     */
    public function create_payment( $data ) {
        return $this->user_post( 'api/v1/user/payment/create', $data );
    }

    /**
     * Cancel a VA payment.
     * POST /user/api/v1/user/payment/cancel
     *
     * @param string $payment_id The payment ID to cancel.
     * @param string $reason     Cancellation reason.
     * @return array|WP_Error
     */
    public function cancel_payment( $payment_id, $reason = 'Order cancelled' ) {
        return $this->user_post( 'api/v1/user/payment/cancel', array(
            'payment_id' => $payment_id,
            'reason'     => $reason,
        ) );
    }

    /**
     * Get payment status.
     * GET /user/api/v1/user/payment/status/:payment_id
     *
     * @param string $payment_id The payment ID.
     * @return array|WP_Error
     */
    public function get_payment_status( $payment_id ) {
        return $this->user_get( 'api/v1/user/payment/status/' . urlencode( $payment_id ) );
    }

    // ── Cache ──

    public static function clear_cache() {
        global $wpdb;
        $wpdb->query(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_komerce_%' OR option_name LIKE '_transient_timeout_komerce_%'"
        );
    }
}
endif;
