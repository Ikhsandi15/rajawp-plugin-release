<?php
/**
 * RajaOngkir AJAX Endpoints
 *
 * Registers every `wp_ajax_rajaongkir_*` hook consumed by the frontend.
 * Each handler verifies a nonce, sanitizes input, delegates to the functions in
 * rajaongkir-functions.php, and returns a uniform JSON envelope:
 *
 *   success → { "status": "success", "data": ... }
 *   error   → { "status": "error", "message": "...", "code": "..." }
 *
 * The single nonce action `rajaongkir_nonce` is exposed to JS as
 * `window.rajaongkir_params.nonce`.
 *
 * @package WooCommerce\Komerce
 * @since   2.3.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Komerce_Ajax' ) ) :
class Komerce_Ajax {

	/** Nonce action shared by every rajaongkir_* endpoint. */
	const NONCE_ACTION = 'rajaongkir_nonce';

	/**
	 * Endpoints available to logged-in and guest visitors alike.
	 *
	 * action suffix => handler method
	 *
	 * @var array<string,string>
	 */
	private static $public_endpoints = array(
		'rajaongkir_get_destinations'      => 'get_destinations',
		'rajaongkir_calculate_shipping'    => 'calculate_shipping',
		'rajaongkir_select_shipping'       => 'select_shipping',
		'rajaongkir_get_payment_methods'   => 'get_payment_methods',
		'rajaongkir_create_payment'        => 'create_payment',
		'rajaongkir_check_payment_status'  => 'check_payment_status',
		'rajaongkir_place_order'           => 'place_order',
	);

	public function __construct() {
		foreach ( self::$public_endpoints as $action => $method ) {
			add_action( "wp_ajax_{$action}", array( $this, $method ) );
			add_action( "wp_ajax_nopriv_{$action}", array( $this, $method ) );
		}

		// Admin-only: manual destination cache purge.
		add_action( 'wp_ajax_rajaongkir_clear_cache', array( $this, 'clear_cache' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_params' ) );
	}

	// ─────────────────────────────────────────────────────────────────────
	// Shared helpers
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Expose the AJAX URL + nonce to frontend scripts.
	 *
	 * @return void
	 */
	public function enqueue_params() {
		if ( ! is_checkout() && ! is_cart() && ! is_wc_endpoint_url( 'order-pay' ) && ! is_wc_endpoint_url( 'order-received' ) ) {
			return;
		}

		// Attach to whichever script is present; register a src-less stub if needed.
		if ( ! wp_script_is( 'komerce-checkout', 'registered' ) ) {
			wp_register_script( 'komerce-checkout', false, array( 'jquery' ), KOMERCE_VERSION, true );
			wp_enqueue_script( 'komerce-checkout' );
		}

		wp_localize_script( 'komerce-checkout', 'rajaongkir_params', array(
			'ajax_url'  => admin_url( 'admin-ajax.php' ),
			'nonce'     => wp_create_nonce( self::NONCE_ACTION ),
			'min_chars' => 3,
		) );
	}

	/**
	 * Verify the request nonce, terminating with a JSON error when invalid.
	 *
	 * Accepts the nonce in either `nonce` or `security` for flexibility.
	 *
	 * @return void
	 */
	private function verify_nonce() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$nonce = '';
		if ( isset( $_REQUEST['nonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) );
		} elseif ( isset( $_REQUEST['security'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_REQUEST['security'] ) );
		}
		// phpcs:enable

		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			$this->respond_error(
				__( 'Sesi tidak valid. Muat ulang halaman lalu coba lagi.', 'komerce-shipping' ),
				'invalid_nonce',
				403
			);
		}
	}

	/**
	 * Send `{ "status": "success", "data": ... }` and terminate.
	 *
	 * @param mixed $data Payload.
	 * @return void
	 */
	private function respond_success( $data ) {
		wp_send_json( array(
			'status' => 'success',
			'data'   => $data,
		), 200 );
	}

	/**
	 * Send `{ "status": "error", "message": ... }` and terminate.
	 *
	 * @param string $message     Human-readable message.
	 * @param string $code        Machine-readable code.
	 * @param int    $http_status HTTP status code.
	 * @return void
	 */
	private function respond_error( $message, $code = 'error', $http_status = 400 ) {
		wp_send_json( array(
			'status'  => 'error',
			'code'    => $code,
			'message' => $message,
		), $http_status );
	}

	/**
	 * Convert a WP_Error into an error response and terminate.
	 *
	 * @param WP_Error $error Error.
	 * @return void
	 */
	private function respond_wp_error( WP_Error $error ) {
		$data   = $error->get_error_data();
		$status = ( is_array( $data ) && ! empty( $data['status'] ) ) ? (int) $data['status'] : 400;

		if ( $status < 400 || $status > 599 ) {
			$status = 400;
		}

		$this->respond_error( $error->get_error_message(), $error->get_error_code(), $status );
	}

	/**
	 * Read + sanitize a scalar request param.
	 *
	 * @param string $key     Param name.
	 * @param string $default Fallback.
	 * @return string
	 */
	private function param( $key, $default = '' ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( ! isset( $_REQUEST[ $key ] ) || is_array( $_REQUEST[ $key ] ) ) {
			return $default;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		return sanitize_text_field( wp_unslash( $_REQUEST[ $key ] ) );
	}

	/**
	 * Confirm the current visitor may act on the given order.
	 *
	 * Owners are matched by customer ID; guests by the order key present in the
	 * request (the same mechanism WooCommerce uses for the order-pay page).
	 *
	 * @param WC_Order $order Order.
	 * @return bool
	 */
	private function user_can_access_order( WC_Order $order ) {
		if ( current_user_can( 'edit_shop_orders' ) ) {
			return true;
		}

		$customer_id = $order->get_customer_id();

		if ( $customer_id && get_current_user_id() === $customer_id ) {
			return true;
		}

		$key = $this->param( 'order_key' );
		if ( $key && hash_equals( (string) $order->get_order_key(), $key ) ) {
			return true;
		}

		// Guest order created in this session.
		if ( ! $customer_id && function_exists( 'WC' ) && WC()->session ) {
			$session_order_id = (int) WC()->session->get( 'order_awaiting_payment' );
			if ( $session_order_id === $order->get_id() ) {
				return true;
			}
		}

		return false;
	}

	// ─────────────────────────────────────────────────────────────────────
	// Destinations
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * AJAX: rajaongkir_get_destinations
	 *
	 * Params: keyword (min 3 chars).
	 *
	 * @return void
	 */
	public function get_destinations() {
		$this->verify_nonce();

		$keyword = $this->param( 'keyword' );

		if ( strlen( $keyword ) < 3 ) {
			$this->respond_error(
				__( 'Keyword minimal 3 karakter.', 'komerce-shipping' ),
				'invalid_keyword'
			);
		}

		$result = rajaongkir_search_destination( $keyword );

		if ( is_wp_error( $result ) ) {
			$this->respond_wp_error( $result );
		}

		$this->respond_success( $result );
	}

	// ─────────────────────────────────────────────────────────────────────
	// Tariff
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * AJAX: rajaongkir_calculate_shipping
	 *
	 * Params: destination_id (required), origin_id (optional — falls back to the
	 * configured origin), weight in grams (optional — falls back to the cart
	 * weight), item_value, cod.
	 *
	 * @return void
	 */
	public function calculate_shipping() {
		$this->verify_nonce();

		$destination_id = $this->param( 'destination_id' );
		if ( '' === $destination_id ) {
			$this->respond_error(
				__( 'Parameter destination_id wajib diisi.', 'komerce-shipping' ),
				'missing_destination_id'
			);
		}

		$origin_id = $this->param( 'origin_id' );
		if ( '' === $origin_id ) {
			$origin_id = rajaongkir_get_origin_id();
		}
		if ( '' === $origin_id ) {
			$this->respond_error(
				__( 'Origin ID belum dikonfigurasi. Buka WooCommerce > Komerce.', 'komerce-shipping' ),
				'missing_origin_id'
			);
		}

		$weight = (int) $this->param( 'weight', '0' );
		if ( $weight <= 0 ) {
			$weight = rajaongkir_get_cart_weight();
		}
		if ( $weight <= 0 ) {
			$this->respond_error(
				__( 'Berat tidak dapat dihitung. Pastikan produk memiliki data berat.', 'komerce-shipping' ),
				'missing_weight'
			);
		}

		$item_value = (int) $this->param( 'item_value', '0' );
		if ( $item_value <= 0 && function_exists( 'WC' ) && WC()->cart ) {
			$item_value = (int) round( (float) WC()->cart->get_subtotal() );
		}

		$cod = in_array( strtolower( $this->param( 'cod', 'no' ) ), array( 'yes', '1', 'true' ), true );

		$result = rajaongkir_calculate_shipping_cost( array(
			'origin_id'      => $origin_id,
			'destination_id' => $destination_id,
			'weight'         => $weight, // kg
			'item_value'     => $item_value,
			'cod'            => $cod,
		) );

		if ( is_wp_error( $result ) ) {
			$this->respond_wp_error( $result );
		}

		$this->respond_success( array(
			'origin_id'      => $origin_id,
			'destination_id' => $destination_id,
			'weight'         => $weight,
			'couriers'       => $result,
		) );
	}

	/**
	 * AJAX: rajaongkir_select_shipping
	 *
	 * Persists the chosen courier into the checkout session.
	 *
	 * Params: courier_id, courier_name, cost, eta, destination_id.
	 *
	 * @return void
	 */
	public function select_shipping() {
		$this->verify_nonce();

		$courier_id = $this->param( 'courier_id' );
		if ( '' === $courier_id ) {
			$this->respond_error(
				__( 'Parameter courier_id wajib diisi.', 'komerce-shipping' ),
				'missing_courier_id'
			);
		}

		$stored = rajaongkir_store_shipping_selection( array(
			'courier_id'     => $courier_id,
			'courier_code'   => $this->param( 'courier_code' ),
			'courier_name'   => $this->param( 'courier_name' ),
			'service'        => $this->param( 'service' ),
			'cost'           => (int) $this->param( 'cost', '0' ),
			'eta'            => $this->param( 'eta' ),
			'destination_id' => $this->param( 'destination_id' ),
			'weight'         => (int) $this->param( 'weight', '0' ),
		) );

		if ( ! $stored ) {
			$this->respond_error(
				__( 'Sesi WooCommerce tidak tersedia.', 'komerce-shipping' ),
				'session_unavailable',
				500
			);
		}

		$this->respond_success( rajaongkir_get_shipping_selection() );
	}

	// ─────────────────────────────────────────────────────────────────────
	// Payment
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * AJAX: rajaongkir_get_payment_methods
	 *
	 * @return void
	 */
	public function get_payment_methods() {
		$this->verify_nonce();

		$refresh = in_array( strtolower( $this->param( 'refresh', 'no' ) ), array( 'yes', '1', 'true' ), true );

		$result = rajaongkir_get_payment_methods( $refresh );

		if ( is_wp_error( $result ) ) {
			$this->respond_wp_error( $result );
		}

		$this->respond_success( $result );
	}

	/**
	 * AJAX: rajaongkir_create_payment
	 *
	 * Params: order_id, payment_method (required); amount, customer_name,
	 * customer_email, customer_phone, expiry_duration (optional — defaults to
	 * 3600 for VA and 300 for QRIS).
	 *
	 * @return void
	 */
	public function create_payment() {
		$this->verify_nonce();

		$order_id = absint( $this->param( 'order_id', '0' ) );
		if ( ! $order_id ) {
			$this->respond_error(
				__( 'Parameter order_id wajib diisi.', 'komerce-shipping' ),
				'missing_order_id'
			);
		}

		$payment_method = $this->param( 'payment_method' );
		if ( '' === $payment_method ) {
			$this->respond_error(
				__( 'Parameter payment_method wajib diisi.', 'komerce-shipping' ),
				'missing_payment_method'
			);
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			$this->respond_error(
				__( 'Order tidak ditemukan.', 'komerce-shipping' ),
				'invalid_order_id',
				404
			);
		}

		if ( ! $this->user_can_access_order( $order ) ) {
			$this->respond_error(
				__( 'Anda tidak memiliki akses ke order ini.', 'komerce-shipping' ),
				'forbidden',
				403
			);
		}

		// 0 lets the core function pick the per-method default
		// (3600 for VA, 300 for QRIS).
		$expiry = (int) $this->param( 'expiry_duration', '0' );

		$result = rajaongkir_create_payment( array(
			'order_id'        => $order_id,
			'amount'          => (int) $this->param( 'amount', '0' ),
			'customer_name'   => $this->param( 'customer_name' ),
			'customer_email'  => $this->param( 'customer_email' ),
			'customer_phone'  => $this->param( 'customer_phone' ),
			'payment_method'  => $payment_method,
			'expiry_duration' => max( 0, $expiry ),
		) );

		if ( is_wp_error( $result ) ) {
			$this->respond_wp_error( $result );
		}

		$this->respond_success( $result );
	}

	/**
	 * AJAX: rajaongkir_check_payment_status
	 *
	 * Params: transaction_id or order_id.
	 *
	 * @return void
	 */
	public function check_payment_status() {
		$this->verify_nonce();

		$transaction_id = $this->param( 'transaction_id' );
		$order_id       = absint( $this->param( 'order_id', '0' ) );

		if ( '' === $transaction_id && ! $order_id ) {
			$this->respond_error(
				__( 'Parameter transaction_id atau order_id wajib diisi.', 'komerce-shipping' ),
				'missing_identifier'
			);
		}

		if ( $order_id ) {
			$order = wc_get_order( $order_id );
			if ( ! $order ) {
				$this->respond_error(
					__( 'Order tidak ditemukan.', 'komerce-shipping' ),
					'invalid_order_id',
					404
				);
			}
			if ( ! $this->user_can_access_order( $order ) ) {
				$this->respond_error(
					__( 'Anda tidak memiliki akses ke order ini.', 'komerce-shipping' ),
					'forbidden',
					403
				);
			}
		}

		$identifier = $order_id ? $order_id : $transaction_id;
		$result     = rajaongkir_check_payment_status( $identifier );

		if ( is_wp_error( $result ) ) {
			$this->respond_wp_error( $result );
		}

		$this->respond_success( $result );
	}

	// ─────────────────────────────────────────────────────────────────────
	// Place order (verify payment → create shipping order)
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * AJAX: rajaongkir_place_order
	 *
	 * Verifies the payment status first, then branches:
	 *   success → create the RajaOngkir order, set wc-processing, email customer
	 *   pending → do NOT create the order, keep wc-pending, return payment details
	 *   failed/expired → error with a clear message
	 *
	 * Params: order_id (required), order_key (guest access).
	 *
	 * @return void
	 */
	public function place_order() {
		$this->verify_nonce();

		$order_id = absint( $this->param( 'order_id', '0' ) );
		if ( ! $order_id ) {
			$this->respond_error(
				__( 'Parameter order_id wajib diisi.', 'komerce-shipping' ),
				'missing_order_id'
			);
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			$this->respond_error(
				__( 'Order tidak ditemukan.', 'komerce-shipping' ),
				'invalid_order_id',
				404
			);
		}

		if ( ! $this->user_can_access_order( $order ) ) {
			$this->respond_error(
				__( 'Anda tidak memiliki akses ke order ini.', 'komerce-shipping' ),
				'forbidden',
				403
			);
		}

		Komerce_Logger::payment( $order_id, 'order.place', 'Verifikasi pembayaran sebelum create order' );

		$status = rajaongkir_verify_payment_status( $order_id );

		if ( is_wp_error( $status ) ) {
			$this->respond_wp_error( $status );
		}

		switch ( $status ) {
			case 'success':
				$created = rajaongkir_create_order_to_rajaongkir( $order_id );

				if ( is_wp_error( $created ) ) {
					$this->respond_wp_error( $created );
				}

				$order = wc_get_order( $order_id ); // Refresh after status change.

				$this->respond_success( array(
					'payment_status'      => 'success',
					'order_created'       => true,
					'wc_order_id'         => $order_id,
					'wc_order_status'     => $order->get_status(),
					'rajaongkir_order_id' => $created['order_id'],
					'rajaongkir_order_no' => $created['order_no'] ?? '',
					'airway_bill'         => $created['airway_bill'],
					'message'             => __( 'Pembayaran terkonfirmasi. Order pengiriman berhasil dibuat.', 'komerce-shipping' ),
					'redirect'            => $order->get_checkout_order_received_url(),
				) );
				break;

			case 'pending':
				$this->respond_success( array(
					'payment_status'  => 'pending',
					'order_created'   => false,
					'wc_order_id'     => $order_id,
					'wc_order_status' => $order->get_status(),
					'payment_details' => array(
						'transaction_id'  => (string) $order->get_meta( RAJAONGKIR_META_TRANSACTION_ID ),
						'payment_method'  => (string) $order->get_meta( RAJAONGKIR_META_PAYMENT_METHOD ),
						'virtual_account' => (string) $order->get_meta( RAJAONGKIR_META_VIRTUAL_ACCOUNT ),
						'qr_string'       => (string) $order->get_meta( RAJAONGKIR_META_QR_STRING ),
						'amount'          => (int) $order->get_meta( RAJAONGKIR_META_PAYMENT_AMOUNT ),
						'expiry_date'     => (string) $order->get_meta( RAJAONGKIR_META_PAYMENT_EXPIRY ),
						'payment_url'     => (string) $order->get_meta( RAJAONGKIR_META_PAYMENT_URL ),
					),
					'message'         => __( 'Pembayaran belum diterima. Selesaikan pembayaran terlebih dahulu.', 'komerce-shipping' ),
				) );
				break;

			case 'expired':
				$this->respond_error(
					__( 'Pembayaran sudah kedaluwarsa. Silakan buat pembayaran baru.', 'komerce-shipping' ),
					'payment_expired',
					409
				);
				break;

			case 'failed':
			default:
				$this->respond_error(
					__( 'Pembayaran gagal atau dibatalkan. Silakan coba metode pembayaran lain.', 'komerce-shipping' ),
					'payment_failed',
					409
				);
				break;
		}
	}

	// ─────────────────────────────────────────────────────────────────────
	// Admin
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * AJAX: rajaongkir_clear_cache (admin only)
	 *
	 * @return void
	 */
	public function clear_cache() {
		$this->verify_nonce();

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			$this->respond_error(
				__( 'Unauthorized.', 'komerce-shipping' ),
				'forbidden',
				403
			);
		}

		Komerce_API_Client::clear_cache();

		$this->respond_success( array(
			'message' => __( 'Cache dibersihkan.', 'komerce-shipping' ),
		) );
	}
}
endif;
