<?php
/**
 * Komerce Pickup
 *
 * Courier pickup request via Komerce OpenAPI.
 * Endpoint: POST /order/api/v1/pickup/request
 *
 * @package WooCommerce\Komerce
 * @since   2.2.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Komerce_Pickup' ) ) :
class Komerce_Pickup {

    private $api;

    public function __construct() {
        $this->api = Komerce_API_Client::instance();
        add_action( 'wp_ajax_komerce_request_pickup', array( $this, 'ajax_pickup' ) );
    }

    public function ajax_pickup() {
        check_ajax_referer( 'komerce_order_actions', 'nonce' );
        if ( ! current_user_can( 'edit_shop_orders' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        $order = wc_get_order( absint( $_POST['order_id'] ?? 0 ) );
        if ( ! $order ) {
            wp_send_json_error( 'Order tidak ditemukan' );
        }

        $ko_no = $order->get_meta( Komerce_Order::META_ORDER_NO );
        if ( ! $ko_no ) {
            wp_send_json_error( 'Order pengiriman belum dibuat' );
        }

        $opts = get_option( 'komerce_settings', array() );

        // OpenAPI pickup payload — matches Postman Collection format.
        $payload = array(
            'pickup_date'    => gmdate( 'Y-m-d' ),
            'pickup_time'    => '16:00',
            'pickup_vehicle' => 'Motor',
            'orders'         => array(
                array( 'order_no' => $ko_no ),
            ),
        );

        $resp = $this->api->request_pickup( $payload );
        if ( is_wp_error( $resp ) ) {
            wp_send_json_error( $resp->get_error_message() );
        }

        $order->update_meta_data( Komerce_Order::META_STATUS, 'pickup_requested' );
        $order->add_order_note( 'Request pickup kurir berhasil.' );
        $order->save();

        wp_send_json_success( array( 'message' => 'Pickup sudah di-request' ) );
    }
}
endif;
