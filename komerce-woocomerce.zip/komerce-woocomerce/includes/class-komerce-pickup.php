<?php
/**
 * Komerce Pickup
 *
 * Courier pickup request via Komerce OpenAPI.
 * Endpoint: POST /order/api/v1/pickup/request
 *
 * @package WooCommerce\Komerce
 * @since   2.2.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Komerce_Pickup' ) ) :
class Komerce_Pickup {

    private $api;

    public function __construct() {
        $this->api = Komerce_API_Client::instance();
        add_action( 'wp_ajax_komerce_request_pickup', array( $this, 'ajax_pickup' ) );
    }

    public function ajax_pickup() {
        check_ajax_referer( 'komerce_order_actions', 'nonce' );
        if ( ! current_user_can( 'edit_shop_orders' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        $order = wc_get_order( absint( $_POST['order_id'] ?? 0 ) );
        if ( ! $order ) {
            wp_send_json_error( 'Order tidak ditemukan' );
        }

        $ko_no = $order->get_meta( Komerce_Order::META_ORDER_NO );
        if ( ! $ko_no ) {
            wp_send_json_error( 'Order pengiriman belum dibuat' );
        }

        $opts = get_option( 'komerce_settings', array() );

        // Default pickup schedule: order created_at + 3 hours (Zona Waktu WIB / GMT+7)
        $tz = new DateTimeZone( 'Asia/Jakarta' );
        $created_dt = $order->get_date_created();
        if ( $created_dt ) {
            $dt = clone $created_dt;
            $dt->setTimezone( $tz );
            $dt->modify( '+3 hours' );
        } else {
            $dt = new DateTime( 'now', $tz );
            $dt->modify( '+3 hours' );
        }
        $default_pickup_date = $dt->format( 'Y-m-d' );
        $default_pickup_time = $dt->format( 'H:i' );

        // Configurable pickup date, time, and vehicle.
        $pickup_date = sanitize_text_field( $_POST['pickup_date'] ?? '' );
        if ( empty( $pickup_date ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $pickup_date ) ) {
            $pickup_date = $default_pickup_date;
        }

        $pickup_time = sanitize_text_field( $_POST['pickup_time'] ?? '' );
        if ( empty( $pickup_time ) || ! preg_match( '/^\d{2}:\d{2}$/', $pickup_time ) ) {
            $pickup_time = $default_pickup_time;
        }

        $pickup_vehicle = sanitize_text_field( $_POST['pickup_vehicle'] ?? 'Motor' );
        if ( empty( $pickup_vehicle ) || ! in_array( $pickup_vehicle, array( 'Motor', 'Mobil' ), true ) ) {
            $pickup_vehicle = 'Motor';
        }

        // OpenAPI pickup payload — matches collaborator OpenAPI format.
        $payload = array(
            'pickup_date'    => $pickup_date,
            'pickup_time'    => $pickup_time,
            'pickup_vehicle' => $pickup_vehicle,
            'orders'         => array(
                array( 'order_no' => $ko_no ),
            ),
        );

        $resp = $this->api->request_pickup( $payload );
        if ( is_wp_error( $resp ) ) {
            wp_send_json_error( $resp->get_error_message() );
        }

        $order->update_meta_data( Komerce_Order::META_STATUS, 'pickup_requested' );
        $order->update_meta_data( '_komerce_pickup_date', $pickup_date );
        $order->update_meta_data( '_komerce_pickup_time', $pickup_time );
        $order->update_meta_data( '_komerce_pickup_vehicle', $pickup_vehicle );
        $order->add_order_note( sprintf(
            'Request pickup kurir berhasil untuk tanggal %s pukul %s (%s).',
            $pickup_date,
            $pickup_time,
            $pickup_vehicle
        ) );
        $order->save();

        wp_send_json_success( array(
            'message'        => sprintf( 'Pickup dijadwalkan: %s %s (%s)', $pickup_date, $pickup_time, $pickup_vehicle ),
            'pickup_date'    => $pickup_date,
            'pickup_time'    => $pickup_time,
            'pickup_vehicle' => $pickup_vehicle,
        ) );
    }
}
endif;
