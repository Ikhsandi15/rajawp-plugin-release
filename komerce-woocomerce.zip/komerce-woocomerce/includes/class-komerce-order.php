<?php
/**
 * Komerce Order Management
 *
 * Auto/manual shipping order creation, admin meta box, cancel.
 * Aligned with Komerce Collaborator OpenAPI endpoints.
 *
 * @package WooCommerce\Komerce
 * @since   2.2.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Komerce_Order' ) ) :
class Komerce_Order {

    const META_ORDER_NO  = '_komerce_order_no';
    const META_AWB       = '_komerce_awb';
    const META_COURIER   = '_komerce_courier';
    const META_SERVICE   = '_komerce_service';
    const META_STATUS    = '_komerce_shipping_status';

    private $api;

    /** @var self|null Shared instance for procedural callers. */
    private static $instance = null;

    /**
     * Shared instance accessor (used by rajaongkir-functions.php).
     *
     * @return self
     */
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        $this->api = Komerce_API_Client::instance();

        if ( null === self::$instance ) {
            self::$instance = $this;
        }

        // Admin meta box.
        add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
        add_action( 'add_meta_boxes_woocommerce_page_wc-orders', array( $this, 'add_meta_box' ) );

        // Auto-create on processing.
        $opts = get_option( 'komerce_settings', array() );
        if ( ( $opts['auto_create_order'] ?? '' ) === 'yes' ) {
            add_action( 'woocommerce_order_status_processing', array( $this, 'auto_create' ) );
        }

        // AJAX.
        add_action( 'wp_ajax_komerce_create_order', array( $this, 'ajax_create' ) );
        add_action( 'wp_ajax_komerce_cancel_order', array( $this, 'ajax_cancel' ) );
    }

    // ── Meta box ──

    public function add_meta_box() {
        $screen = 'shop_order';
        if ( function_exists( 'wc_get_container' ) && class_exists( '\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController' ) ) {
            $ctrl = wc_get_container()->get( \Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class );
            if ( $ctrl->custom_orders_table_usage_is_enabled() ) {
                $screen = wc_get_page_screen_id( 'shop-order' );
            }
        }

        add_meta_box( 'komerce-shipping', 'Komerce Shipping', array( $this, 'render_meta_box' ), $screen, 'side', 'high' );
    }

    public function render_meta_box( $post_or_order ) {
        $order = ( $post_or_order instanceof WC_Order ) ? $post_or_order : wc_get_order( $post_or_order->ID );
        if ( ! $order ) {
            return;
        }

        $ko_no   = $order->get_meta( self::META_ORDER_NO );
        $awb     = $order->get_meta( self::META_AWB );
        $courier = $order->get_meta( self::META_COURIER );
        $status  = $order->get_meta( self::META_STATUS );
        $nonce   = wp_create_nonce( 'komerce_order_actions' );
        $oid     = $order->get_id();

        echo '<div class="komerce-mb">';

        // Status.
        $sl = $this->status_label( $status );
        printf( '<p><strong>Status:</strong> <span style="color:%s">%s</span></p>', esc_attr( $sl[1] ), esc_html( $sl[0] ) );

        if ( $ko_no ) {
            echo '<p><strong>Order No:</strong> ' . esc_html( $ko_no ) . '</p>';
        }
        if ( $awb ) {
            echo '<p><strong>AWB:</strong> <code>' . esc_html( $awb ) . '</code></p>';
        }
        if ( $courier ) {
            echo '<p><strong>Kurir:</strong> ' . esc_html( strtoupper( $courier ) ) . '</p>';
        }

        echo '<hr>';

        // Buttons & Actions.
        if ( empty( $ko_no ) ) {
            printf(
                '<button type="button" class="button button-primary" onclick="komerceAction(\'komerce_create_order\',%d,\'%s\')">Buat Order</button> ',
                $oid, esc_js( $nonce )
            );
        } else {
            // Print Label Button
            if ( class_exists( 'Komerce_Label' ) ) {
                $label_url = Komerce_Label::get_label_url( $oid, 'page_1' );
                printf(
                    '<a href="%s" target="_blank" class="button" style="background:#0284c7; color:#fff; border-color:#0284c7; text-decoration:none; margin-right:4px;">🖨️ Cetak Label</a> ',
                    esc_url( $label_url )
                );
            }

            if ( $awb ) {
                printf(
                    '<button type="button" class="button" onclick="komerceAction(\'komerce_track_awb\',%d,\'%s\')">Lacak</button> ',
                    $oid, esc_js( $nonce )
                );
            }

            $p_date = $order->get_meta( '_komerce_pickup_date' );
            $p_time = $order->get_meta( '_komerce_pickup_time' );
            $p_veh  = $order->get_meta( '_komerce_pickup_vehicle' );

            if ( $status === 'pickup_requested' ) {
                if ( $p_date || $p_time ) {
                    printf( '<p style="font-size:12px; margin:8px 0 4px; color:#475569;"><strong>Jadwal Pickup:</strong> %s %s (%s)</p>', esc_html( $p_date ), esc_html( $p_time ), esc_html( $p_veh ?: 'Motor' ) );
                }
            } elseif ( in_array( $status, array( 'created', 'pending', '' ), true ) ) {
                $opts = get_option( 'komerce_settings', array() );
                $default_time    = ! empty( $opts['pickup_default_time'] ) ? $opts['pickup_default_time'] : '16:00';
                $default_vehicle = ! empty( $opts['pickup_default_vehicle'] ) ? $opts['pickup_default_vehicle'] : 'Motor';
                $today           = current_time( 'Y-m-d' );
                ?>
                <div id="komerce-pickup-panel-<?php echo $oid; ?>" style="margin-top:10px; padding:10px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:6px;">
                    <strong style="display:block; margin-bottom:6px; font-size:12px;">📅 Atur Jadwal Pickup:</strong>
                    <div style="margin-bottom:6px;">
                        <label style="font-size:11px; display:block; color:#475569;">Tanggal Pickup:</label>
                        <input type="date" id="komerce_pickup_date_<?php echo $oid; ?>" value="<?php echo esc_attr( $today ); ?>" min="<?php echo esc_attr( $today ); ?>" style="width:100%; font-size:12px; padding:3px 6px;" />
                    </div>
                    <div style="display:flex; gap:6px; margin-bottom:8px;">
                        <div style="flex:1;">
                            <label style="font-size:11px; display:block; color:#475569;">Waktu:</label>
                            <input type="time" id="komerce_pickup_time_<?php echo $oid; ?>" value="<?php echo esc_attr( $default_time ); ?>" style="width:100%; font-size:12px; padding:3px 6px;" />
                        </div>
                        <div style="flex:1;">
                            <label style="font-size:11px; display:block; color:#475569;">Kendaraan:</label>
                            <select id="komerce_pickup_vehicle_<?php echo $oid; ?>" style="width:100%; font-size:12px;">
                                <option value="Motor" <?php selected( $default_vehicle, 'Motor' ); ?>>Motor</option>
                                <option value="Mobil" <?php selected( $default_vehicle, 'Mobil' ); ?>>Mobil</option>
                            </select>
                        </div>
                    </div>
                    <button type="button" class="button button-primary" style="width:100%;" onclick="komercePickupAction(<?php echo $oid; ?>, '<?php echo esc_js( $nonce ); ?>')">Request Pickup</button>
                </div>
                <?php
            }

            if ( in_array( $status, array( 'created', 'pending', '' ), true ) ) {
                printf(
                    '<button type="button" class="button" style="color:#dc2626; margin-top:8px;" onclick="if(confirm(\'Yakin ingin membatalkan order pengiriman ini?\'))komerceAction(\'komerce_cancel_order\',%d,\'%s\')">Batal Order</button>',
                    $oid, esc_js( $nonce )
                );
            }
        }

        echo '<div id="komerce-result" style="margin-top:10px;"></div>';
        echo '</div>';

        // Inline JS for admin AJAX actions.
        ?>
        <script>
        function komerceAction(action, orderId, nonce) {
            var r = document.getElementById('komerce-result');
            r.innerHTML = 'Memproses...';
            r.style.color = '#2563eb';

            jQuery.post(ajaxurl, {action: action, order_id: orderId, nonce: nonce}, function(resp) {
                if (resp.success) {
                    r.style.color = '#16a34a';
                    r.innerHTML = (resp.data.message || 'Berhasil');
                    if (action !== 'komerce_track_awb') setTimeout(function(){ location.reload(); }, 1200);
                    if (resp.data.history) {
                        var h = '<ul style="margin-top:8px;font-size:12px;">';
                        resp.data.history.forEach(function(i){ h += '<li><small>' + (i.date||'') + '</small> ' + (i.description||'') + '</li>'; });
                        h += '</ul>';
                        r.innerHTML += h;
                    }
                } else {
                    r.style.color = '#dc2626';
                    r.innerHTML = 'Error: ' + (resp.data || 'Gagal');
                }
            }).fail(function(){ r.style.color='#dc2626'; r.innerHTML='Request error'; });
        }

        function komercePickupAction(orderId, nonce) {
            var pDate = document.getElementById('komerce_pickup_date_' + orderId).value;
            var pTime = document.getElementById('komerce_pickup_time_' + orderId).value;
            var pVeh  = document.getElementById('komerce_pickup_vehicle_' + orderId).value;

            var r = document.getElementById('komerce-result');
            r.innerHTML = 'Memproses request pickup...';
            r.style.color = '#2563eb';

            jQuery.post(ajaxurl, {
                action: 'komerce_request_pickup',
                order_id: orderId,
                pickup_date: pDate,
                pickup_time: pTime,
                pickup_vehicle: pVeh,
                nonce: nonce
            }, function(resp) {
                if (resp.success) {
                    r.style.color = '#16a34a';
                    r.innerHTML = (resp.data.message || 'Pickup berhasil dijadwalkan');
                    setTimeout(function(){ location.reload(); }, 1200);
                } else {
                    r.style.color = '#dc2626';
                    r.innerHTML = 'Error: ' + (resp.data || 'Gagal request pickup');
                }
            }).fail(function(){ r.style.color='#dc2626'; r.innerHTML='Request error'; });
        }
        </script>
        <?php
    }

    private function status_label( $status ) {
        $map = array(
            ''          => array( 'Belum dibuat', '#9ca3af' ),
            'pending'   => array( 'Menunggu', '#f59e0b' ),
            'created'   => array( 'Dibuat', '#3b82f6' ),
            'pickup_requested' => array( 'Pickup', '#8b5cf6' ),
            'in_transit' => array( 'Dikirim', '#6366f1' ),
            'delivered'  => array( 'Diterima', '#10b981' ),
            'cancelled'  => array( 'Dibatalkan', '#ef4444' ),
        );
        return $map[ $status ] ?? array( ucfirst( $status ), '#6b7280' );
    }

    // ── AJAX handlers ──

    public function ajax_create() {
        check_ajax_referer( 'komerce_order_actions', 'nonce' );
        if ( ! current_user_can( 'edit_shop_orders' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        $order = wc_get_order( absint( $_POST['order_id'] ?? 0 ) );
        if ( ! $order ) {
            wp_send_json_error( 'Order tidak ditemukan' );
        }

        $result = $this->create_shipping_order( $order );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }

        wp_send_json_success( array(
            'message'  => 'Order pengiriman dibuat',
            'order_no' => $result['order_no'],
            'awb'      => $result['awb'],
        ) );
    }

    public function ajax_cancel() {
        check_ajax_referer( 'komerce_order_actions', 'nonce' );
        if ( ! current_user_can( 'edit_shop_orders' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        $order = wc_get_order( absint( $_POST['order_id'] ?? 0 ) );
        if ( ! $order ) {
            wp_send_json_error( 'Order tidak ditemukan' );
        }

        $ko_no = $order->get_meta( self::META_ORDER_NO );
        if ( ! $ko_no ) {
            wp_send_json_error( 'Belum ada order Komerce' );
        }

        $resp = $this->api->cancel_order( $ko_no );
        if ( is_wp_error( $resp ) ) {
            wp_send_json_error( $resp->get_error_message() );
        }

        $order->update_meta_data( self::META_STATUS, 'cancelled' );
        $order->add_order_note( 'Order pengiriman Komerce dibatalkan.' );
        $order->save();

        wp_send_json_success( array( 'message' => 'Order dibatalkan' ) );
    }

    // ── Auto-create ──

    public function auto_create( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order || $order->get_meta( self::META_ORDER_NO ) ) {
            return;
        }

        $uses_komerce = false;
        foreach ( $order->get_shipping_methods() as $m ) {
            if ( strpos( $m->get_method_id(), 'komerce_shipping' ) !== false ) {
                $uses_komerce = true;
                break;
            }
        }
        if ( ! $uses_komerce ) {
            return;
        }

        $result = $this->create_shipping_order( $order );
        if ( is_wp_error( $result ) ) {
            $order->add_order_note( 'Auto-create Komerce gagal: ' . $result->get_error_message() );
        }
    }

    // ── Core: create shipping order via OpenAPI ──

    /**
     * Create the shipping order in Komerce/RajaOngkir.
     *
     * @param WC_Order $order WooCommerce order.
     * @return array|WP_Error { order_no, awb }
     */
    public function create_shipping_order( WC_Order $order ) {
        $opts = get_option( 'komerce_settings', array() );

        // Extract courier and service from shipping meta.
        $courier = $service = $shipping_code = '';
        $shipping_cost     = 0;
        $shipping_cashback = 0;
        $service_fee       = 0;
        $grandtotal        = 0;
        $is_cod            = false;

        foreach ( $order->get_shipping_methods() as $m ) {
            foreach ( $m->get_meta_data() as $md ) {
                $d = $md->get_data();
                if ( $d['key'] === 'courier_code' )      $courier           = $d['value'];
                if ( $d['key'] === 'shipping_code' )     $shipping_code     = $d['value']; // Order-service format: JNE, JNT, etc.
                if ( $d['key'] === 'service_code' )      $service           = $d['value']; // REG, OKE, YES, etc.
                if ( $d['key'] === 'original_cost' )     $shipping_cost     = (int) $d['value'];
                if ( $d['key'] === 'shipping_cashback' ) $shipping_cashback = (int) $d['value'];
                if ( $d['key'] === 'service_fee' )       $service_fee       = (int) $d['value'];
                if ( $d['key'] === 'grandtotal' )        $grandtotal        = (int) $d['value'];
                if ( $d['key'] === 'is_cod' && $d['value'] ) $is_cod        = true;
            }
            // Get shipping total from WC as fallback.
            if ( ! $shipping_cost ) {
                $shipping_cost = (int) $m->get_total();
            }
        }

        // Use shipping_code (order-service format) if available, fallback to courier_code uppercase.
        $shipping_value = ! empty( $shipping_code ) ? $shipping_code : strtoupper( $courier );

        // Determine payment method for OpenAPI.
        $pay_method = $order->get_meta( '_komerce_pay_method' );

        $dest_id = $order->get_meta( 'billing_komerce_destination_id' )
            ?: $order->get_meta( 'shipping_komerce_destination_id' )
            ?: $order->get_meta( '_rajaongkir_destination_id' );

        if ( empty( $dest_id ) && WC()->session && is_callable( array( WC()->session, 'get' ) ) ) {
            $dest_id = WC()->session->get( 'komerce_destination_id' );
            if ( $dest_id ) {
                $order->update_meta_data( '_rajaongkir_destination_id', (string) $dest_id );
                $order->save();
            }
        }

        // Build order_details from WC items.
        // All dimension/variant fields are required by the API, so empty values
        // fall back to sane defaults rather than being sent blank.
        $order_details = array();
        $total_weight  = 0;
        foreach ( $order->get_items() as $item ) {
            $product     = $item->get_product();
            $qty         = max( 1, (int) $item->get_quantity() );
            $item_weight = 0;

            if ( $product ) {
                $item_weight = (int) round( (float) $product->get_weight() * $this->weight_multiplier() );
            }
            if ( $item_weight <= 0 ) {
                $item_weight = 1000; // 1 kg default when the product has no weight.
            }

            $total_weight += $item_weight * $qty;

            $variant = '';
            if ( $product && method_exists( $product, 'get_attribute_summary' ) ) {
                $variant = (string) $product->get_attribute_summary();
            } elseif ( $item instanceof WC_Order_Item_Product && method_exists( $item, 'get_formatted_meta_data' ) ) {
                $meta = $item->get_formatted_meta_data( '' );
                if ( ! empty( $meta ) ) {
                    $parts = array();
                    foreach ( $meta as $m ) {
                        $parts[] = $m->display_key . ': ' . strip_tags( (string) $m->display_value );
                    }
                    $variant = implode( ', ', $parts );
                }
            }
            if ( '' === trim( (string) $variant ) ) {
                $variant = '-'; // Required field; the API rejects an empty string.
            }

            $width  = $product ? (int) round( (float) $product->get_width() ) : 0;
            $height = $product ? (int) round( (float) $product->get_height() ) : 0;
            $length = $product ? (int) round( (float) $product->get_length() ) : 0;

            $order_details[] = array(
                'product_name'         => $item->get_name(),
                'product_variant_name' => $variant,
                'product_price'        => (int) round( (float) $item->get_subtotal() / $qty ),
                'product_weight'       => $item_weight, // grams
                'product_width'        => max( 1, $width ),
                'product_height'       => max( 1, $height ),
                'product_length'       => max( 1, $length ),
                'qty'                  => $qty,
                'subtotal'             => (int) round( (float) $item->get_subtotal() ),
            );
        }

        // Live tariff match with Order-Service calculation to ensure exact price match
        if ( ! empty( $dest_id ) && ! empty( $shipping_value ) ) {
            $calc_resp = $this->api->calculate_cost( array(
                'shipper_destination_id'  => (int) ( $opts['origin_id'] ?? 0 ),
                'receiver_destination_id' => (int) $dest_id,
                'weight'                  => rajaongkir_grams_to_kg( max( $total_weight, 1000 ) ),
                'item_value'              => (int) round( (float) $order->get_subtotal() ),
                'cod'                     => $is_cod ? 'yes' : 'no',
            ) );

            if ( ! is_wp_error( $calc_resp ) && ! empty( $calc_resp['data'] ) ) {
                $categories = array( 'calculate_reguler', 'calculate_cargo', 'calculate_instant', 'calculate_sameday' );
                foreach ( $categories as $cat ) {
                    if ( ! empty( $calc_resp['data'][ $cat ] ) && is_array( $calc_resp['data'][ $cat ] ) ) {
                        foreach ( $calc_resp['data'][ $cat ] as $rate ) {
                            $r_ship = strtoupper( (string) ( $rate['shipping_code'] ?? $rate['shipping_name'] ?? '' ) );
                            $r_serv = strtoupper( (string) ( $rate['service_code'] ?? $rate['service_name'] ?? '' ) );
                            if ( $r_ship === strtoupper( $shipping_value ) && ( empty( $service ) || false !== stripos( $r_serv, strtoupper( $service ) ) || false !== stripos( strtoupper( $service ), $r_serv ) ) ) {
                                $shipping_cost     = (int) ( $rate['shipping_cost'] ?? $shipping_cost );
                                $shipping_cashback = (int) ( $rate['shipping_cashback'] ?? 0 );
                                $service_fee       = (int) ( $rate['service_fee'] ?? 0 );
                                $grandtotal        = (int) ( $rate['grandtotal'] ?? $grandtotal );
                                break 2;
                            }
                        }
                    }
                }
            }
        }

        // Compute grandtotal if not from meta.
        if ( ! $grandtotal ) {
            $grandtotal = (int) $order->get_total();
        }

        // Payment method for Komerce order-service (Strictly Non-COD: BANK TRANSFER).
        $is_cod         = false;
        $payment_method = 'BANK TRANSFER';
        $cod_value      = 0;
        $service_fee    = 0;

        // Receiver data with billing fallback (shipping fields may be empty).
        $receiver_name = trim( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() );
        if ( '' === $receiver_name ) {
            $receiver_name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
        }
        $receiver_address = $order->get_shipping_address_1() ?: $order->get_billing_address_1();

        // The API rejects "+62"; numbers must start with 0 or 62.
        $shipper_phone  = rajaongkir_normalize_phone( $opts['shipper_phone'] ?? '' );
        $receiver_phone = rajaongkir_normalize_phone( $order->get_billing_phone() );

        // OpenAPI store order payload.
        $payload = array(
            'order_date'              => gmdate( 'Y-m-d' ),
            'brand_name'              => get_bloginfo( 'name' ),
            'shipper_name'            => $opts['shipper_name']    ?? get_bloginfo( 'name' ),
            'shipper_phone'           => $shipper_phone,
            'shipper_destination_id'  => (int) ( $opts['origin_id'] ?? 0 ),
            'shipper_address'         => $opts['shipper_address'] ?? '',
            'shipper_email'           => get_option( 'admin_email' ),
            'receiver_name'           => $receiver_name,
            'receiver_phone'          => $receiver_phone,
            'receiver_destination_id' => (int) $dest_id,
            'receiver_address'        => $receiver_address,
            'shipping'                => $shipping_value,
            'shipping_type'           => $service,
            'payment_method'          => $payment_method,
            'shipping_cost'           => $shipping_cost,
            'shipping_cashback'       => $shipping_cashback,
            'service_fee'             => $service_fee,
            'additional_cost'         => 0,
            'grand_total'             => $grandtotal,
            'cod_value'               => $cod_value,
            'insurance_value'         => 0,
            'order_details'           => $order_details,
        );

        $resp = $this->api->create_order( $payload );
        if ( is_wp_error( $resp ) ) {
            if ( class_exists( 'Komerce_Logger' ) ) {
                Komerce_Logger::payment(
                    $order->get_id(),
                    'order.store',
                    'Store order gagal: ' . $resp->get_error_message(),
                    array( 'shipping' => $shipping_value, 'shipping_type' => $service ),
                    'error'
                );
            }
            return $resp;
        }

        // Store Order response: data.order_id (int) + data.order_no ("KOM...").
        // No AWB is returned here — the courier assigns it later and it reaches
        // us through the shipping webhook as `cnote`.
        $data     = $resp['data'] ?? $resp;
        $ro_id    = isset( $data['order_id'] ) ? (string) $data['order_id'] : '';
        $order_no = (string) ( $data['order_no'] ?? '' );
        $awb      = (string) ( $data['awb'] ?? $data['cnote'] ?? $data['waybill'] ?? '' );

        // Legacy fallback for older/other response shapes.
        if ( '' === $order_no ) {
            $order_no = (string) ( $data['id'] ?? $ro_id );
        }

        $order->update_meta_data( self::META_ORDER_NO, $order_no );
        $order->update_meta_data( self::META_COURIER, $courier );
        $order->update_meta_data( self::META_SERVICE, $service );
        $order->update_meta_data( self::META_STATUS, 'created' );
        if ( $awb ) {
            $order->update_meta_data( self::META_AWB, $awb );
        }

        // Mirror to the RajaOngkir meta keys expected by the AJAX layer.
        $order->update_meta_data( '_rajaongkir_order_id', $ro_id !== '' ? $ro_id : $order_no );
        $order->update_meta_data( '_rajaongkir_order_no', $order_no );
        if ( $awb ) {
            $order->update_meta_data( '_rajaongkir_airway_bill', $awb );
        }

        $order->add_order_note( sprintf(
            'Komerce order dibuat (No: %s). Kurir: %s %s. %s',
            $order_no,
            strtoupper( $courier ),
            $service,
            $awb ? "AWB: {$awb}" : 'AWB menunggu notifikasi kurir.'
        ) );
        $order->save();

        if ( class_exists( 'Komerce_Logger' ) ) {
            Komerce_Logger::payment( $order->get_id(), 'order.store', 'Store order berhasil', array(
                'order_id' => $ro_id,
                'order_no' => $order_no,
                'awb'      => $awb ?: '(menunggu webhook)',
            ) );
        }

        return array(
            'order_id' => $ro_id,
            'order_no' => $order_no,
            'awb'      => $awb,
        );
    }

    private function weight_multiplier() {
        $mult = array( 'kg' => 1000, 'lbs' => 453.592, 'oz' => 28.3495, 'g' => 1 );
        return $mult[ get_option( 'woocommerce_weight_unit', 'kg' ) ] ?? 1000;
    }

    private function item_desc( WC_Order $order ) {
        $parts = array();
        foreach ( $order->get_items() as $item ) {
            $parts[] = $item->get_name() . ' x' . $item->get_quantity();
        }
        $desc = implode( ', ', $parts );
        return strlen( $desc ) > 200 ? substr( $desc, 0, 197 ) . '...' : $desc;
    }
}
endif;
